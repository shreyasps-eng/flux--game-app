FLUX Showcase Website

Open index.html for the website. For the embedded actual City preview, host this folder using a web server (e.g. python -m http.server 8000) rather than file:// because JavaScript modules need HTTP.

Contains the official FLUX logo and original playablecity HTML/JavaScript/assets from the supplied Android project. Other module panels are labeled conceptual previews, not genuine captured Android screenshots. No download button. Contact: shreyasprasad42@gmail.com

Deploy the contents of this folder to Cloudflare Pages or another static host. No build step is needed.
