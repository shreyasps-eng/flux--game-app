// City/player progression is separate from a property's six architectural tiers.
// These limits pace normal offline play; the device clock is not a trusted server.
export const MAX_CITY_LEVEL = 300;
export const DAILY_XP_CAP = 350;
export const REAL_DAY_MS = 24 * 60 * 60 * 1000;
const VERSION = 1;
const whole = (value, fallback = 0) => Number.isFinite(Number(value))
  ? Math.max(0, Math.floor(Number(value))) : fallback;

export const LEVEL_XP = Object.freeze((() => {
  const thresholds = [0, 0];
  for (let level = 1; level < MAX_CITY_LEVEL; level++)
    thresholds[level + 1] = thresholds[level] + Math.round(200 + 4 * level + .015 * level * level);
  return thresholds;
})());
const MAX_XP = LEVEL_XP[MAX_CITY_LEVEL];

export function xpForLevel(level) {
  return LEVEL_XP[Math.max(1, Math.min(MAX_CITY_LEVEL, whole(level, 1)))];
}
export function levelFromXp(xp) {
  const value = whole(xp);
  let low = 1, high = MAX_CITY_LEVEL;
  while (low < high) {
    const mid = Math.ceil((low + high) / 2);
    if (LEVEL_XP[mid] <= value) low = mid;
    else high = mid - 1;
  }
  return low;
}
export function minimumDaysForLevel(level) {
  // The first window can award XP immediately; later windows need 24 hours.
  return Math.max(0, Math.ceil(xpForLevel(level) / DAILY_XP_CAP) - 1);
}
export function progressionRank(level) {
  return level >= 300 ? 'Legendary Empire' : level >= 250 ? 'Global Megacity'
    : level >= 200 ? 'International Empire' : level >= 150 ? 'National Empire'
    : level >= 100 ? 'Corporate Hub' : level >= 50 ? 'Regional Business'
    : level >= 25 ? 'Growing City' : 'Starter City';
}

export function normalizeCityProgression(state, now = Date.now()) {
  const time = whole(now);
  const raw = state.cityProgression;
  if (!raw || raw.version !== VERSION) {
    // Preserve the old reached level (up to its old cap of 25), converting its
    // partial progress. Unbounded XP from the old Next Day loop cannot jump
    // directly to Level 300 after migration.
    const oldXp = whole(state.xp);
    const oldEarned = Math.min(25, Math.floor(oldXp / 220) + Math.floor(Object.keys(state.owned || {}).length / 4) + 1);
    const preserved = Math.max(oldEarned, Math.min(25, whole(state.highestCityLevel, 1)));
    const cost = xpForLevel(preserved + 1) - xpForLevel(preserved);
    state.xp = xpForLevel(preserved) + Math.floor(oldXp % 220 / 220 * cost);
    state.highestCityLevel = preserved;
    const claims = {};
    for (const [id, o] of Object.entries(state.owned || {})) {
      claims['build:' + id] = true;
      const completed = o.daysLeft > 0 && o.constructionKind === 'build' ? Math.max(0, o.level - 1) : o.level;
      for (let level = 1; level <= Math.min(6, completed || 0); level++) claims['complete:' + id + ':' + level] = true;
    }
    for (const [id, complete] of Object.entries(state.missions || {})) if (complete) claims['mission:' + id] = true;
    if (state.utilities?.power) claims['utility:power'] = true;
    if (state.utilities?.water) claims['utility:water'] = true;
    state.cityProgression = { version: VERSION, windowStartedAt: time, lastObservedAt: time,
      usedXp: 0, pendingXp: 0, claims, windowClaims: {} };
  } else {
    state.xp = Math.min(MAX_XP, whole(state.xp));
    state.highestCityLevel = Math.max(levelFromXp(state.xp), Math.min(MAX_CITY_LEVEL, whole(state.highestCityLevel, 1)));
    // Retain a reached level even if an older save omitted its cumulative XP.
    state.xp = Math.max(state.xp, xpForLevel(state.highestCityLevel));
    state.cityProgression = { version: VERSION,
      windowStartedAt: whole(raw.windowStartedAt, time),
      lastObservedAt: Math.max(whole(raw.lastObservedAt, time), whole(raw.windowStartedAt, time)),
      usedXp: Math.min(DAILY_XP_CAP, whole(raw.usedXp)),
      pendingXp: Math.min(MAX_XP - state.xp, whole(raw.pendingXp)),
      claims: raw.claims && typeof raw.claims === 'object' && !Array.isArray(raw.claims) ? {...raw.claims} : {},
      windowClaims: raw.windowClaims && typeof raw.windowClaims === 'object' && !Array.isArray(raw.windowClaims) ? {...raw.windowClaims} : {} };
  }
  syncCityProgression(state, time);
  return state;
}

function dailyWindow(state, now) {
  const p = state.cityProgression;
  // Moving the clock backwards cannot reopen an already used XP window.
  const time = Math.max(whole(now), p.lastObservedAt, p.windowStartedAt);
  if (time - p.windowStartedAt >= REAL_DAY_MS) {
    p.windowStartedAt += Math.floor((time - p.windowStartedAt) / REAL_DAY_MS) * REAL_DAY_MS;
    p.usedXp = 0;
    p.windowClaims = {};
  }
  p.lastObservedAt = time;
  return time;
}
function releasePending(state) {
  const p = state.cityProgression;
  const grant = Math.min(p.pendingXp, DAILY_XP_CAP - p.usedXp, MAX_XP - state.xp);
  p.pendingXp -= grant;
  p.usedXp += grant;
  state.xp += grant;
  state.highestCityLevel = Math.max(state.highestCityLevel || 1, levelFromXp(state.xp));
  return grant;
}
export function syncCityProgression(state, now = Date.now()) {
  dailyWindow(state, now);
  return releasePending(state);
}
export function awardCityXp(state, value, key, daily = false, now = Date.now()) {
  syncCityProgression(state, now);
  const p = state.cityProgression, claims = daily ? p.windowClaims : p.claims;
  if (!key || Object.prototype.hasOwnProperty.call(claims, key)) return { granted: 0, queued: 0 };
  const earned = Math.min(whole(value), MAX_XP - state.xp - p.pendingXp);
  if (!earned) return { granted: 0, queued: 0 };
  claims[key] = true;
  p.pendingXp += earned;
  const granted = releasePending(state);
  return { granted, queued: earned - granted };
}
export function cityProgressionStatus(state, now = Date.now()) {
  syncCityProgression(state, now);
  const p = state.cityProgression, level = Math.min(MAX_CITY_LEVEL, state.highestCityLevel);
  const next = level === MAX_CITY_LEVEL ? MAX_XP : LEVEL_XP[level + 1];
  const needed = next - LEVEL_XP[level];
  return { level, cap: MAX_CITY_LEVEL, rank: progressionRank(level), totalXp: state.xp,
    levelXp: state.xp - LEVEL_XP[level], nextCost: needed, toNext: Math.max(0, next - state.xp),
    fraction: needed ? (state.xp - LEVEL_XP[level]) / needed : 1,
    usedXp: p.usedXp, dailyCap: DAILY_XP_CAP, pendingXp: p.pendingXp,
    resetsInMs: Math.max(0, p.windowStartedAt + REAL_DAY_MS - p.lastObservedAt),
    dailyRewardClaimed: !!p.windowClaims['daily-city'],
    maxLevelXp: MAX_XP, minimumDaysToMax: minimumDaysForLevel(MAX_CITY_LEVEL) };
}
