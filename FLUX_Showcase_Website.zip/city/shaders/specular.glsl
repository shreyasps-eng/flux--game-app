// GGX specular helper used by specular-lighting.js. All directions are in view space.

const float FLUX_PI = 3.141592653589793;

vec3 fluxFresnelSchlick(float VoH, vec3 F0) {
  return F0 + (vec3(1.0) - F0) * pow(1.0 - clamp(VoH, 0.0, 1.0), 5.0);
}

float fluxDistributionGGX(float NoH, float roughness) {
  float alpha = max(roughness * roughness, 0.0025);
  float alpha2 = alpha * alpha;
  float d = NoH * NoH * (alpha2 - 1.0) + 1.0;
  return alpha2 / max(FLUX_PI * d * d, 0.000001);
}

float fluxVisibilitySmith(float NoV, float NoL, float roughness) {
  float r = roughness + 1.0;
  float k = r * r * 0.125;
  float gv = NoV / max(NoV * (1.0 - k) + k, 0.00001);
  float gl = NoL / max(NoL * (1.0 - k) + k, 0.00001);
  return gv * gl;
}

// Returns the specular BRDF * NoL. Multiply by linear light radiance and its
// shadow visibility. Use metallic albedo for F0 on metals, ~0.04 on dielectrics.
vec3 fluxSpecularGGX(vec3 N, vec3 V, vec3 L, vec3 F0, float roughness) {
  N = normalize(N); V = normalize(V); L = normalize(L);
  float NoL = max(dot(N, L), 0.0);
  float NoV = max(dot(N, V), 0.0);
  vec3 halfDirection = V + L;
  if (NoL <= 0.0 || NoV <= 0.0 || dot(halfDirection, halfDirection) < 0.000001) {
    return vec3(0.0);
  }
  vec3 H = normalize(halfDirection);
  float NoH = max(dot(N, H), 0.0);
  float VoH = max(dot(V, H), 0.0);
  float r = clamp(roughness, 0.08, 1.0);
  vec3 F = fluxFresnelSchlick(VoH, clamp(F0, vec3(0.0), vec3(1.0)));
  float D = fluxDistributionGGX(NoH, r);
  float G = fluxVisibilitySmith(NoV, NoL, r);
  return (D * G * F / max(4.0 * NoV * NoL, 0.0001)) * NoL;
}
