// Three.js r169 / WebGL2. The standalone copy is shaders/specular.glsl.
// Directions and normals are all in VIEW space; geometryViewDir also supports
// the orthographic City camera. Lighting is accumulated in linear color space.
export const SPECULAR_GLSL = /* glsl */`
const float FLUX_PI = 3.141592653589793;

vec3 fluxFresnelSchlick(float VoH, vec3 F0) {
  return F0 + (vec3(1.0) - F0) * pow(1.0 - clamp(VoH, 0.0, 1.0), 5.0);
}

float fluxDistributionGGX(float NoH, float roughness) {
  float alpha = max(roughness * roughness, 0.0025);
  float alpha2 = alpha * alpha;
  float d = NoH * NoH * (alpha2 - 1.0) + 1.0;
  return alpha2 / max(FLUX_PI * d * d, 0.000001);
}

float fluxVisibilitySmith(float NoV, float NoL, float roughness) {
  float r = roughness + 1.0;
  float k = r * r * 0.125;
  float gv = NoV / max(NoV * (1.0 - k) + k, 0.00001);
  float gl = NoL / max(NoL * (1.0 - k) + k, 0.00001);
  return gv * gl;
}

// Returns the specular BRDF * NoL. Multiply by linear light radiance and its
// shadow visibility. Use metallic albedo for F0 on metals, ~0.04 on dielectrics.
vec3 fluxSpecularGGX(vec3 N, vec3 V, vec3 L, vec3 F0, float roughness) {
  N = normalize(N); V = normalize(V); L = normalize(L);
  float NoL = max(dot(N, L), 0.0);
  float NoV = max(dot(N, V), 0.0);
  vec3 halfDirection = V + L;
  if (NoL <= 0.0 || NoV <= 0.0 || dot(halfDirection, halfDirection) < 0.000001) {
    return vec3(0.0);
  }
  vec3 H = normalize(halfDirection);
  float NoH = max(dot(N, H), 0.0);
  float VoH = max(dot(V, H), 0.0);
  float r = clamp(roughness, 0.08, 1.0);
  vec3 F = fluxFresnelSchlick(VoH, clamp(F0, vec3(0.0), vec3(1.0)));
  float D = fluxDistributionGGX(NoH, r);
  float G = fluxVisibilitySmith(NoV, NoL, r);
  return (D * G * F / max(4.0 * NoV * NoL, 0.0001)) * NoL;
}
`;

const ACCUMULATE_GLSL = /* glsl */`
#if NUM_DIR_LIGHTS > 0
  float fluxSunVisibility = 1.0;
  #if defined(USE_SHADOWMAP) && NUM_DIR_LIGHT_SHADOWS > 0
    if (receiveShadow) {
      fluxSunVisibility = getShadow(
        directionalShadowMap[0],
        directionalLightShadows[0].shadowMapSize,
        directionalLightShadows[0].shadowIntensity,
        directionalLightShadows[0].shadowBias,
        directionalLightShadows[0].shadowRadius,
        vDirectionalShadowCoord[0]
      );
    }
  #endif
  vec3 fluxF0 = mix(vec3(0.04), diffuseColor.rgb, metalnessFactor);
  reflectedLight.directSpecular += fluxSpecularGGX(
    geometryNormal, geometryViewDir, directionalLights[0].direction,
    fluxF0, roughnessFactor
  ) * directionalLights[0].color * fluxSunVisibility * uFluxSpecularGain;
#endif
`;

// A small additional polished-surface lobe, on top of Three's PBR lighting.
// Three still provides environment reflections, normal transforms, shadows,
// clearcoat, tone mapping and sRGB output. Never replace its entire shader.
export function installSpecularLighting(material, gain = 0.12) {
  material.onBeforeCompile = (shader) => {
    shader.uniforms.uFluxSpecularGain = { value: gain };
    shader.fragmentShader = shader.fragmentShader
      .replace('#include <common>', '#include <common>\nuniform float uFluxSpecularGain;\n' + SPECULAR_GLSL)
      .replace('#include <lights_fragment_end>', '#include <lights_fragment_end>\n' + ACCUMULATE_GLSL);
  };
  material.customProgramCacheKey = () => 'flux-city-ggx-v1';
  material.userData.fluxSpecular = true;
  return material;
}
