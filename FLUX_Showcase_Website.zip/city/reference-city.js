import * as T from './three.module.js';

// Real geometry. Each upgrade activates additional floor groups and moves the
// roof, rather than stretching a picture or changing the horizontal footprint.
export function createReferenceArchitecture(graphics, scene, pickables) {
  const { box, shape, material } = graphics;
  const cube = new T.BoxGeometry(1, 1, 1);
  const leaf = new T.SphereGeometry(.5, 12, 8);
  const cylinder = new T.CylinderGeometry(.5, .5, 1, 20, 1);
  const colors = { stone: 0xe9dfc9, edge: 0xf4ebd9, dark: 0x182d38,
    bronze: 0xae8749, glass: 0x3d647e, lawn: 0x24323e };
  const signMaterials = new Map(), advertMaterials = new Map();
  const stats = { tallAssets: 0, terraceFloors: 0, backdropBuildings: 0 };
  const solid = (root, name, x, y, z, w, h, d, color, id = null, kind = 'stone') =>
    shape(root, cube, name, x, y, z, w, h, d, color, id, 0, kind);

  function sign(root, text, x, y, z, w, h, yaw = 0, id = null) {
    if (!signMaterials.has(text)) {
      const c = document.createElement('canvas'); c.width = 512; c.height = 128;
      const ctx = c.getContext('2d');
      ctx.fillStyle = '#162630'; ctx.fillRect(0, 0, 512, 128);
      ctx.strokeStyle = '#a98950'; ctx.lineWidth = 5; ctx.strokeRect(3, 3, 506, 122);
      ctx.fillStyle = '#f2d49a'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '600 ' + (text.length > 18 ? 35 : 46) + 'px Arial';
      ctx.fillText(text, 256, 65, 475);
      const map = new T.CanvasTexture(c); map.colorSpace = T.SRGBColorSpace;
      map.anisotropy = Math.min(4, graphics.maxAnisotropy || 4);
      signMaterials.set(text, new T.MeshStandardMaterial({ map, roughness: .6,
        emissive: 0x8c6b36, emissiveMap: map, emissiveIntensity: .16 }));
    }
    const m = new T.Mesh(new T.PlaneGeometry(w, h), signMaterials.get(text));
    m.name = 'Architectural sign: ' + text; m.position.set(x, y, z); m.rotation.y = yaw;
    if (id) { m.userData.assetId = id; pickables.push(m); }
    root.add(m); return m;
  }

  function advert(root, text, x, y, z, w, h, id) {
    if (!advertMaterials.has(text)) {
      const canvas = document.createElement('canvas'); canvas.width = 256; canvas.height = 512;
      const c = canvas.getContext('2d');
      const grad = c.createLinearGradient(0, 0, 256, 512);
      grad.addColorStop(0, '#e7d8bb'); grad.addColorStop(1, '#ad916d');
      c.fillStyle = grad; c.fillRect(0, 0, 256, 512);
      c.fillStyle = '#4b453b'; c.font = '28px Georgia'; c.textAlign = 'center'; c.fillText(text, 128, 55);
      c.fillStyle = '#57422e'; c.beginPath(); c.ellipse(133, 139, 32, 44, 0, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#b98162'; c.beginPath(); c.ellipse(135, 144, 25, 34, 0, 0, Math.PI * 2); c.fill();
      c.fillStyle = text === 'STYLE' ? '#b96b3c' : '#647b70';
      c.beginPath(); c.moveTo(108,183); c.lineTo(159,183); c.lineTo(172,238); c.lineTo(184,369); c.lineTo(79,369); c.lineTo(99,238); c.closePath(); c.fill();
      c.strokeStyle = '#b98162'; c.lineWidth = 12; c.lineCap = 'round';
      c.beginPath(); c.moveTo(103,190); c.lineTo(81,249); c.lineTo(65,269); c.moveTo(161,190); c.lineTo(180,252); c.lineTo(189,270); c.stroke();
      c.strokeStyle = '#695443'; c.lineWidth = 9; c.beginPath(); c.moveTo(110,367); c.lineTo(101,423); c.moveTo(151,367); c.lineTo(162,423); c.stroke();
      c.fillStyle = '#efe6d2'; c.font = '18px Arial'; c.fillText('NEW COLLECTION', 128, 467);
      const map = new T.CanvasTexture(canvas); map.colorSpace = T.SRGBColorSpace;
      advertMaterials.set(text, new T.MeshStandardMaterial({map,roughness:.85}));
    }
    const poster = new T.Mesh(new T.PlaneGeometry(w,h), advertMaterials.get(text));
    poster.position.set(x,y,z); poster.name = 'retail campaign poster';
    poster.userData.assetId = id; if (id) pickables.push(poster); root.add(poster);
  }
  function tree(root, x, z, size = 1, ground = 10, palm = false) {
    const g = new T.Group(); g.position.set(x, ground, z); root.add(g);
    solid(g, 'tree trunk', 0, 21 * size, 0, 4 * size, 42 * size, 4 * size, 0x715a40);
    if (palm) {
      for (let i = 0; i < 8; i++) {
        const a = i * Math.PI / 4;
        const frond = shape(g, leaf, 'palm foliage', Math.cos(a) * 14 * size,
          48 * size, Math.sin(a) * 14 * size, 45 * size, 4 * size, 10 * size,
          i % 2 ? 0x4a703b : 0x668249, null, a, 'lawn');
        frond.rotation.z = Math.sin(a) * .25;
      }
    } else {
      for (let i = 0; i < 5; i++) {
        const a = i * 2.399;
        shape(g, leaf, 'broadleaf canopy', Math.cos(a) * 10 * size, (44 + i % 3 * 6) * size,
          Math.sin(a) * 10 * size, 28 * size, 30 * size, 29 * size,
          [0x597d43, 0x6c8950, 0x446b3e][i % 3], null, 0, 'lawn');
      }
    }
    return g;
  }
  function planter(root, x, y, z, w = 25, d = 14, id = null) {
    solid(root, 'stone planter', x, y + 3, z, w, 6, d, colors.stone, id);
    solid(root, 'planter soil', x, y + 6.2, z, w - 2, 1, d - 2, 0x514735, id);
    for (let i = -1; i <= 1; i++) shape(root, leaf, 'terrace shrub', x + i * w * .26,
      y + 11, z, w * .5, 10, d, 0x527c42, id, 0, 'lawn');
  }
  function railing(root, w, d, y, id) {
    for (const side of [-1, 1]) {
      solid(root, 'terrace bronze rail', 0, y + 10, side * (d / 2 - 2), w - 4, 1.3, 1.3, colors.bronze, id, 'metal');
      solid(root, 'terrace bronze rail', side * (w / 2 - 2), y + 10, 0, 1.3, 1.3, d - 4, colors.bronze, id, 'metal');
      for (let x = -w / 2 + 4; x <= w / 2 - 4; x += 26)
        solid(root, 'terrace rail post', x, y + 5, side * (d / 2 - 2), 1.1, 10, 1.1, colors.bronze, id, 'metal');
    }
  }
  function floor(root, d, index, w, depth, pitch, residential, podium) {
    const id = d.id, body = residential ? colors.stone : colors.glass;
    solid(root, 'floor volume', 0, pitch / 2, 0, w, pitch, depth, body, id, residential ? 'stone' : 'glass');
    const columns = Math.max(4, Math.round(w / (residential ? 30 : 24)));
    const sides = Math.max(3, Math.round(depth / 30));
    for (const side of [-1, 1]) {
      solid(root, 'horizontal stone floor band', 0, 1.4, side * (depth / 2 + 1), w + 3, 2.8, 3, podium ? colors.edge : colors.bronze, id);
      for (let j = 0; j < columns; j++) {
        const x = -w / 2 + (j + .5) * w / columns;
        const tint = (j * 7 + index * 3) % 11 === 0 ? 0x8b9b95 : (j + index) % 4 === 0 ? 0x5c8193 : colors.glass;
        if (residential) solid(root, 'residential window glass', x, pitch * .52, side * (depth / 2 + .7), w / columns * .7, pitch * .68, 1.2, tint, id, 'glass');
        else solid(root, 'window reflective pane', x, pitch * .52, side * (depth / 2 + .7), w / columns - 1.5, pitch - 4, 1.1, tint, id, 'glass');
        solid(root, 'window vertical bronze mullion', x - w / columns * .5, pitch * .5,
          side * (depth / 2 + 2), residential ? 3 : 1.2, pitch, 1.8, residential ? colors.edge : colors.bronze, id, 'metal');
      }
      for (let j = 0; j < sides; j++) {
        const z = -depth / 2 + (j + .5) * depth / sides;
        solid(root, 'side window glass', side * (w / 2 + .7), pitch * .52, z,
          1.1, pitch * .72, depth / sides * .82, colors.glass, id, 'glass');
        solid(root, 'side window stone mullion', side * (w / 2 + 2), pitch * .5,
          z - depth / sides * .5, 1.5, pitch, residential ? 3 : 1.3, colors.edge, id);
      }
      solid(root, 'side stone floor band', side * (w / 2 + 1), 1.4, 0, 3, 2.8, depth + 3, colors.edge, id);
      solid(root, 'facade corner pier', side * (w / 2 - 4), pitch / 2, depth / 2 + 2,
        residential ? 10 : 6, pitch, 5, colors.stone, id);
    }
  }
  function roof(root, d, w, depth, isMall, residential) {
    const id = d.id;
    box(root, 'beveled roof terrace cap', 0, 2, 0, w + 8, 4, depth + 8, colors.edge, id);
    railing(root, w + 8, depth + 8, 4, id);
    for (let i = -1; i <= 1; i++) {
      planter(root, i * w * .28, 4, depth * .36, w * .2, 13, id);
      solid(root, 'rooftop AC unit', i * w * .24, 10, -depth * .28, 18, 12, 16, 0x9caaa8, id, 'metal');
      shape(root, cylinder, 'AC fan', i * w * .24, 17, -depth * .28, 10, 1, 10, 0x384b51, id, 0, 'metal');
    }
    if (!isMall && !residential) {
      for (let i = 0; i < 4; i++) {
        const f = .62 - i * .11;
        box(root, 'setback roof crown', 0, 9 + i * 15, 0, w * f, 18, depth * f, i % 2 ? colors.glass : colors.stone, id);
        for (const side of [-1, 1]) solid(root, 'crown bronze fin', side * w * f * .48,
          12 + i * 15, depth * f * .5, 2, 22, 2, colors.bronze, id, 'metal');
      }
      shape(root, cylinder, 'skyscraper spire', 0, 104, 0, 3, 94, 3, colors.bronze, id, 0, 'metal');
    }
  }

  function build(root, d) {
    const mall = d.model === 'mall', tower = d.model === 'tower';
    const residential = ['house', 'villa', 'apartment'].includes(d.model);
    if (!mall && !tower && !residential && d.model !== 'supermart') return false;
    const flagship = d.id === 'mall';
    let base = mall ? (flagship ? 8 : 5) : tower ? ({ bank: 34, corp_tower: 32, office: 26, hospital: 16, college: 14 }[d.id] || d.floors || 22)
      : d.model === 'apartment' ? (d.floors || 9) : residential ? (d.model === 'villa' ? 3 : 2) : 3;
    const increment = mall ? 2 : tower ? 3 : 1, pitch = mall ? 28 : tower ? 23 : residential ? 20 : 24;
    const maximum = base + increment * ((d.max || 1) - 1);
    const width = mall ? (flagship ? 600 : 300) : tower ? (d.width || 155) : residential ? (d.width || (d.model === 'apartment' ? 142 : 120)) : 240;
    const depth = mall ? (flagship ? 360 : 205) : tower ? (d.depth || 135) : residential ? (d.depth || 118) : 165;
    const podium = new T.Group(); root.add(podium);
    solid(podium, 'paved building plaza', 0, 6, 14, width + 32, 12, depth + 72, 0xc9c2b3, d.id);
    for (const side of [-1, 1]) {
      solid(podium, 'landscaped plaza garden', side * (width / 2 + 11), 13,
        0, 13, 2, depth + 22, 0x60804c, d.id, 'lawn');
      for (let j = -1; j <= 1; j++) planter(podium, side * (width / 2 + 11), 13, j * depth * .3, 12, 20, d.id);
    }
    const floorGroups = [];
    for (let f = 0; f < maximum; f++) {
      const g = new T.Group(); g.position.y = 12 + f * pitch; root.add(g);
      const tier = mall ? Math.floor(f / 2) : tower ? Math.floor(Math.max(0, f - 3) / 7) : Math.floor(f / 5);
      const scale = Math.max(mall ? .6 : .66, Math.pow(mall ? .92 : .93, tier));
      const w = width * scale, dep = depth * scale;
      floor(g, d, f, w, dep, pitch, residential, f < 2);
      if ((mall && f % 2 === 1) || (tower && f > 2 && (f - 2) % 7 === 0)) {
        box(g, 'setback terrace slab', 0, pitch, 0, w + 10, 3, dep + 10, colors.edge, d.id);
        railing(g, w + 10, dep + 10, pitch, d.id);
        for (const side of [-1, 1]) for (let j = -1; j <= 1; j++)
          planter(g, j * w * .27, pitch + 2, side * dep * .46, w * .17, 10, d.id);
        stats.terraceFloors++;
      }
      floorGroups.push(g);
    }
    const roofGroup = new T.Group(); root.add(roofGroup);
    roof(roofGroup, d, width * .65, depth * .65, mall, residential);
    if (mall) {
      // Continuous curved glass barrel, framed in actual 3D, from the entrance
      // up across the stepped roof. The roof curve remains attached on upgrades.
      const atrium = new T.Group(); root.add(atrium);
      const aw = flagship ? 126 : 76, totalHeight = base * pitch;
      solid(atrium, 'atrium dark glass entrance', 0, totalHeight * .45 + 12, depth / 2 + 4,
        aw, totalHeight * .9, 3, 0x34677f, d.id, 'glass');
      for (let i = -3; i <= 3; i++) solid(atrium, 'atrium bronze vertical frame', i * aw / 7,
        totalHeight * .45 + 12, depth / 2 + 7, 2, totalHeight * .9, 2, colors.bronze, d.id, 'metal');
      for (let f = 0; f < base; f++) solid(atrium, 'atrium horizontal frame', 0, 12 + f * pitch,
        depth / 2 + 7, aw, 2, 2, colors.bronze, d.id, 'metal');
      const vault = new T.CylinderGeometry(aw / 2, aw / 2, depth * .61, 40, 1, true, 0, Math.PI);
      vault.rotateX(Math.PI / 2); vault.translate(0, 0, 0);
      const glassVault = new T.Mesh(vault, material(0x2d6586, 'glass'));
      glassVault.material = glassVault.material.clone();
      glassVault.material.side = T.DoubleSide;
      glassVault.material.color.setHex(0x317ca4);
      glassVault.material.envMapIntensity = .3;
      glassVault.material.emissive.setHex(0x18445f);
      glassVault.material.emissiveIntensity = .22;
      glassVault.name = 'curved mall skylight'; glassVault.rotation.z = Math.PI / 2;
      // Tube curves make clean curved roof ribs, with no faceted dome.
      glassVault.rotation.set(Math.PI / 2, 0, Math.PI / 2);
      glassVault.geometry.dispose();
      const positions = [], indices = [], normals = [];
      const samples = 40, length = depth * .62, radius = aw * .5;
      for (let j = 0; j <= 1; j++) for (let i = 0; i <= samples; i++) {
        const a = Math.PI * i / samples;
        positions.push(Math.cos(a) * radius, Math.sin(a) * radius, (j - .5) * length);
        normals.push(Math.cos(a), Math.sin(a), 0);
      }
      for (let i = 0; i < samples; i++) { const b = samples + 1 + i; indices.push(i, b, i + 1, i + 1, b, b + 1); }
      const geo = new T.BufferGeometry(); geo.setAttribute('position', new T.Float32BufferAttribute(positions, 3));
      geo.setAttribute('normal', new T.Float32BufferAttribute(normals, 3)); geo.setIndex(indices);
      glassVault.geometry = geo; glassVault.rotation.set(0, 0, 0);
      glassVault.position.set(0, 10, 0); roofGroup.add(glassVault);
      glassVault.userData.assetId = d.id; pickables.push(glassVault);
      for (let j = 0; j < 7; j++) {
        const points = [];
        for (let i = 0; i <= 24; i++) {
          const a = Math.PI * i / 24;
          points.push(new T.Vector3(Math.cos(a) * radius, 10 + Math.sin(a) * radius, -length / 2 + j * length / 6));
        }
        const rib = new T.Mesh(new T.TubeGeometry(new T.CatmullRomCurve3(points), 24, .9, 4, false), material(colors.edge, 'metal'));
        rib.name = 'curved skylight steel rib'; roofGroup.add(rib);
      }
      const title = flagship ? 'FLUX MALL' : d.name.toUpperCase();
      sign(podium, title, 0, 62, depth / 2 + 11, width * .49, 24, 0, d.id);
      for (const side of [-1, 1]) {
        const x = side * width * .34;
        solid(podium, 'retail poster stone surround', x, 107, depth / 2 + 3, 76, 144, 8, colors.stone, d.id);
        advert(podium, side < 0 ? 'STYLE' : 'LIVING', x, 123, depth / 2 + 8, 65, 100, d.id);
        sign(podium, side < 0 ? 'FASHION' : 'HOME', x, 57, depth / 2 + 9, 66, 25, 0, d.id);
        for (let j = -1; j <= 1; j++) tree(podium, side * (width / 2 + 8), j * depth * .34, flagship ? 1.12 : .75, 12, true);
      }
      for (let i = 0; i < 5; i++) solid(podium, 'mall entrance staircase', 0, 1 + i * 2.3,
        depth / 2 + 49 - i * 5, aw + 26, 2.3, 28, colors.edge, d.id);
      root.userData.atrium = atrium;
    } else if (tower) {
      solid(podium, 'tower entrance canopy', 0, 35, depth / 2 + 14, width * .7, 4, 30, colors.stone, d.id);
      sign(podium, d.name.toUpperCase(), 0, 42, depth / 2 + 3, width * .8, 15, 0, d.id);
      for (const side of [-1, 1]) tree(podium, side * width * .38, depth / 2 + 29, .55, 12, true);
    }
    root.userData.architecture = { base, increment, pitch, maximum, floorGroups, roofGroup, width, depth, level: 0 };
    update(root, 1); stats.tallAssets++;
    return true;
  }
  function update(root, level) {
    const a = root.userData.architecture; if (!a || a.level === level) return false;
    const active = Math.min(a.maximum, a.base + a.increment * Math.max(0, level - 1));
    a.floorGroups.forEach((g, i) => g.scale.setScalar(i < active ? 1 : .000001));
    a.roofGroup.position.y = 12 + active * a.pitch;
    if (root.userData.atrium) root.userData.atrium.scale.y = active / a.base;
    a.level = level; a.floors = active; a.height = 12 + active * a.pitch;
    return true;
  }

  function park(x, z) {
    const root = new T.Group(); root.position.set(x, 0, z); scene.add(root);
    solid(root, 'city park perimeter stone', 0, 8, 0, 580, 16, 420, 0xc5bdaa);
    solid(root, 'city park lawn', 0, 17, 0, 565, 2, 405, 0x2b3846, null, 'lawn');
    shape(root, cylinder, 'park circular promenade', 0, 20, 0, 265, 3, 265, 0xd6cbb1);
    shape(root, cylinder, 'park sunken garden', 0, 22, 0, 225, 2, 225, 0x7c925e, null, 0, 'lawn');
    shape(root, cylinder, 'fountain pool stone', 0, 26, 0, 95, 8, 95, colors.edge);
    shape(root, cylinder, 'fountain water', 0, 31, 0, 83, 1, 83, 0x65949c, null, 0, 'water');
    shape(root, cylinder, 'fountain pillar', 0, 45, 0, 15, 28, 15, colors.stone);
    for (const side of [-1, 1]) {
      solid(root, 'park path', 0, 20, side * 160, 565, 2, 17, 0xd6cbb1);
      for (let j = -3; j <= 3; j++) tree(root, j * 77, side * 185, .85, 20, j % 2 === 0);
    }
    for (let i = 0; i < 8; i++) {
      const a = i * Math.PI / 4;
      planter(root, Math.cos(a) * 141, 22, Math.sin(a) * 141, 30, 14);
    }
  }
  function streets() {
    for (let x = -650; x <= 1120; x += 125) {
      tree(scene, x, -742, 1.15, 10, true);
      if (Math.abs(x - 430) > 260) tree(scene, x, -959, 1.05, 10, true);
    }
    for (let z = -2180; z <= -500; z += 145) tree(scene, -747, z, 1.05, 10, true);
    // Pedestrians are mesh characters, not decals or a flattened scene image.
    for (let i = 0; i < 44; i++) {
      const x = -600 + ((i * 113) % 1720), z = i % 2 ? -748 : -958;
      const color = [0xd0d0bc, 0x263e56, 0x92634e, 0xb98247][i % 4];
      shape(scene, cylinder, 'pedestrian body', x, 20, z, 3.5, 9, 3.5, color);
      shape(scene, leaf, 'pedestrian head', x, 26, z, 4, 4, 4, 0xb8916b);
      for (const side of [-1, 1]) solid(scene, 'pedestrian leg', x + side, 13, z, 1, 6, 1.5, 0x344554);
    }
  }
  function backdrop(occupied = []) {
    const obstructions=occupied.map(l=>({...l}));
    const canvas = document.createElement('canvas'); canvas.width = 256; canvas.height = 512;
    const c = canvas.getContext('2d'); c.fillStyle = '#c2c5bd'; c.fillRect(0, 0, 256, 512);
    for (let row = 0; row < 16; row++) for (let col = 0; col < 6; col++) {
      c.fillStyle = (row * 13 + col * 7) % 5 ? '#7694a2' : '#9faaa8';
      c.fillRect(col * 42 + 8, row * 32 + 8, 26, 20);
      c.fillStyle = '#cbd0c7'; c.fillRect(col * 42 + 8, row * 32 + 8, 2, 20);
    }
    const texture = new T.CanvasTexture(canvas); texture.colorSpace = T.SRGBColorSpace;
    const mats = [0xbac1c7,0xd4d0bf,0xb2c3c9].map(color => new T.MeshStandardMaterial({map:texture,color,roughness:.83}));
    for (let row = 0; row < 7; row++) for (let col = 0; col < 34; col++) {
      const x = -3600 + col * 210 + row % 2 * 70;
      let z = -3320 - row * 220;
      const width=110+col%3*18,depth=100+col%4*12;
      while(obstructions.some(l=>Math.abs(x-l.x)<(width+l.width)/2+16 && Math.abs(z-l.z)<(depth+l.depth)/2+16))z-=220;
      obstructions.push({x,z,width,depth});
      const h = 80 + ((col * 17 + row * 29) % 18) * 16;
      const m = solid(scene, 'distant city building', x, h / 2, z,
        width, h, depth, 0x9faeb5);
      m.userData.backdropLot={x,z,width,depth};
      m.material = mats[col % 3];
      if ((col + row) % 3 === 0) tree(scene,x+70,z+78,.9,0);
      stats.backdropBuildings++;
    }
  }

  return { build, update, tree, planter, park, streets, backdrop, stats, sign };
}
