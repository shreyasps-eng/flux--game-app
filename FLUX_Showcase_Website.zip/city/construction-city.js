import * as T from './three.module.js';

// Construction uses shared, instanced geometry. No per-frame mesh rebuilding.
export const BUILD_STAGES = ['Site preparation', 'Structure', 'Finishing', 'Ready'];

export function constructionProgress(o, now = Date.now()) {
  if (o?.constructionEndAt) {
    const remainingMs = Math.max(0, o.constructionEndAt - now);
    const progress = Math.max(0, Math.min(1, 1 - remainingMs / Math.max(1, o.constructionDurationMs)));
    const stage = remainingMs ? Math.min(2, Math.floor(progress * 3)) : 3;
    return { stage, progress, name: BUILD_STAGES[stage], remainingMs };
  }
  if (!o || !o.daysLeft) return { stage: 3, progress: 1, name: BUILD_STAGES[3], remainingMs: 0 };
  const total = Math.max(o.daysLeft, o.constructionTotal || o.daysLeft);
  const progress = Math.max(0, Math.min(1, (total - o.daysLeft) / total));
  const stage = Math.min(2, Math.floor(progress * 3));
  return { stage, progress, name: BUILD_STAGES[stage] };
}

export function createConstructionSites(graphics, architecture) {
  const cube = new T.BoxGeometry(1, 1, 1);
  const wheel = new T.CylinderGeometry(.5, .5, 1, 10);
  const hiddenScale = .000001;
  const put = (g, name, x, y, z, w, h, d, color, id) =>
    graphics.shape(g, cube, name, x, y, z, w, h, d, color, id);

  function attach(item, footprint) {
    const { root, mark, def } = item;
    const building = new T.Group(); building.name = 'Completed building';
    for (const child of [...root.children]) if (child !== mark && child.name !== 'land survey') building.add(child);
    // Some parking/tree details originally had no ID. They must follow the
    // same asset when their instance transforms change during construction.
    building.traverse(m => { if (m.isMesh) m.userData.assetId = def.id; });
    root.add(building);
    const site = new T.Group(); site.name = 'Player construction site'; root.add(site);
    const preparation = new T.Group(), structure = new T.Group(), crane = new T.Group();
    site.add(preparation, structure, crane);
    const w = Math.min(footprint[0] - 20, root.userData.architecture?.width || footprint[0] * .76);
    const dep = Math.min(footprint[1] - 20, root.userData.architecture?.depth || footprint[1] * .7);
    const id = def.id;
    put(site, 'construction dirt pad', 0, 1, 0, w + 12, 2, dep + 12, 0x9c805e, id);
    for (const side of [-1, 1]) {
      put(site, 'construction safety fence', side * (w / 2 + 8), 9, 0, 3, 16, dep + 16, 0xdaaa46, id);
      put(site, 'construction safety fence', 0, 9, side * (dep / 2 + 8), w + 16, 16, 3, 0xcca144, id);
    }
    put(preparation, 'concrete foundation slab', 0, 5, 0, w, 7, dep, 0xb4afa4, id);
    for (const side of [-1, 1]) for (const end of [-1, 1])
      put(preparation, 'foundation rebar', side * w * .42, 17, end * dep * .42, 4, 27, 4, 0x53616a, id);
    const excavator = new T.Group(); excavator.position.set(-w * .23, 0, dep * .2); preparation.add(excavator);
    put(excavator, 'excavator tracks', 0, 6, 0, 36, 10, 24, 0x354450, id);
    put(excavator, 'excavator cabin', -5, 19, 0, 19, 20, 18, 0xdda638, id);
    put(excavator, 'excavator glass', -5, 21, 10, 13, 10, 2, 0x456b7d, id);
    const arm = put(excavator, 'excavator arm', 23, 26, 0, 36, 6, 6, 0xd6a034, id);
    arm.rotation.z = -.48;
    put(excavator, 'excavator bucket', 42, 12, 0, 10, 12, 14, 0x778286, id);
    // The structure's local height is one unit. Its group grows to the target
    // height, so columns and floor slabs can share geometry across all plots.
    for (const side of [-1, 1]) for (const end of [-1, 0, 1])
      put(structure, 'construction steel column', side * w * .43, .5, end * dep * .43, 7, 1, 7, 0x899390, id);
    const slabs=[],maximumSiteFloors=def.kind==='land'?64:root.userData.architecture?.maximum||8;
    for (let f = 0; f <= maximumSiteFloors; f++) {
      const taper = Math.max(.7,1-f/maximumSiteFloors*.25);
      slabs.push(put(structure, 'unfinished concrete floor', 0, f / maximumSiteFloors, 0, w * taper, .008, dep * taper, 0xbcb6a9, id));
    }
    const craneX = w * .38, craneZ = -dep * .38;
    put(crane, 'tower crane mast', craneX, .5, craneZ, 6, 1, 6, 0xe0b24e, id);
    put(crane, 'tower crane beam', craneX - w * .25, .98, craneZ, w * .7, .012, 5, 0xe0b24e, id);
    put(crane, 'tower crane cable', craneX - w * .47, .76, craneZ, 1.5, .43, 1.5, 0x47545c, id);
    put(crane, 'tower crane load', craneX - w * .47, .54, craneZ, 18, .026, 12, 0x8f999b, id);
    // Small workers at ground level make the active building site legible.
    for (let n = 0; n < 3; n++) {
      const x = (n - 1) * 22, z = dep * .36;
      put(site, 'construction worker jacket', x, 11, z, 5, 8, 4, 0xe2a149, id);
      graphics.shape(site, wheel, 'construction worker helmet', x, 17, z, 6, 3, 6, 0xf1d271, id);
      put(site, 'construction worker legs', x, 4, z, 4, 7, 3, 0x294154, id);
    }
    site.scale.setScalar(hiddenScale);
    item.construction = { building, site, preparation, structure, crane, slabs, width:w, depth:dep, key: '', stage: 3 };
  }

  function update(item, owned) {
    const c = item.construction;
    const { stage } = constructionProgress(owned);
    const working = !!(owned?.daysLeft || owned?.constructionEndAt);
    const targetLevel = owned?.targetLevel || owned?.level || 1;
    const isUpgrade = owned?.constructionKind === 'upgrade';
    const shownLevel = working && stage < 2 && isUpgrade ? owned.level : targetLevel;
    let changed = architecture.update(item.root, shownLevel);
    const key = [working, stage, shownLevel, isUpgrade].join(':');
    if (key === c.key) return changed;
    c.key = key; c.stage = stage;
    c.site.scale.setScalar(working ? 1 : hiddenScale);
    c.building.scale.setScalar(item.def.kind === 'land' && (!owned || owned.landOnly) ? hiddenScale : !working || isUpgrade || stage >= 2 ? 1 : hiddenScale);
    c.preparation.scale.setScalar(working && stage === 0 ? 1 : hiddenScale);
    const a = item.root.userData.architecture;
    const fullHeight = a ? 12 + Math.min(a.maximum, a.base + a.increment * (targetLevel - 1)) * a.pitch
      : Math.max(item.root.userData.modelHeight || 100, (item.root.userData.majorTiers?.base || 80) + 23 * targetLevel);
    const baseHeight = isUpgrade ? a ? 12 + (a.base + a.increment * (owned.level - 1)) * a.pitch
      : Math.max(item.root.userData.modelHeight || 100,(item.root.userData.majorTiers?.base || 80)+23*owned.level) : 6;
    const workHeight = Math.max(24, fullHeight - baseHeight);
    const targetFloors=a?Math.min(a.maximum,a.base+a.increment*(targetLevel-1)):3+targetLevel-1;
    const previousFloors=a?a.base+a.increment*((owned?.level||1)-1):3+(owned?.level||1)-1;
    const frameFloors=Math.max(1,Math.min(c.slabs.length-1,isUpgrade?targetFloors-previousFloors:targetFloors));
    c.slabs.forEach((m,i)=>{
      if(i<=frameFloors){const taper=1-i/frameFloors*.25;m.position.y=i/frameFloors;m.scale.set(c.width*taper,.008,c.depth*taper);}
      else m.scale.setScalar(hiddenScale);
      m.updateMatrix();
    });
    c.structure.position.y = baseHeight;
    // The land survey/fence stays full size. A player building's foundations
    // and crane footprint follow its selected blueprint rather than the parcel.
    const selectedWidth=a?a.width:item.def.model==='airport'?600:item.def.model==='factory'?320:item.def.model==='shipyard'?420:180;
    const selectedDepth=a?a.depth:item.def.model==='airport'?860:item.def.model==='factory'?280:item.def.model==='shipyard'?350:190;
    const sx=item.def.kind==='land'?Math.min(1,selectedWidth/c.width):1;
    const sz=item.def.kind==='land'?Math.min(1,selectedDepth/c.depth):1;
    c.structure.scale.set(sx, working && stage === 1 ? workHeight : hiddenScale, sz);
    // Scale all axes to remove inactive slabs as well as their height.
    if (!working || stage !== 1) c.structure.scale.setScalar(hiddenScale);
    c.crane.scale.set(sx, Math.max(60, fullHeight + 35), sz);
    if (!working) c.crane.scale.setScalar(hiddenScale);
    return true;
  }
  return { attach, update };
}
