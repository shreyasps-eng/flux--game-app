import * as T from './three.module.js';
import { installSpecularLighting } from './specular-lighting.js';

export const QUALITY_PRESETS = Object.freeze({
  fast: { buildingSegments: 4, radialSegments: 16, roadStep: 64, pixelRatio: 1, shadowSize: 512 },
  mobile: { buildingSegments: 4, radialSegments: 24, roadStep: 50, pixelRatio: 1, shadowSize: 1024 },
  balanced: { buildingSegments: 6, radialSegments: 32, roadStep: 48, pixelRatio: 1, shadowSize: 1024 },
  high: { buildingSegments: 8, radialSegments: 40, roadStep: 35, pixelRatio: 1.25, shadowSize: 1024 },
  ultra: { buildingSegments: 12, radialSegments: 64, roadStep: 25, pixelRatio: 1.5, shadowSize: 2048 }
});

// Subdivisions are concentrated around the bevel instead of wasting all of
// them on flat walls. Analytic normals remain continuous across face seams.
export function beveledBoxGeometry(segments = 12, radius = 0.075) {
  const g = new T.BoxGeometry(1, 1, 1, segments, segments, segments);
  const p = g.attributes.position, n = g.attributes.normal;
  const edgeCells = Math.max(2, Math.floor(segments / 4));
  const inner = 0.5 - radius;
  function redistribute(value) {
    const i = (value + 0.5) * segments;
    if (i < edgeCells) return -0.5 + radius * i / edgeCells;
    if (i > segments - edgeCells) return 0.5 - radius * (segments - i) / edgeCells;
    return -inner + 2 * inner * (i - edgeCells) / (segments - 2 * edgeCells);
  }
  const point = new T.Vector3(), inside = new T.Vector3(), normal = new T.Vector3();
  for (let i = 0; i < p.count; i++) {
    point.set(redistribute(p.getX(i)), redistribute(p.getY(i)), redistribute(p.getZ(i)));
    inside.copy(point).clampScalar(-inner, inner);
    normal.subVectors(point, inside).normalize();
    point.copy(inside).addScaledVector(normal, radius);
    p.setXYZ(i, point.x, point.y, point.z);
    n.setXYZ(i, normal.x, normal.y, normal.z);
  }
  g.computeBoundingBox(); g.computeBoundingSphere();
  g.userData = { style: 'subdivided-beveled', subdivisions: segments };
  return g;
}

export function subdividedRoofGeometry(segments = 12) {
  // Extrude a gable profile: caps stay crisp while both sloping roof planes
  // receive longitudinal subdivisions for tile ribs and smooth silhouettes.
  const profile = new T.Shape();
  profile.moveTo(-0.5, -0.5); profile.lineTo(0.5, -0.5);
  profile.lineTo(0, 0.5); profile.closePath();
  const g = new T.ExtrudeGeometry(profile, {
    depth: 1, steps: segments, bevelEnabled: true,
    bevelSegments: 3, bevelThickness: 0.012, bevelSize: 0.012, curveSegments: segments
  });
  g.translate(0, 0, -0.5);
  return g;
}

export function roundedRectangleCurve(x0, z0, x1, z1, radius = 200) {
  radius = Math.min(radius, (x1 - x0) / 2, (z1 - z0) / 2);
  const curve = new T.CurvePath();
  const v = (x, z) => new T.Vector3(x, 12, z);
  const line = (a, b) => curve.add(new T.LineCurve3(v(...a), v(...b)));
  const bend = (a, c, b) => curve.add(new T.QuadraticBezierCurve3(v(...a), v(...c), v(...b)));
  line([x0 + radius, z0], [x1 - radius, z0]);
  bend([x1 - radius, z0], [x1, z0], [x1, z0 + radius]);
  line([x1, z0 + radius], [x1, z1 - radius]);
  bend([x1, z1 - radius], [x1, z1], [x1 - radius, z1]);
  line([x1 - radius, z1], [x0 + radius, z1]);
  bend([x0 + radius, z1], [x0, z1], [x0, z1 - radius]);
  line([x0, z1 - radius], [x0, z0 + radius]);
  bend([x0, z0 + radius], [x0, z0], [x0 + radius, z0]);
  curve.userData = { closed: true };
  return curve;
}

// Sweep a flat road ribbon over an arc-length-sampled centerline. This avoids
// both square road blocks and uneven triangle spacing around bends.
export function ribbonGeometry(curve, width, segments, y = 12, offset = 0, across = 4, start = 0, end = 1) {
  const positions = [], uvs = [], indices = [];
  const point = new T.Vector3(), tangent = new T.Vector3();
  const length = curve.getLength();
  for (let i = 0; i <= segments; i++) {
    const t = start + (end - start) * i / segments;
    curve.getPointAt(t, point); curve.getTangentAt(t, tangent);
    const side = new T.Vector3(-tangent.z, 0, tangent.x).normalize();
    for (let j = 0; j <= across; j++) {
      const lateral = offset + width * (j / across - 0.5);
      positions.push(point.x + side.x * lateral, y, point.z + side.z * lateral);
      uvs.push(j / across, t * length / 100);
    }
  }
  for (let i = 0; i < segments; i++) {
    for (let j = 0; j < across; j++) {
      const a = i * (across + 1) + j, b = a + across + 1;
      indices.push(a, a + 1, b, a + 1, b + 1, b); // positive Y normals
    }
  }
  const g = new T.BufferGeometry();
  g.setAttribute('position', new T.Float32BufferAttribute(positions, 3));
  g.setAttribute('uv', new T.Float32BufferAttribute(uvs, 2));
  g.setIndex(indices); g.computeVertexNormals(); g.computeBoundingSphere();
  return g;
}

function joinGeometries(parts) {
  const positions = [], normals = [], uvs = [], indices = [];
  let vertexOffset = 0;
  for (const g of parts) {
    positions.push(...g.attributes.position.array); normals.push(...g.attributes.normal.array);
    uvs.push(...g.attributes.uv.array);
    for (const index of g.index.array) indices.push(vertexOffset + index);
    vertexOffset += g.attributes.position.count;
    g.dispose();
  }
  const g = new T.BufferGeometry();
  g.setAttribute('position', new T.Float32BufferAttribute(positions, 3));
  g.setAttribute('normal', new T.Float32BufferAttribute(normals, 3));
  g.setAttribute('uv', new T.Float32BufferAttribute(uvs, 2));
  g.setIndex(indices); g.computeBoundingSphere();
  return g;
}

function noiseTexture() {
  const data = new Uint8Array(128 * 128 * 4);
  let seed = 1265;
  for (let i = 0; i < data.length; i += 4) {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    const value = 180 + (seed >>> 26);
    data[i] = data[i + 1] = data[i + 2] = value; data[i + 3] = 255;
  }
  const texture = new T.DataTexture(data, 128, 128);
  texture.wrapS = texture.wrapT = T.RepeatWrapping;
  texture.magFilter = T.LinearFilter; texture.minFilter = T.LinearMipmapLinearFilter;
  texture.generateMipmaps = true; texture.needsUpdate = true;
  return texture;
}

export function createHighPolyCity(scene, renderer, pickables, qualityName = 'high') {
  const quality = QUALITY_PRESETS[qualityName] || QUALITY_PRESETS.high;
  const rounded = beveledBoxGeometry(quality.buildingSegments);
  const detailBox = beveledBoxGeometry(8, 0.035);
  const flatBox = new T.BoxGeometry(1, 1, 1);
  const cylinder = new T.CylinderGeometry(0.5, 0.5, 1, quality.radialSegments, 8);
  const wheelGeometry = new T.CylinderGeometry(0.5, 0.5, 1, quality.radialSegments, 1);
  const hubGeometry = new T.CylinderGeometry(0.5, 0.5, 1, 32, 1);
  const sphere = new T.SphereGeometry(0.5, quality.radialSegments / 2, 20);
  const textures = { noise: noiseTexture() };
  const materials = new Map(), waterMaterials = [], batches = [];
  const roads = [], traffic = [];
  const stats = { quality: qualityName, buildingSubdivisions: quality.buildingSegments,
    cylinderSegments: quality.radialSegments, roads: 0, batchedObjects: 0, instanceBatches: 0 };

  renderer.setPixelRatio(Math.min(globalThis.devicePixelRatio || 1, quality.pixelRatio));
  renderer.toneMapping = T.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;
  renderer.outputColorSpace = T.SRGBColorSpace;

  function environment() {
    // Offline reflection source: sky, horizon and stylized skyline. It is a
    // material texture, not a static background substituting for the city.
    const c = document.createElement('canvas'); c.width = 512; c.height = 256;
    const ctx = c.getContext('2d');
    const gradient = ctx.createLinearGradient(0, 0, 0, 256);
    gradient.addColorStop(0, '#7999bd'); gradient.addColorStop(0.45, '#dbe7ec');
    gradient.addColorStop(0.53, '#f9e4c5'); gradient.addColorStop(0.65, '#68817d');
    gradient.addColorStop(1, '#273538'); ctx.fillStyle = gradient; ctx.fillRect(0, 0, 512, 256);
    for (let i = 0; i < 38; i++) {
      ctx.fillStyle = i % 2 ? '#809293' : '#556c77';
      const h = 6 + ((i * 37) % 29);
      ctx.fillRect(i * 14, 143 - h, 9, h);
    }
    const sky = new T.CanvasTexture(c); sky.mapping = T.EquirectangularReflectionMapping;
    sky.colorSpace = T.SRGBColorSpace;
    const pmrem = new T.PMREMGenerator(renderer);
    const target = pmrem.fromEquirectangular(sky);
    scene.environment = target.texture; scene.userData.environmentTarget = target;
    sky.dispose(); pmrem.dispose();
  }
  environment();

  function material(color, kind = 'stone') {
    const key = color.toString(16) + ':' + kind;
    if (materials.has(key)) return materials.get(key);
    const profiles = {
      stone: { roughness: 0.72, metalness: 0.015, envMapIntensity: 0.3 },
      glass: { roughness: 0.17, metalness: 0.3, clearcoat: .6, clearcoatRoughness: 0.1, envMapIntensity: .65, specularIntensity: .7 },
      metal: { roughness: 0.27, metalness: 0.72, envMapIntensity: 0.8 },
      paint: { roughness: 0.29, metalness: 0.13, clearcoat: 0.8, clearcoatRoughness: 0.17 },
      roof: { roughness: 0.6, metalness: 0.12, envMapIntensity: 0.45 },
      asphalt: { roughness: 0.88, metalness: 0, bumpMap: textures.noise, bumpScale: 0.22, envMapIntensity: 0.2 },
      lawn: { roughness: 0.98, metalness: 0, envMapIntensity: 0.1 },
      light: { roughness: 0.4, metalness: 0.12, emissive: color, emissiveIntensity: 0.22 },
      water: { roughness: 0.19, metalness: 0.24, clearcoat: 0.8, clearcoatRoughness: 0.13, envMapIntensity: 1.1 }
    };
    const physical = ['glass', 'paint', 'water'].includes(kind);
    const m = physical ? new T.MeshPhysicalMaterial({ color, ...profiles[kind] })
      : new T.MeshStandardMaterial({ color, ...(profiles[kind] || profiles.stone) });
    if (['glass', 'paint', 'metal', 'water'].includes(kind)) installSpecularLighting(m, kind === 'glass' ? 0.16 : 0.09);
    if (kind === 'water') {
      const previous = m.onBeforeCompile;
      m.onBeforeCompile = shader => {
        previous(shader);
        shader.uniforms.uFluxTime = { value: 0 };
        shader.vertexShader = shader.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vFluxWaterPosition;')
          .replace('#include <begin_vertex>', '#include <begin_vertex>\nvFluxWaterPosition = position;');
        shader.fragmentShader = shader.fragmentShader.replace('#include <common>', '#include <common>\nuniform float uFluxTime;\nvarying vec3 vFluxWaterPosition;')
          .replace('#include <normal_fragment_maps>', '#include <normal_fragment_maps>\n' +
            'normal = normalize(normal + vec3(0.035 * sin(vFluxWaterPosition.x * 0.07 + uFluxTime), 0.028 * cos(vFluxWaterPosition.z * 0.09 + uFluxTime * 0.7), 0.0));');
        m.userData.shader = shader;
      };
      m.customProgramCacheKey = () => 'flux-water-ggx-v1'; waterMaterials.push(m);
    }
    materials.set(key, m); return m;
  }

  function classify(name) {
    if (/water|river|basin/.test(name)) return 'water';
    if (/glass|window|atrium|tower cabin/.test(name)) return 'glass';
    if (/asphalt|runway|parking$|land$|base$/.test(name)) return 'asphalt';
    if (/garden|tree crown|palm leaf/.test(name)) return 'lawn';
    if (/roof|canopy/.test(name)) return 'roof';
    if (/body/.test(name) && /car|bus|plane/.test(name)) return 'paint';
    if (/pole|arm|beam|crane|rail|frame|mullion|vent|chimney|steel|antenna/.test(name)) return 'metal';
    if (/light head|headlight|taillight/.test(name)) return 'light';
    return 'stone';
  }

  function mesh(parent, geo, name, x, y, z, sx, sy, sz, color, assetId = null, yaw = 0, kind = classify(name)) {
    const m = new T.Mesh(geo, material(color, kind));
    m.name = name; m.position.set(x, y, z); m.scale.set(sx, sy, sz); m.rotation.y = yaw;
    m.castShadow = (sy > 4 && sx > 4 && sz > 4 && !['water', 'lawn', 'light'].includes(kind)) || (/canopy|foliage/.test(name) && sx > 15); m.receiveShadow = kind !== 'light';
    if (assetId) { m.userData.assetId = assetId; pickables.push(m); }
    parent.add(m); return m;
  }
  function box(parent, name, x, y, z, sx, sy, sz, color, assetId = null, yaw = 0) {
    const big = sy > 32 && sx > 40 && sz > 40;
    const tiny = Math.min(sx, sy, sz) < 4 || Math.max(sx, sy, sz) > 1500;
    return mesh(parent, tiny ? flatBox : big ? rounded : detailBox, name, x, y, z, sx, sy, sz, color, assetId, yaw);
  }
  function shape(...args) { return mesh(...args); }

  function water(parent, name, x, z, width, depth, y = -1.5) {
    const g = new T.PlaneGeometry(width, depth, 64, 32); g.rotateX(-Math.PI / 2);
    const m = new T.Mesh(g, material(0x0288D1, 'water')); m.name = name; m.position.set(x, y, z);
    m.renderOrder = -1;
    if (m.material) {
      m.material.depthWrite = true;
      m.material.depthTest = true;
    }
    m.receiveShadow = true; parent.add(m); return m;
  }

  function tree(parent, x, z, s = 1) {
    shape(parent, cylinder, 'tree trunk', x, 18 * s, z, 7 * s, 36 * s, 7 * s, 0x70523d);
    for (let i = 0; i < 3; i++) {
      shape(parent, sphere, 'tree crown', x + (i - 1) * 9 * s, (47 + i * 9) * s,
        z + (i % 2 ? 8 : -5) * s, 40 * s, 45 * s, 38 * s, [0x2E7D32, 0x388E3C, 0x4CAF50][i]);
    }
  }

  function streetPoints(x, z, len, vertical) {
    // Original junction coordinates stay exact. Between junctions, the spline
    // bends gently within its corridor rather than cutting through city lots.
    const nodes = vertical ? [-2320, -850, 620, 1990, 3160] : [-4520, -2750, -850, 1250, 3050, 4250];
    const center = vertical ? z : x, lo = center - len / 2, hi = center + len / 2;
    const anchors = [lo, ...nodes.filter(n => n > lo && n < hi), hi];
    const points = [];
    anchors.forEach((a, i) => {
      points.push(new T.Vector3(vertical ? x : a, 12, vertical ? a : z));
      if (i < anchors.length - 1) {
        const mid = (a + anchors[i + 1]) / 2, bend = 0;
        points.push(new T.Vector3(vertical ? x + bend : mid, 12, vertical ? mid : z + bend));
      }
    });
    return points;
  }

  function curvedRoad(curve, width = 96, name = 'curved boulevard') {
    const segments = Math.max(32, Math.ceil(curve.getLength() / quality.roadStep));
    curve.arcLengthDivisions = Math.max(600, segments * 2); curve.updateArcLengths();
    const surface = (w, y, offset, color, kind, label, offsetFactor = -1) => {
      const mat = material(color, kind);
      mat.polygonOffset = true;
      mat.polygonOffsetFactor = offsetFactor;
      mat.polygonOffsetUnits = offsetFactor;
      const m = new T.Mesh(ribbonGeometry(curve, w, segments, y, offset), mat);
      m.name = name + ' ' + label; m.receiveShadow = true; scene.add(m); return m;
    };
    surface(width + 56, 10.2, 0, 0xCFD8DC, 'stone', 'sidewalk', -1);
    surface(width, 11.2, 0, 0x455A64, 'asphalt', 'asphalt', -2);
    for (const side of [-1, 1]) {
      surface(5, 11.8, side * (width / 2 + 2), 0xeee4ce, 'stone', 'curb', -3);
      surface(2, 11.6, side * (width / 2 - 6), 0xe7e5d7, 'stone', 'edge marking', -3);
    }
    surface(2.5, 12.1, 2.4, 0xebc45b, 'stone', 'center line', -4);
    surface(2.5, 12.1, -2.4, 0xebc45b, 'stone', 'center line', -4);
    const dashParts = [], length = curve.getLength();
    for (let d = 35; d + 38 < length; d += 88) {
      for (const side of [-1, 1]) dashParts.push(ribbonGeometry(curve, 3, 3, 12.2, side * width * 0.26, 1, d / length, (d + 38) / length));
    }
    if (dashParts.length) {
      const dashMat = material(0xedeadf, 'stone').clone();
      dashMat.polygonOffset = true;
      dashMat.polygonOffsetFactor = -5;
      dashMat.polygonOffsetUnits = -5;
      const dashes = new T.Mesh(joinGeometries(dashParts), dashMat);
      dashes.name = name + ' dashed lane markings'; scene.add(dashes);
    }
    roads.push({ curve, width, name }); stats.roads = roads.length;
    return curve;
  }
  function road(x, z, len, vertical, width) {
    return curvedRoad(new T.CatmullRomCurve3(streetPoints(x, z, len, vertical), false, 'centripetal'), width);
  }

  function facade(root, d, width, height, depth, floors, columns = 6, baseY = 8) {
    const rowHeight = height / floors, colWidth = width / columns;
    for (let floor = 0; floor < floors; floor++) {
      const y = baseY + rowHeight * (floor + 0.55);
      for (const side of [-1, 1]) {
        for (let col = 0; col < columns; col++) {
          const x = -width / 2 + colWidth * (col + 0.5);
          box(root, 'facade window', x, y, side * (depth / 2 + 1.3), colWidth * 0.72, rowHeight * 0.63, 2.8,
            (col + floor) % 4 === 0 ? 0x709798 : 0x3e7185, d.id);
        }
        box(root, 'facade floor ledge', 0, baseY + rowHeight * (floor + 1), side * (depth / 2 + 3), width + 8, 2.5, 8, 0xc7d1ce, d.id);
      }
      for (const side of [-1, 1]) {
        for (let col = 0; col < 3; col++) {
          const z = -depth / 2 + depth / 3 * (col + 0.5);
          box(root, 'side facade glass', side * (width / 2 + 1), y, z, 2.8, rowHeight * 0.63, depth / 3 * 0.68, 0x3e7185, d.id);
        }
      }
    }
    for (const side of [-1, 1]) for (let col = 0; col <= columns; col++) {
      const x = -width / 2 + colWidth * col;
      box(root, 'aluminum mullion', x, baseY + height / 2, side * (depth / 2 + 4), 2, height, 3, 0x9fb5bd, d.id);
    }
  }

  function roofEquipment(root, d, y, width = 120, depth = 95) {
    for (let i = -1; i <= 1; i++) {
      box(root, 'roof ventilation unit', i * width * 0.26, y + 5, depth * 0.16, 22, 10, 17, 0x91a2a5, d.id);
      shape(root, cylinder, 'circular roof vent', i * width * 0.26, y + 11, depth * 0.16, 10, 3, 10, 0x324c58, d.id);
    }
    box(root, 'solar glass panel', 0, y + 3, -depth * 0.23, width * 0.7, 2, depth * 0.25, 0x244459, d.id);
  }

  function enrichAsset(root, d) {
    const id = d.id;
    if (['house', 'villa'].includes(d.model)) {
      // Balconies, framed glazing, gutters, roof tile ribs, steps and gardens.
      for (const side of [-1, 1]) {
        for (let i = -1; i <= 1; i++) {
          box(root, 'side window frame', side * 59, 32, i * 32, 3, 23, 23, 0xf0e7d2, id);
          box(root, 'side window glass', side * 61, 32, i * 32, 2, 18, 17, 0x4b7f95, id);
        }
        box(root, 'roof gutter', side * 64, 54, 0, 3, 4, 130, 0x526d73, id);
      }
      for (let i = -5; i <= 5; i++) {
        const rib = box(root, 'terracotta tile rib', i * 11, 88 - Math.abs(i * 11) * 0.55, 0, 2.5, 3, 129, 0x955542, id);
        rib.rotation.z = i < 0 ? 0.5 : -0.5;
      }
      for (let i = 0; i < 3; i++) box(root, 'entry step', 0, 2 + i * 2, -89 + i * 5, 48, 4, 11, 0xd4d2c5, id);
      box(root, 'garden path', 0, 1.2, -102, 30, 1, 40, 0xc5bba6, id);
      for (const x of [-73, 73]) {
        box(root, 'planter', x, 5, -52, 17, 10, 24, 0xd8c8ab, id);
        shape(root, sphere, 'tree crown', x, 18, -52, 26, 23, 28, 0x4c814d, id);
      }
      if (d.model === 'villa') {
        box(root, 'villa balcony slab', 0, 48, 56, 96, 5, 35, 0xe8ddc5, id);
        box(root, 'balcony glass rail', 0, 58, 74, 96, 17, 2, 0x78a9b0, id);
      }
    } else if (['tower', 'apartment'].includes(d.model)) {
      const h = d.model === 'tower' ? 230 : 152, w = d.model === 'tower' ? 115 : 130, depth = d.model === 'tower' ? 105 : 120;
      facade(root, d, w, h - 20, depth, d.model === 'tower' ? 10 : 7, 6, 10);
      box(root, 'tower crown cap', 0, h + 7, 0, w + 10, 9, depth + 10, 0xc4ceca, id);
      roofEquipment(root, d, h + 12, w, depth);
      shape(root, cylinder, 'rooftop antenna', w * 0.35, h + 40, depth * 0.27, 2, 55, 2, 0x8a9da4, id);
      box(root, 'entry glass portal', 0, 16, -depth / 2 - 16, 44, 32, 24, 0x376c7d, id);
    } else if (['mall', 'supermart', 'shop'].includes(d.model)) {
      const mall = d.model === 'mall', shop = d.model === 'shop';
      const width = mall ? 330 : shop ? 145 : 240, depth = mall ? 210 : shop ? 118 : 170, h = mall ? 76 : shop ? 62 : 76;
      facade(root, d, width, h - 10, depth, mall ? 3 : 2, shop ? 5 : 9, 4);
      roofEquipment(root, d, mall ? 116 : h + 4, width * 0.6, depth * 0.65);
      for (let i = -1; i <= 1; i++) {
        shape(root, cylinder, 'entry steel column', i * width * 0.2, 25, -depth / 2 - 22, 5, 50, 5, 0xb2c2bc, id);
      }
      if (mall) {
        const dome = new T.SphereGeometry(1, quality.radialSegments, 24, 0, Math.PI * 2, 0, Math.PI / 2);
        shape(root, dome, 'glass atrium dome', 0, 124, 28, 68, 30, 65, 0x68a3b4, id);
        for (let i = -3; i <= 3; i++) box(root, 'atrium steel frame', i * 17, 130, 28, 2, 3, 130, 0xbdced0, id);
      }
    } else if (d.model === 'factory' || d.model === 'shipyard') {
      const shipyard = d.model === 'shipyard';
      for (let i = -6; i <= 6; i++) box(root, 'corrugated steel rib', i * 18, 35, shipyard ? -112 : -92, 2, 66, 3, 0x8e9f9b, id);
      if (!shipyard) for (let i = -2; i <= 0; i++) {
        shape(root, cylinder, 'storage tank', 105 + i * 50, 31, 119, 38, 62, 38, 0xbdc8c5, id);
        shape(root, sphere, 'metal tank dome', 105 + i * 50, 61, 119, 38, 16, 38, 0xbdc8c5, id);
      }
    } else if (d.model === 'airport') {
      for (let i = -6; i <= 6; i++) box(root, 'terminal aluminum mullion', 155 + i * 19, 44, -158, 2.5, 72, 6, 0xc8d6d5, id);
      const g = new T.CylinderGeometry(1, 1, 1, quality.radialSegments, 8, false, 0, Math.PI);
      const vault = shape(root, g, 'terminal curved roof', 155, 90, -70, 38, 296, 93, 0xc6d9d7, id);
      vault.rotation.z = Math.PI / 2;
      for (let i = -1; i <= 1; i++) {
        box(root, 'passenger glass jet bridge', 155 + i * 75, 22, -204, 29, 22, 95, 0x79aabb, id);
      }
      roofEquipment(root, d, 110, 120, 80);
    } else if (d.model === 'market') {
      for (let i = -2; i <= 2; i++) {
        for (const z of [-28, 28]) shape(root, cylinder, 'market steel post', i * 46, 23, z, 2.5, 46, 2.5, 0x899c9a, id);
        for (let j = -1; j <= 1; j++) shape(root, sphere, 'market produce', i * 46 + j * 9, 26, -27, 7, 7, 7, d.id === 'flowermarket' ? 0xe9a276 : 0x84aa4f, id);
      }
    }
  }

  function vehicleDetails(root, type = 'car', assetId = null) {
    const length = type === 'bus' ? 60 : 34, width = type === 'bus' ? 24 : 18;
    for (const x of [-length * 0.3, length * 0.3]) for (const z of [-width / 2, width / 2]) {
      const wheel = shape(root, wheelGeometry, 'rubber wheel', x, -7, z, 9, 3, 9, 0x263139, assetId);
      wheel.rotation.x = Math.PI / 2;
      const hub = shape(root, hubGeometry, 'steel wheel hub', x, -7, z * 1.14, 4, 1, 4, 0xc3cccd, assetId);
      hub.rotation.x = Math.PI / 2;
    }
    for (const z of [-width * 0.3, width * 0.3]) {
      box(root, 'headlight', length / 2 + 0.2, 1, z, 1, 3, 4, 0xffefcd, assetId);
      box(root, 'taillight', -length / 2 - 0.2, 1, z, 1, 3, 4, 0xda5340, assetId);
    }
    if (type === 'bus') for (let i = -3; i <= 3; i++) for (const z of [-12.5, 12.5]) {
      box(root, 'bus side glass', i * 7, 7, z, 5.5, 9, 1.5, 0x397586, assetId);
    }
  }

  function batchStaticWorld(scope = scene) {
    // Keep hidden source transforms to update instances after ownership upgrades.
    // Every instance retains its own asset ID, including batches shared by assets.
    scene.updateMatrixWorld(true);
    const groups = new Map();
    scope.traverse(m => {
      if (!m.isMesh || m.isInstancedMesh || !m.visible || m.name === 'ownership marker' || m.material.userData.shader || (scope===scene && m.userData.deferredBatch)) return;
      const key = m.geometry.uuid + ':' + m.material.uuid + ':' + m.castShadow + ':' + m.receiveShadow + ':' + (m.userData.batchRegion || 'core');
      if (!groups.has(key)) groups.set(key, []); groups.get(key).push(m);
    });
    const batchedPickables = new Set();
    for (const sources of groups.values()) {
      if (sources.length < 3) continue;
      const first = sources[0], batch = new T.InstancedMesh(first.geometry, first.material, sources.length);
      batch.name = 'city instances: ' + first.name;
      batch.castShadow = first.castShadow; batch.receiveShadow = first.receiveShadow;
      batch.userData.assetIds = sources.map(m => m.userData.assetId || null);
      sources.forEach((m, i) => { batch.setMatrixAt(i, m.matrixWorld); batch.setColorAt(i, new T.Color(m.userData.remodelTint || 0xffffff)); m.visible = false; m.matrixAutoUpdate = false; batchedPickables.add(m); });
      batch.computeBoundingSphere(); scene.add(batch); batches.push({ batch, sources, scope });
      if (batch.userData.assetIds.some(Boolean)) pickables.push(batch);
      stats.batchedObjects += sources.length; stats.instanceBatches++;
    }
    for (let i = pickables.length - 1; i >= 0; i--) if (batchedPickables.has(pickables[i])) pickables.splice(i, 1);
    // Static source groups keep their baked transforms until an ownership,
    // construction or upgrade change explicitly updates that property.
    scope.traverse(g=>{if(g.isGroup){g.updateMatrix();g.matrixAutoUpdate=false;}});
  }
  function syncInstances(changedAssets = null) {
    for (const { batch, sources } of batches) {
      let changed = false;
      sources.forEach((m, i) => {
        if (changedAssets && !changedAssets.has(m.userData.assetId)) return;
        m.updateWorldMatrix(true, false); batch.setMatrixAt(i, m.matrixWorld);
        batch.setColorAt(i, new T.Color(m.userData.remodelTint || 0xffffff)); changed = true;
      });
      if (changed) { batch.instanceMatrix.needsUpdate = true; if(batch.instanceColor)batch.instanceColor.needsUpdate = true; batch.computeBoundingSphere(); }
    }
    renderer.shadowMap.needsUpdate = true;
  }
  function clearScopedBatches(scope) {
    for(let i=batches.length-1;i>=0;i--)if(batches[i].scope===scope){
      const {batch,sources}=batches[i];scene.remove(batch);batch.dispose();
      const index=pickables.indexOf(batch);if(index>=0)pickables.splice(index,1);
      stats.batchedObjects-=sources.length;stats.instanceBatches--;batches.splice(i,1);
    }
  }
  function addTraffic(modelCar) {
    // Cars use exactly the same spline as the asphalt and lane markings.
    for (let i = 0; i < 20; i++) {
      const lane = roads[i % roads.length];
      const g = modelCar(scene, 0, 0, 0, [0xe6b94c, 0xc45245, 0x3f83a2, 0xe6e7dd][i % 4]);
      g.traverse(m => { if (m.isMesh) m.castShadow = false; });
      traffic.push({ g, lane, offset: i * 0.073, speed: 18 + (i % 6) * 3 });
    }
  }
  function sampleRoad(curve, progress, laneOffset = 0) {
    const t = ((progress % 1) + 1) % 1, p = curve.getPointAt(t), tangent = curve.getTangentAt(t);
    const side = new T.Vector3(-tangent.z, 0, tangent.x).normalize(); p.addScaledVector(side, laneOffset);
    return { x: p.x, z: p.z, yaw: Math.atan2(-tangent.z, tangent.x) }; // vehicle forward axis is +X
  }
  function update(time) {
    for (const m of waterMaterials) if (m.userData.shader) m.userData.shader.uniforms.uFluxTime.value = time;
    for (const car of traffic) {
      const closed = car.lane.curve.userData?.closed;
      const t = car.offset + time * car.speed / car.lane.curve.getLength();
      // Open roads use the opposite lane for the return journey.
      const phase = ((t % 2) + 2) % 2, reverse = !closed && phase > 1;
      const p = sampleRoad(car.lane.curve, closed ? t : reverse ? 2 - phase : phase, (reverse ? -1 : 1) * car.lane.width * 0.3);
      car.g.position.set(p.x, 24, p.z); car.g.rotation.y = p.yaw + (reverse ? Math.PI : 0);
    }
  }
  function setQuality(name) {
    const q = QUALITY_PRESETS[name] || QUALITY_PRESETS.high;
    // Live changes affect raster/shadow cost; geometry settings apply next load.
    renderer.setPixelRatio(Math.min(globalThis.devicePixelRatio || 1, q.pixelRatio));
    return q;
  }
  return { quality, stats, box, shape, material, rounded, cylinder, sphere, tree,
    water, road, curvedRoad, enrichAsset, facade, roofEquipment, vehicleDetails,
    batchStaticWorld, clearScopedBatches, syncInstances, addTraffic, sampleRoad, update, setQuality, roads };
}
