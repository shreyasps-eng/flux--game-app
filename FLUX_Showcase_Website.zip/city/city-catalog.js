// Existing IDs/prices are defined in world.js and remain unchanged.
const L = 100000, CR = 10000000;
export const GROWTH_DISTRICTS = [
  ['garden','10. Garden Homes',[-7800,-4600]],
  ['heights','11. Apartment Heights',[-3500,-6400]],
  ['retail','12. Retail Avenue',[850,-6400]],
  ['nightlife','13. Leisure Quarter',[5200,-6400]],
  ['innovation','14. Innovation District',[8200,-700]],
  ['logistics','15. Logistics Gateway',[8200,5100]],
  ['waterfront','16. Waterfront Estates',[3350,7200]],
  ['foundry','17. Foundry Park',[-1250,7200]],
  ['development','18. New Development',[-6650,7200]]
].map(([id,name,center])=>({id,name,center,size:[4100,id==='development'?5800:5400],color:0x1e293b,growth:true}));

const retail = [
  ['Bike Showroom','bike',80*L],['Electric Bike Showroom','bike',120*L],
  ['Luxury Car Showroom','showroom',12*CR],['Used Car Showroom','showroom',3*CR],
  ['Electric Car Showroom','showroom',9*CR],['Motorcycle Service Centre','bike',65*L],
  ['Neighbourhood Pub','pub',110*L],['Rooftop Pub','pub',4*CR],['Live Music Pub','pub',3*CR],
  ['Sports Bar','pub',2*CR],['Brewery Restaurant','pub',5*CR],['Family Diner','shop',75*L],
  ['Bakery','shop',14*L],['Pharmacy','shop',28*L],['Bookshop','shop',18*L],
  ['Pet Shop','shop',16*L],['Hardware Store','shop',30*L],['Fashion Boutique','shop',45*L],
  ['Furniture Store','supermart',2*CR],['Electronics Store','supermart',150*L],
  ['Grocery Hypermarket','supermart',6*CR],['Fitness Club','supermart',2*CR],
  ['Bowling Centre','supermart',3*CR],['Cinema Plaza','mall',20*CR]
];
const civic=[
  ['Community Hospital','tower',18*CR],['Medical Centre','supermart',3*CR],['School Campus','supermart',180*L],
  ['Design College','tower',6*CR],['Research Institute','tower',12*CR],['Public Library','supermart',120*L],
  ['Convention Centre','mall',24*CR],['Business Hotel','tower',30*CR],['Serviced Apartments','apartment',8*CR]
];
const industry=[
  ['Textile Factory','factory',8*CR],['Food Processing Factory','factory',12*CR],
  ['Automobile Factory','factory',80*CR],['Solar Panel Factory','factory',35*CR],
  ['Pharmaceutical Factory','factory',50*CR],['Recycling Factory','factory',6*CR],
  ['Cold Storage Warehouse','factory',7*CR],['Packaging Factory','factory',4*CR],
  ['Ceramics Factory','factory',10*CR],['Electronics Factory','factory',45*CR],
  ['Steel Foundry','factory',65*CR],['Precision Engineering Factory','factory',28*CR]
];
// Ten new purchases reuse the existing high-detail building models.
export const CITY_ADDITIONS = [
  ['mobile_kiosk','Mobile Repair Kiosk','shop',45000,'Retail','retail'],
  ['juice_bar','Street Juice Bar','shop',60000,'Retail','nightlife'],
  ['bicycle_workshop','Bicycle Workshop','bike',85000,'Retail','foundry'],
  ['furniture_workshop','Furniture Workshop','factory',18*L,'Industry','foundry'],
  ['dairy_plant','Dairy Processing Plant','factory',4*CR,'Industry','foundry'],
  ['bottling_plant','Water Bottling Plant','factory',6*CR,'Industry','foundry'],
  ['prefab_factory','Prefab Housing Factory','factory',16*CR,'Industry','foundry'],
  ['logistics_office','Logistics Office','tower',2*CR,'Offices','logistics'],
  ['cargo_airport','Cargo Airport','airport',1200*CR,'Transport','logistics'],
  ['cruise_terminal','Cruise Ship Terminal','shipyard',1800*CR,'Transport','logistics']
].map(([id,name,model,price,category,district])=>({id,name,model,price,category,district}));
export const BLUEPRINTS = [
  ['family','Family House','house',55*L,21000,4200,'Homes'],
  ['villa','Garden Villa','villa',120*L,45000,9000,'Homes'],
  ['apartment','Apartment Building','apartment',350*L,165000,32000,'Homes'],
  ['tower','Commercial Skyscraper','tower',15*CR,1500000,310000,'Offices'],
  ['mall','Shopping Centre','mall',30*CR,2600000,550000,'Retail'],
  ['airport','Regional Airport','airport',200*CR,12500000,2600000,'Transport'],
  ['shipyard','Shipyard','shipyard',1500*CR,28000000,6200000,'Transport'],
  ['bus','Bus Terminal','busstand',2*CR,120000,35000,'Transport'],
  ...retail.map(([name,model,price],i)=>['retail_'+i,name,model,price,Math.round(price*.012),Math.round(price*.0028),['pub'].includes(model)?'Leisure':'Retail']),
  ...civic.map(([name,model,price],i)=>['civic_'+i,name,model,price,Math.round(price*.008),Math.round(price*.002),'Civic']),
  ...industry.map(([name,model,price],i)=>['industry_'+i,name,model,price,Math.round(price*.01),Math.round(price*.0024),'Industry']),
  ['mobile_kiosk','Mobile Repair Kiosk','shop',30000,420,90,'Retail'],
  ['juice_bar','Street Juice Bar','shop',45000,600,130,'Retail'],
  ['bicycle_workshop','Bicycle Workshop','bike',65000,850,180,'Retail']
].map(([id,name,model,price,income,upkeep,category])=>({id,name,model,price,income,upkeep,category,max:6}));

// Show thirty clear choices. Keep every legacy blueprint in BLUEPRINTS so
// previously built properties and saved construction still load correctly.
export const BUILD_CHOICES = [
  'family','mobile_kiosk','juice_bar','bicycle_workshop','villa','apartment',
  'tower','mall','airport','shipyard','bus',
  'retail_0','retail_2','retail_4','retail_6','retail_7','retail_11',
  'retail_12','retail_13','retail_14','retail_16','retail_20','retail_23',
  'industry_0','industry_1','industry_2','industry_5',
  'civic_0','civic_2','civic_5'
].map(id=>BLUEPRINTS.find(b=>b.id===id));

export function appendCityCatalog(def,districts){
  const cursor={};
  function add(district,config){
    const zone=districts.find(d=>d.id===district),index=cursor[district]||0;
    cursor[district]=index+1;
    // Each plot is clear of the local boulevard. Larger infrastructure fits
    // the same surveyed 730 x 1080m cells, with a separate 860m land survey.
    def({...config,district,x:zone.center[0]+(index%5-2)*780,
      z:zone.center[1]+(Math.floor(index/5)-2)*1060,expansion:true,max:6,
      note:config.note||'Fixed purchase price · six structural levels · repeatable remodeling'});
  }
  for(let i=1;i<=72;i++){
    const model=i<=36?'house':i<=48?'villa':'apartment';
    const zone=i<=25?'garden':i<=50?'heights':'waterfront';
    const price=(model==='apartment'?280+i*5:model==='villa'?130+i*2:70+i*2)*L;
    add(zone,{id:'home_new_'+i,name:(model==='apartment'?'Skyline Apartments ':model==='villa'?'Garden Villa ':'Family House ')+String(i).padStart(2,'0'),
      model,kind:'house',category:'Homes',price,income:Math.round(price*.008),upkeep:Math.round(price*.0018)});
  }
  retail.forEach(([name,model,price],i)=>{for(let branch=1;branch<=2;branch++)add(i<12?'retail':'nightlife',{
    id:'retail_new_'+i+'_'+branch,name:name+' '+(branch===1?'Central':'West'),model,
    category:model==='pub'?'Leisure':'Retail',price,income:Math.round(price*.012),upkeep:Math.round(price*.0028)});});
  civic.forEach(([name,model,price],i)=>{for(let branch=1;branch<=2;branch++)add(i<5?'innovation':(cursor.waterfront||0)<25?'waterfront':'foundry',{
    id:'civic_new_'+i+'_'+branch,name:name+' '+(branch===1?'North':'South'),model,category:'Civic',
    price,income:Math.round(price*.008),upkeep:Math.round(price*.002)});});
  for(let i=1;i<=18;i++)add(i<=15?'innovation':'foundry',{
    id:'tower_new_'+i,name:['Venture Tower','Commerce Tower','Finance Tower'][i%3]+' '+String(i).padStart(2,'0'),
    model:'tower',category:'Offices',price:(10+i*2)*CR,income:(900000+i*130000),upkeep:(220000+i*25000),floors:22+i%10});
  industry.forEach(([name,model,price],i)=>add('foundry',{id:'industry_new_'+i,name,model,category:'Industry',price,income:Math.round(price*.01),upkeep:Math.round(price*.0024)}));
  for(let i=1;i<=12;i++){
    const model=i<=4?'airport':i<=8?'shipyard':'busstand';
    const price=(model==='airport'?200+i*60:model==='shipyard'?1800+(i-5)*350:2+i*.3)*CR;
    add('logistics',{id:'transport_new_'+i,name:(model==='airport'?'Gateway Airport ':model==='shipyard'?'Cargo Shipyard ':'Transit Terminal ')+i,
      model,category:'Transport',price,income:Math.round(price*.006),upkeep:Math.round(price*.0014)});
  }
  CITY_ADDITIONS.forEach(({district,...config})=>add(district,{
    ...config,income:Math.round(config.price*.01),upkeep:Math.round(config.price*.0024)
  }));
  const allDistricts = districts.map(d => d.id);
  for(let i=1; i<=54; i++){
    const districtId = allDistricts[(i - 1) % allDistricts.length];
    const price = (15 + i * 2) * L;
    add(districtId, {
      id: 'land_' + i,
      name: 'Vacant Land ' + String(i).padStart(2, '0') + ' (' + districtId.toUpperCase() + ')',
      district: districtId,
      model: 'land',
      kind: 'land',
      category: 'Land',
      price: price,
      income: 0,
      upkeep: 0
    });
  }
}

export function durationMs(def,level=1){
  const base=def.model==='airport'||def.model==='shipyard'?6*3600000:
    def.model==='tower'||def.model==='mall'?2*3600000:
    def.model==='apartment'||def.model==='factory'?3600000:15*60000;
  return Math.round(base*(1+(level-1)*.35));
}
export function timeLabel(ms){
  const seconds=Math.max(0,Math.ceil(ms/1000));
  const h=Math.floor(seconds/3600),m=Math.floor(seconds%3600/60),s=seconds%60;
  return (h?h+'h ':'')+(m||h?m+'m ':'')+s+'s';
}
export function fastFinishPrice(owned,now=Date.now()){
  if(!owned?.constructionEndAt||owned.constructionEndAt<=now)return 0;
  const ratio=(owned.constructionEndAt-now)/Math.max(1,owned.constructionDurationMs);
  return Math.max(1000,Math.ceil((owned.constructionCost||10000)*.12*ratio));
}
