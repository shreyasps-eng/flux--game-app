import * as T from './three.module.js';
import { createReferenceArchitecture } from './reference-city.js';
import { BUILD_STAGES, constructionProgress as rawConstructionProgress, createConstructionSites } from './construction-city.js';
import { MAX_CITY_LEVEL, DAILY_XP_CAP, REAL_DAY_MS, normalizeCityProgression, levelFromXp,
  awardCityXp, cityProgressionStatus, minimumDaysForLevel } from './city-progression.js';
import { createHighPolyCity, subdividedRoofGeometry, roundedRectangleCurve, QUALITY_PRESETS } from './high-poly-city.js';
import { appendCityCatalog, GROWTH_DISTRICTS, BLUEPRINTS, durationMs, fastFinishPrice, timeLabel } from './city-catalog.js';
import { createCityInterface } from './city-ui.js';

const host = document.getElementById('hud').parentElement;
const $ = (id) => document.getElementById(id);
const L = 100000;
const CR = 10000000;
const saveKey = 'flux_big_playable_city_v5';
const POWER_COST = 25 * CR;
const WATER_COST = 15 * CR;
const WORLD_SIZE_METERS = 250000;
const ACTIVE_CITY_METERS = { width: 21000, depth: 20000 };
let cityUI;
const worldInfo = {
  empireKmPerDistrict: 300000,
  playableSector: '250,000m strategic base with a dense playable 3D metro sector',
  districtClaim: 'Each district represents a 300,000km empire claim in the atlas; the playable city renders the high-detail management hub.'
};

function money(v) {
  const sign = v < 0 ? '-₹' : '₹';
  const a = Math.abs(v);
  const NI = 10000000000000; // 10^13 = Nil
  const KH = 100000000000;   // 10^11 = Kharab (100 Arab)
  const AR = 1000000000;     // 10^9  = Arab (100 Crore)
  const CR = 10000000;       // 10^7  = Crore (100 Lakh)
  const L  = 100000;         // 10^5  = Lakh
  const K  = 1000;           // 10^3  = Thousand

  if (a >= NI) return sign + (a / NI).toFixed(1) + ' Nil';
  if (a >= KH) return sign + (a / KH).toFixed(1) + ' Kh';
  if (a >= AR) return sign + (a / AR).toFixed(1) + ' Ar';
  if (a >= CR) return sign + (a / CR).toFixed(1) + ' Cr';
  if (a >= L)  return sign + (a / L).toFixed(1) + ' L';
  if (a >= K)  return sign + (a / K).toFixed(1) + ' K';
  return sign + Math.round(a).toLocaleString('en-IN');
}

function bankBridge() {
  return window.AndroidBank || null;
}

function defaultState() {
  return {
    account: false,
    balance: 0,
    day: 1,
    xp: 0,
    highestCityLevel: 1,
    loans: [],
    owned: {},
    missions: {},
    utilities: { power: false, water: false },
    cycle: 'stable',
    history: [],
    taxes: { due: 0, paid: 0 },
    clock: { lastAt: Date.now() },
    last: 'Open a Flux Bank account, take a loan, then buy assets.'
  };
}

function normalizeState(raw) {
  const base = Object.assign(defaultState(), raw || {});
  base.day = Math.max(1, Number(base.day) || 1);
  base.xp = Math.max(0, Number(base.xp) || 0);
  base.highestCityLevel = Math.max(1, Math.min(MAX_CITY_LEVEL, Math.floor(Number(base.highestCityLevel) || 1)));
  base.loans = Array.isArray(base.loans) ? base.loans : [];
  base.owned = base.owned && typeof base.owned === 'object' ? base.owned : {};
  base.missions = base.missions && typeof base.missions === 'object' ? base.missions : {};
  base.utilities = Object.assign({ power: false, water: false }, base.utilities || {});
  base.history = Array.isArray(base.history) ? base.history.slice(0, 20) : [];
  base.taxes = { due: Math.max(0, Number(base.taxes?.due) || 0), paid: Math.max(0, Number(base.taxes?.paid) || 0) };
  base.clock = { lastAt: Math.max(Date.now(), Number(base.clock?.lastAt) || 0) };
  Object.keys(base.owned).forEach(id => {
    base.owned[id] = normalizeOwned(base.owned[id]);
  });
  normalizeCityProgression(base);
  return base;
}

function normalizeOwned(o) {
  const value = o && typeof o === 'object' ? o : {};
  const timed = Number(value.constructionEndAt) > 0;
  const daysLeft = timed ? 0 : Math.max(0, Math.floor(Number(value.daysLeft) || 0));
  const level = Math.max(1, Math.min(6, Math.floor(Number(value.level) || 1)));
  return {
    level,
    buses: Math.max(0, Number(value.buses) || 0),
    ships: Math.max(0, Number(value.ships) || 0),
    condition: Math.max(5, Math.min(100, Number(value.condition) || 100)),
    daysLeft,
    constructionTotal: daysLeft ? Math.max(3, daysLeft, Number(value.constructionTotal) || daysLeft) : 0,
    constructionKind: daysLeft || timed ? (value.constructionKind === 'upgrade' ? 'upgrade' : 'build') : null,
    targetLevel: daysLeft || timed ? Math.max(level, Math.min(6, Number(value.targetLevel) || level)) : level,
    constructionEndAt: timed ? Number(value.constructionEndAt) : 0,
    constructionDurationMs: timed ? Math.max(1000, Number(value.constructionDurationMs) || 900000) : 0,
    constructionCost: Math.max(0, Number(value.constructionCost) || 0),
    landOnly: !!value.landOnly,
    blueprintId: BLUEPRINTS.some(b=>b.id===value.blueprintId) ? value.blueprintId : null,
    buildValue: Math.max(0, Number(value.buildValue) || 0),
    customName: String(value.customName || '').slice(0,48),
    style: ['original','sky','jade','warm'].includes(value.style) ? value.style : 'original',
    remodelCount: Math.max(0, Math.floor(Number(value.remodelCount) || 0))
  };
}

function hostLoad() {
  try {
    const bridge = bankBridge();
    if (!bridge?.loadCityState) return null;
    const raw = String(bridge.loadCityState() || '');
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function load() {
  try {
    return normalizeState(hostLoad() || JSON.parse(localStorage.getItem(saveKey) || '{}'));
  } catch {
    return normalizeState({ last: 'Fresh city save.' });
  }
}

function save() {
  const json = JSON.stringify(state);
  localStorage.setItem(saveKey, json);
  try {
    const bridge = bankBridge();
    if (bridge?.saveCityState) bridge.saveCityState(json);
  } catch {
    // Local storage remains the fallback save path.
  }
}

let state = load();
function bridgeBalance() {
  const bridge = bankBridge();
  if (!bridge?.getBankBalance) return NaN;
  const value = Number(bridge.getBankBalance());
  return Number.isFinite(value) ? value : NaN;
}
function syncHostBalance() {
  const balance = bridgeBalance();
  if (!Number.isFinite(balance)) return false;
  state.account = true;
  state.balance = balance;
  return true;
}
function credit(amount, reason) {
  const value = Number(amount) || 0;
  if (value <= 0) return true;
  const bridge = bankBridge();
  if (bridge?.credit) {
    const ok = bridge.credit(value, reason || 'Playable City income');
    syncHostBalance();
    return !!ok;
  }
  state.balance += value;
  return true;
}
function takeHostLoan(name, principal) {
  const bridge = bankBridge();
  if (!bridge?.takeLoan) return false;
  const ok = bridge.takeLoan(name, principal);
  syncHostBalance();
  return !!ok;
}
if (syncHostBalance()) {
  state.last = 'Linked to the main FLUX India Bank account.';
}
let selected = 'mall';
const assetDefs = [];
const assets = new Map();
const pickables = [];
const dynamic = { buses: [], ships: [], planes: [] };
const economyCycles = {
  stable: { name: 'Stable', income: 1, upkeep: 1, taxBoost: 0 },
  boom: { name: 'Boom', income: 1.18, upkeep: 1.06, taxBoost: .01 },
  monsoon: { name: 'Monsoon', income: .94, upkeep: 1.11, taxBoost: 0 },
  festival: { name: 'Festival', income: 1.28, upkeep: 1.04, taxBoost: .01 },
  slowdown: { name: 'Slowdown', income: .86, upkeep: .96, taxBoost: 0 }
};
const missionDefs = [
  { id: 'first_asset', title: 'Buy first city asset', reward: 50_000, xp: 25, check: () => ownedCount() >= 1 },
  { id: 'first_house', title: 'Buy first house', reward: 2 * L, xp: 40, check: () => ownsKind('house') },
  { id: 'five_assets', title: 'Own 5 city assets', reward: 10 * L, xp: 80, check: () => ownedCount() >= 5 },
  { id: 'first_bus', title: 'Start public transport', reward: 5 * L, xp: 80, check: () => totalBuses() >= 1 },
  { id: 'shipyard_owner', title: 'Own a shipyard', reward: 5 * CR, xp: 160, check: () => ownsModel('shipyard') },
  { id: 'airport_owner', title: 'Own an airport', reward: 10 * CR, xp: 180, check: () => ownsModel('airport') },
  { id: 'two_airports', title: 'Own both airports', reward: 25 * CR, xp: 300, check: () => ownedByModel('airport') >= 2 },
  { id: 'utility_city', title: 'Activate power and water', reward: 3 * CR, xp: 170, check: () => state.utilities.power && state.utilities.water },
  { id: 'ten_assets', title: 'Own 10 city assets', reward: 15 * CR, xp: 260, check: () => ownedCount() >= 10 }
];

const districts = [
  { id: 'residential', name: '1. Residential District', color: 0x8BC34A, center: [-2450, -1420], size: [2500, 1500] },
  { id: 'commercial', name: '2. Commercial District', color: 0x9575CD, center: [0, -980], size: [2250, 1850] },
  { id: 'corporate', name: '3. Corporate District', color: 0x64B5F6, center: [-140, -2460], size: [1450, 850] },
  { id: 'industrial', name: '4. Industrial District', color: 0x455A64, center: [-3600, 520], size: [2100, 1450] },
  { id: 'mining', name: '5. Desert Mining Zone', color: 0xE9C46A, center: [-850, 860], size: [1900, 1500] },
  { id: 'education', name: '6. Civic & Gardens', color: 0x8BC34A, center: [2600, 760], size: [2200, 1450] },
  { id: 'port', name: '7. Port & Waterfront', color: 0x0288D1, center: [-3750, 2400], size: [2450, 1600] },
  { id: 'airport', name: '8. Airport Hub', color: 0x455A64, center: [450, 2500], size: [2600, 1650] },
  { id: 'entertainment', name: '9. Transport & Retail Plaza', color: 0x9575CD, center: [3300, 2300], size: [2100, 1500] }
];
districts.push(...GROWTH_DISTRICTS);

function def(config) {
  assetDefs.push(Object.assign({ max: 6, income: 0, upkeep: 0, kind: 'asset' }, config));
}

function buildCatalog() {
  const at = (districtId, dx, dz) => {
    const c = districts.find(d => d.id === districtId).center;
    return [c[0] + dx, c[1] + dz];
  };
  const rc = districts.find(d => d.id === 'residential').center;
  let i = 0;
  for (let row = 0; row < 4; row++) {
    for (let col = 0; col < (row === 3 ? 4 : 6); col++) {
      i++;
      def({
        id: 'house' + i,
        name: 'Flux Family House ' + String(i).padStart(2, '0'),
        district: 'residential',
        kind: 'house',
        model: i % 6 === 0 ? 'apartment' : i % 5 === 0 ? 'villa' : 'house',
        x: rc[0] - 820 + col * 330,
        z: rc[1] - 520 + row * 330,
        price: (70 + i * 3) * L,
        income: (18000 + i * 950),
        upkeep: (4200 + i * 130),
        note: 'One of 22 large playable homes; buy, upgrade, sell.'
      });
    }
  }

  [
    ['tea', 'Large Tea Shop', 'commercial', 'shop', -620, -380, 25000, 1600, 300],
    ['coffee', 'Coffee Cafe', 'commercial', 'shop', -360, -380, 8 * L, 12000, 2500],
    ['vegmarket', 'Vegetable Market', 'commercial', 'market', -80, -410, 40 * L, 42000, 9000],
    ['flowermarket', 'Flower Market', 'commercial', 'market', 220, -410, 35 * L, 38000, 8500],
    ['supermart', 'Flux Super Mart', 'commercial', 'supermart', 520, -300, 120 * L, 95000, 22000],
    ['restaurant', 'Family Restaurant', 'commercial', 'shop', -560, 150, 90 * L, 78000, 18000],
    ['foodcourt', 'Food Court', 'commercial', 'mall', -140, 180, 5 * CR, 260000, 55000],
    ['mall', 'Shopping Mall', 'commercial', 'mall', 430, 160, 80 * CR, 3200000, 650000],
    ['tinystore', 'Tiny Starter Store', 'commercial', 'shop', 760, -50, 12000, 950, 160],
    ['kirana', 'Kirana Super Shop', 'commercial', 'shop', 760, 250, 2 * L, 16000, 3500],
    ['carshowroom', 'Car Showroom', 'commercial', 'supermart', 520, 520, 7 * CR, 750000, 160000],
    ['fluxshed', 'Flux Storage Shed', 'commercial', 'factory', -720, 420, 80 * L, 90000, 21000]
  ].forEach(a => { const [x, z] = at(a[2], a[4], a[5]); def({ id: a[0], name: a[1], district: a[2], model: a[3], x, z, price: a[6], income: a[7], upkeep: a[8], note: 'Commercial income asset with upgrade levels.' }); });

  [
    ['mine_quarry', 'Small Quarry', 'mining', 'mine', -540, -130, 10 * L, 30000, 6000],
    ['mine_crusher', 'Stone Crusher', 'mining', 'factory', -120, -110, 40 * L, 95000, 18000],
    ['mine_iron', 'Iron Mine', 'mining', 'mine', -380, 250, 3 * CR, 650000, 110000],
    ['mine_coal', 'Coal Mine', 'mining', 'mine', 220, 240, 8 * CR, 1200000, 240000],
    ['mine_rare', 'Rare Metal Mine', 'mining', 'mine', -720, 240, 40 * CR, 5200000, 900000],
    ['warehouse', 'Mini Warehouse', 'industrial', 'factory', -420, -320, 5 * L, 35000, 8500],
    ['cement', 'Cement Unit', 'industrial', 'factory', 0, -330, 1 * CR, 210000, 42000],
    ['steel', 'Steel Workshop', 'industrial', 'factory', 410, -320, 6 * CR, 940000, 190000],
    ['factory', 'Heavy Factory', 'industrial', 'factory', -230, 150, 25 * CR, 3100000, 650000],
    ['construction', 'Construction Company Yard', 'industrial', 'factory', 380, 150, 12 * CR, 1600000, 280000]
  ].forEach(a => { const [x, z] = at(a[2], a[4], a[5]); def({ id: a[0], name: a[1], district: a[2], model: a[3], x, z, price: a[6], income: a[7], upkeep: a[8], note: 'Industry and mining asset.' }); });

  [
    ['shipyard_east', 'Shipyard A', 'port', 'shipyard', -500, -180, 3000 * CR, 42000000, 9000000],
    ['shipyard_west', 'Shipyard B', 'port', 'shipyard', 380, -180, 5000 * CR, 62000000, 13000000],
    ['dock', 'Container Dock', 'port', 'shipyard', -40, 420, 30 * CR, 6700000, 1150000],
    ['bus_north', 'Metro Bus Stand', 'commercial', 'busstand', -850, 520, 2 * CR, 120000, 35000],
    ['bus_res', 'Residential Bus Stand', 'residential', 'busstand', 900, 440, 2 * CR, 120000, 35000],
    ['bus_corp', 'Central Bus Terminal', 'entertainment', 'busstand', -180, -360, 5 * CR, 300000, 65000],
    ['airport_metro', 'Flux Metro Airport', 'airport', 'airport', -470, -120, 200 * CR, 12500000, 2600000],
    ['airport_sky', 'SkyTrade International Airport', 'airport', 'airport', 650, -120, 750 * CR, 38000000, 8000000]
  ].forEach(a => { const [x, z] = at(a[2], a[4], a[5]); def({ id: a[0], name: a[1], district: a[2], model: a[3], x, z, price: a[6], income: a[7], upkeep: a[8], note: a[3] === 'busstand' ? 'Own it, then add more buses.' : a[3] === 'shipyard' ? 'Own it, then add ships.' : 'Large infrastructure asset.' }); });

  [
    ['office', 'Small Office', 'corporate', 'tower', -280, -180, 15 * L, 90000, 22000],
    ['bank', 'Flux Bank Branch', 'corporate', 'tower', 0, -160, 25 * CR, 4200000, 740000],
    ['corp_tower', 'Corporate Tower', 'corporate', 'tower', 280, -130, 10 * CR, 2000000, 370000],
    ['theatre', 'Local Theatre', 'education', 'mall', -530, 300, 25 * L, 35000, 8000],
    ['multiplex', 'Mega Multiplex', 'education', 'mall', 240, 300, 50 * CR, 7200000, 1300000],
    ['school', 'Public School', 'education', 'supermart', -520, -170, 40 * L, 60000, 16000],
    ['college', 'Skill College', 'education', 'tower', 0, -150, 5 * CR, 900000, 150000],
    ['hospital', 'Public Hospital', 'education', 'tower', 430, -120, 50 * CR, 5600000, 1200000]
  ].forEach(a => { const [x, z] = at(a[2], a[4], a[5]); def({ id: a[0], name: a[1], district: a[2], model: a[3], x, z, price: a[6], income: a[7], upkeep: a[8], note: 'City service/business asset.' }); });
}

buildCatalog();
appendCityCatalog(def,districts);

const roadX = [-4520, -2750, -850, 1250, 3050, 4250];
const roadZ = [-2320, -850, 620, 1990, 3160];
const footprints = {
  house: [180, 200], villa: [200, 210], apartment: [180, 180],
  shop: [175, 190], market: [260, 180], supermart: [280, 260],
  mall: [680, 480], factory: [340, 300], mine: [310, 300],
  busstand: [320, 210], shipyard: [450, 380], airport: [640, 900], tower: [190, 200],
  showroom: [300,300], bike: [300,300], pub: [300,300], land: [720,1000]
};
const footprintOf = d => d.kind === 'land' ? footprints.land : d.model === 'mall' && d.id !== 'mall' ? [360, 310] : footprints[d.model];
const reservedLots = [
  { x: -400, z: -1330, width: 610, depth: 450, scenery: 'park' },
  { x: 100, z: -2000, width: 220, depth: 215, scenery: 'terrace tower' },
  { x: 890, z: -1790, width: 220, depth: 215, scenery: 'terrace tower' }
];
assetDefs.find(d => d.id === 'mall').z = -1300;
function lotIsClear(x, z, width, depth, district, padding = 16) {
  const hw = width / 2, hd = depth / 2;
  if (Math.abs(x - district.center[0]) + hw > district.size[0] / 2 - 12 ||
      Math.abs(z - district.center[1]) + hd > district.size[1] / 2 - 12) return false;
  // Road half-width + maximum spline bend + sidewalk and pedestrian clearance.
  if (roadX.some(rx => Math.abs(x - rx) < hw + 88) ||
      roadZ.some(rz => Math.abs(z - rz) < hd + 88)) return false;
  return !reservedLots.some(a => Math.abs(x - a.x) < hw + a.width / 2 + padding &&
    Math.abs(z - a.z) < hd + a.depth / 2 + padding);
}
function planCityLots() {
  const offsets = [];
  for (let dx = -1600; dx <= 1600; dx += 25) for (let dz = -1600; dz <= 1600; dz += 25) offsets.push([dx, dz]);
  offsets.sort((a, b) => a[0] * a[0] + a[1] * a[1] - b[0] * b[0] - b[1] * b[1]);
  const sorted = assetDefs.filter(d=>!d.expansion).sort((a, b) => {
    const af = footprintOf(a), bf = footprintOf(b); return bf[0] * bf[1] - af[0] * af[1];
  });
  for (const d of sorted) {
    const district = districts.find(a => a.id === d.district), [width, depth] = footprintOf(d);
    const offset = offsets.find(([dx, dz]) => lotIsClear(d.x + dx, d.z + dz, width, depth, district));
    if (offset) { d.x += offset[0]; d.z += offset[1]; }
    else console.warn('City lot needs review:', d.id);
    reservedLots.push({ x: d.x, z: d.z, width, depth, id: d.id });
  }
  // Preserve the original 60 surveys. New districts use a non-overlapping grid.
  assetDefs.filter(d=>d.expansion).forEach(d=>{ const [width,depth]=footprintOf(d);reservedLots.push({x:d.x,z:d.z,width,depth,id:d.id}); });
}
planCityLots();

const renderer = new T.WebGLRenderer({ antialias: false, powerPreference: "high-performance" });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.25));
renderer.shadowMap.enabled = false;
renderer.shadowMap.type = T.PCFSoftShadowMap;
renderer.outputColorSpace = T.SRGBColorSpace;
document.body.prepend(renderer.domElement);

const scene = new T.Scene();
scene.background = new T.Color('#94a3b8');
scene.fog = new T.Fog('#94a3b8', 15000, 45000);
const camera = new T.PerspectiveCamera(38, innerWidth / innerHeight, 2, 50000);
scene.add(new T.AmbientLight('#e0f2fe', .25));
scene.add(new T.HemisphereLight('#f1f5f9', '#2e7d32', .85));
const sun = new T.DirectionalLight('#fff7ed', 2.6);
sun.position.set(-2600, 4300, 1600);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -4300;
sun.shadow.camera.right = 4300;
sun.shadow.camera.top = 4300;
sun.shadow.camera.bottom = -4300;
sun.shadow.camera.near = 500;
sun.shadow.camera.far = 15000;
scene.add(sun);
scene.add(sun.target);
sun.shadow.bias = -0.00012;
sun.shadow.normalBias = 2;
// Static buildings only need a new shadow map after camera/ownership changes.
renderer.shadowMap.autoUpdate = false;
let qualityName = 'mobile';
try { qualityName = localStorage.getItem('flux_city_graphics') || (window.AndroidBank ? 'mobile' : 'balanced'); } catch {}
if (!QUALITY_PRESETS[qualityName]) qualityName = 'mobile';
const graphics = createHighPolyCity(scene, renderer, pickables, qualityName);
sun.shadow.mapSize.set(graphics.quality.shadowSize, graphics.quality.shadowSize);
const { box, shape, road } = graphics;
const architecture = createReferenceArchitecture(graphics, scene, pickables);
const constructionSites = createConstructionSites(graphics, architecture);
Object.assign(graphics.stats, architecture.stats);

const cyl = graphics.cylinder;
const cone = new T.ConeGeometry(.5, 1, graphics.quality.radialSegments, 12);
const roof = subdividedRoofGeometry(graphics.quality.buildingSegments);
const lockHoopGeometry = new T.TorusGeometry(9,2.5,8,32,Math.PI);
const hullOutline=new T.Shape();
hullOutline.moveTo(-42,95);hullOutline.lineTo(-42,-80);
hullOutline.quadraticCurveTo(-40,-122,0,-140);hullOutline.quadraticCurveTo(40,-122,42,-80);
hullOutline.lineTo(42,95);hullOutline.quadraticCurveTo(0,124,-42,95);
const shipHullGeometry=new T.ExtrudeGeometry(hullOutline,{depth:24,bevelEnabled:true,bevelSegments:4,steps:3,bevelSize:4,bevelThickness:4,curveSegments:32});
shipHullGeometry.rotateX(-Math.PI/2);
function modelTree(parent, x, z, s = 1) {
  return architecture.tree(parent, x, z, s, 10);
}

function modelPalm(parent, x, z, s = 1) {
  shape(parent, cyl, 'palm trunk', x, 24 * s, z, 8 * s, 48 * s, 8 * s, 0x8b6233);
  for (let i = 0; i < 4; i++) {
    box(parent, 'palm leaf', x + Math.cos(i * Math.PI / 2) * 18 * s, 56 * s, z + Math.sin(i * Math.PI / 2) * 18 * s, 50 * s, 6 * s, 16 * s, 0x2e8d54, null, i * Math.PI / 2);
  }
}

function modelCar(parent, x, z, yaw = 0, color = 0xdd3d34) {
  const g = new T.Group();
  g.position.set(x, 13, z);
  g.rotation.y = yaw;
  parent.add(g);
  box(g, 'car body', 0, 0, 0, 34, 14, 18, color);
  box(g, 'car roof', -2, 10, 0, 19, 10, 15, 0x97d0dc);
  graphics.vehicleDetails(g, 'car');
  return g;
}

function modelStreetLight(parent, x, z, yaw = 0) {
  const g = new T.Group();
  g.position.set(x, 0, z);
  g.rotation.y = yaw;
  parent.add(g);
  shape(g, cyl, 'light pole', 0, 33, 0, 5, 66, 5, 0x24353c);
  box(g, 'light arm', 16, 66, 0, 34, 4, 4, 0x24353c);
  box(g, 'light head', 35, 64, 0, 14, 8, 10, 0xffe7a2);
}

function addTreeGrid(parent, x0, z0, cols, rows, spacing, scale = 1) {
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const jitter = ((c * 37 + r * 19) % 31) - 15;
      modelTree(parent, x0 + c * spacing + jitter, z0 + r * spacing - jitter, scale + ((c + r) % 3) * .1);
    }
  }
}

function addParking(parent, x, z, cols, rows, yaw = 0) {
  const g = new T.Group();
  g.position.set(x, 0, z);
  g.rotation.y = yaw;
  parent.add(g);
  box(g, 'parking asphalt', 0, 1, 0, cols * 58 + 45, 2, rows * 48 + 36, 0x263139);
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const px = (c - (cols - 1) / 2) * 58;
      const pz = (r - (rows - 1) / 2) * 48;
      box(g, 'parking stripe', px + 27, 4, pz, 3, 1, 34, 0xe6e7d3);
      if ((c + r) % 2 === 0) modelCar(g, px, pz, Math.PI / 2, [0xd9463e, 0x2e7ed1, 0xf0c54d, 0xf6f0e5][(c + r) % 4]);
    }
  }
}

function groupAsset(defn) {
  if(defn.kind === 'land' && own(defn.id)?.blueprintId) applyBlueprint(defn,own(defn.id).blueprintId);
  const root = new T.Group();
  root.position.set(defn.x, 0, defn.z);
  scene.add(root);
  const mark = box(root, 'ownership marker', 0, 1.2, 0, 145, 2, 145, 0xf1d36d);
  mark.visible = false;
  assets.set(defn.id, { def: defn, root, mark });
  const build = modelMap[defn.model] || modelMap.shop;
  if(defn.kind==='land'&&defn.model!=='land')modelLand(root,defn);
  if (!architecture.build(root, defn)) { build(root, defn); graphics.enrichAsset(root, defn); }
  attachMajorTiers(root,defn);
  constructionSites.attach(assets.get(defn.id), footprintOf(defn));
  const lock = new T.Group();lock.name='Unowned property lock';root.add(lock);
  const height=root.userData.architecture?.height || (defn.model==='land'?25:defn.model==='factory'?220:defn.model==='airport'?260:140);
  lock.position.y=height+38;
  box(lock,'ownership padlock body',0,0,0,24,22,8,0xe6bd66,defn.id);
  shape(lock,lockHoopGeometry,'ownership padlock shackle',0,11,0,1,1,1,0xe6bd66,defn.id);
  box(lock,'ownership padlock keyhole',0,1,4.4,3,6,1,0x203847,defn.id);
  assets.get(defn.id).lock=lock;
  tagAssetMeshes(assets.get(defn.id));
  return root;
}

function modelHouse(root, d) {
  const c = 0xFFE0B2;
  box(root, 'garden', 0, .4, 0, 180, .8, 170, 0x2b3846, d.id);
  box(root, 'house body', 0, 28, 0, 115, 56, 115, c, d.id);
  shape(root, roof, 'roof', 0, 70, 0, 130, 36, 130, 0xE76F51, d.id);
  box(root, 'porch', 0, 18, -70, 58, 36, 22, 0xFFE0B2, d.id);
  box(root, 'door', 0, 16, -82, 16, 28, 3, 0x455A64, d.id);
  box(root, 'window L', -34, 30, -60, 22, 20, 4, 0x64B5F6, d.id);
  box(root, 'window R', 34, 30, -60, 22, 20, 4, 0x64B5F6, d.id);
}
function modelApartment(root, d) {
  box(root, 'apartment base', 0, 8, 0, 170, 16, 150, 0xCFD8DC, d.id);
  box(root, 'apartment tower', 0, 80, 0, 130, 160, 120, 0xFFE0B2, d.id);
  for (let f = 0; f < 6; f++) box(root, 'glass band', 0, 35 + f * 22, -62, 110, 8, 3, 0x64B5F6, d.id);
  box(root, 'roof cap', 0, 165, 0, 145, 18, 132, 0xE76F51, d.id);
}
function modelShop(root, d) {
  box(root, 'shop body', 0, 31, 0, 145, 62, 118, 0xFFE0B2, d.id);
  box(root, 'front glass', 0, 27, -62, 118, 30, 4, 0x64B5F6, d.id);
  box(root, 'canopy', 0, 52, -76, 160, 10, 32, 0x9575CD, d.id);
  box(root, 'sign', 0, 84, -80, 105, 25, 8, 0x2E7D32, d.id);
}
function modelMarket(root, d) {
  box(root, 'market slab', 0, 1, 0, 245, 2, 160, 0xCFD8DC, d.id);
  for (let i = -2; i <= 2; i++) {
    box(root, 'stall', i * 46, 20, 0, 34, 40, 70, i % 2 ? 0xE76F51 : 0x9575CD, d.id);
    box(root, 'stall canopy', i * 46, 44, -5, 42, 8, 82, 0xFFE0B2, d.id);
  }
}
function modelSupermart(root, d) {
  box(root, 'supermart body', 0, 38, 0, 240, 76, 170, 0xFFE0B2, d.id);
  box(root, 'glass front', 0, 34, -88, 210, 38, 5, 0x64B5F6, d.id);
  box(root, 'large sign', 0, 86, -92, 185, 22, 8, 0x9575CD, d.id);
  box(root, 'parking', 0, 1, -150, 260, 2, 80, 0x455A64, d.id);
}
function modelMall(root, d) {
  box(root, 'mall podium', 0, 38, 0, 330, 76, 210, 0xFFE0B2, d.id);
  box(root, 'mall upper', 0, 90, 30, 280, 48, 155, 0xFFE0B2, d.id);
  box(root, 'atrium', 0, 118, 28, 130, 28, 130, 0x64B5F6, d.id);
  box(root, 'entry canopy', 0, 68, -122, 185, 12, 46, 0x9575CD, d.id);
  for (let i = -3; i <= 3; i++) box(root, 'columns', i * 28, 38, -150, 8, 76, 8, 0xCFD8DC, d.id);
}
function modelFactory(root, d) {
  box(root, 'factory hall', 0, 38, 0, 260, 76, 180, 0x455A64, d.id);
  shape(root, roof, 'factory roof', 0, 88, 0, 285, 42, 195, 0x388E3C, d.id);
  for (let i = -1; i <= 1; i++) {
    shape(root, cyl, 'chimney', -95 + i * 70, 105, 88, 24, 210, 24, 0xE76F51, d.id);
    box(root, 'loading door', -70 + i * 70, 25, -94, 42, 48, 5, 0x64B5F6, d.id);
    for(let n=0;n<5;n++)shape(root,cyl,'chimney white ring',-95+i*70,130+n*16,88,25,4,25,n%2?0xCFD8DC:0xE76F51,d.id);
  }
  for(let i=-4;i<=4;i++)box(root,'factory clerestory glass',i*27,63,-93,20,12,3,0x64B5F6,d.id);
  for(let i=-1;i<=1;i++){
    box(root,'factory rooftop AC',i*55,104,-12,32,16,26,0xCFD8DC,d.id);
    shape(root,cyl,'factory fan grill',i*55,113,-12,21,2,21,0x455A64,d.id);
  }
  architecture.sign(root,d.buildingName||d.name,0,86,-99,175,19,Math.PI,d.id);
  root.userData.modelHeight=220;
}
function modelMine(root, d) {
  shape(root, cyl, 'quarry cut', 0, 3, 0, 260, 8, 260, 0xE9C46A, d.id);
  shape(root, cyl, 'quarry cut 2', 0, 18, 0, 190, 22, 190, 0xCDA35A, d.id);
  shape(root, cone, 'ore pile', -105, 28, -80, 85, 90, 85, 0xCDA35A, d.id);
  box(root, 'crusher shed', 110, 25, 80, 110, 50, 90, 0xE76F51, d.id);
}
function modelBusStand(root, d) {
  box(root, 'bus stand platform', 0, 2, 0, 300, 4, 170, 0x2b3335, d.id);
  box(root, 'terminal hall', -55, 34, 0, 145, 68, 95, 0x8fb0a7, d.id);
  box(root, 'terminal roof', -55, 74, 0, 168, 12, 110, 0x1d2f36, d.id);
  for (let i = 0; i < 3; i++) modelBus(root, 55 + i * 48, 14, -48 + i * 42, 0);
}
function modelShipyard(root, d) {
  box(root, 'shipyard quay', 0, 3, -65, 380, 6, 140, 0xd7d5c5, d.id);
  box(root, 'water basin', -20, .6, 125, 430, 1, 190, 0x165d74, d.id);
  box(root, 'warehouse', 120, 42, -55, 180, 84, 110, 0xcdd4ce, d.id);
  for (let i = -1; i <= 1; i++) {
    box(root, 'crane leg', -90 + i * 60, 72, 20, 12, 144, 12, 0xf0b53d, d.id);
    box(root, 'crane beam', -90 + i * 60, 150, 20, 125, 14, 14, 0xf0b53d, d.id);
  }
  const vessel=modelShip(root, -80, 10, 125, d.id);vessel.scale.setScalar(.64);
  for(let i=0;i<6;i++)for(let tier=0;tier<2;tier++){
    const x=-150+(i%3)*67,z=-85+Math.floor(i/3)*44;
    box(root,'cargo container',x,16+tier*26,z,60,25,36,[0x446a90,0xc88250,0x65918a][i%3],d.id);
    for(let r=-2;r<=2;r++)box(root,'container corrugated rib',x+r*10,16+tier*26,z+19,1,23,1,0xa6b7b7,d.id);
  }
  box(root,'shipyard gantry crossbeam',-30,165,15,270,12,12,0xe3bb62,d.id);
  for(let i=-1;i<=1;i++)box(root,'crane hoist cable',-30+i*70,129,20,2,65,2,0x475a64,d.id);
  root.userData.modelHeight=205;
}
function modelAirport(root, d) {
  box(root, 'runway', -140, 1, 0, 80, 2, 900, 0x20282f, d.id);
  for (let z = -380; z <= 380; z += 95) box(root, 'runway stripe', -140, 3, z, 8, 1, 42, 0xf0f0e4, d.id);
  box(root, 'terminal', 155, 42, -70, 280, 84, 160, 0x5b9fbc, d.id);
  box(root, 'terminal glass', 155, 42, -154, 245, 38, 5, 0x9ce2e9, d.id);
  box(root, 'control tower', 10, 95, 300, 54, 190, 54, 0xd3d9d0, d.id);
  box(root, 'tower cabin', 10, 202, 300, 95, 35, 90, 0x4f99b9, d.id);
  modelPlane(root, 110, 18, -265, d.id);
  box(root,'airport parking apron',155,1,285,285,2,240,0xa7b2ae,d.id);
  modelPlane(root,110,18,290,d.id);
  for(let row=0;row<3;row++){
    for(let i=-6;i<=6;i++)for(const side of [-1,1])box(root,'terminal rear reflective glass',155+i*19,15+row*24,-70+side*84,17,17,2,0x487d9a,d.id);
    for(let i=-3;i<=3;i++)for(const side of [-1,1])box(root,'terminal side reflective glass',155+side*143,15+row*24,-70+i*18,2,17,16,0x487d9a,d.id);
  }
  for(let i=-6;i<=6;i++)box(root,'terminal rear bronze mullion',155+i*19-9,42,16,1.6,76,2,0xbba778,d.id);
  box(root,'hangar rear window band',155,56,245,210,17,2,0x54859c,d.id);
  for(let i=0;i<6;i++){
    box(root,'terminal floor band',155,12+i*12,-155,250,2,5,0xf0e5cd,d.id);
    shape(root,cyl,'runway approach light',-188,5,-370+i*140,4,7,4,0xefc57c,d.id);
  }
  box(root,'airport hangar',155,38,165,240,76,155,0xd7d8cb,d.id);
  box(root,'hangar sliding door',155,33,84,200,59,5,0x718da1,d.id);
  architecture.sign(root,'AIRPORT',155,76,-160,150,18,Math.PI,d.id);
  root.userData.modelHeight=230;
}
function modelLand(root,d){
  const g=new T.Group();g.name='land survey';root.add(g);
  box(g,'empty land soil',0,2,0,680,4,960,0x24323e,d.id);
  for(const s of [-1,1]){
    box(g,'land survey edge',s*345,6,0,3,4,965,0xf59e0b,d.id);
    box(g,'land survey edge',0,6,s*485,690,4,3,0xf59e0b,d.id);
    for(const t of [-1,1])box(g,'survey marker',s*340,15,t*480,8,30,8,0x38bdf8,d.id);
  }
  architecture.sign(g,'VACANT LAND',0,35,470,180,28,0,d.id);
}
function modelShowroom(root,d){
  architecture.build(root,{...d,model:'supermart'});
  architecture.sign(root,d.buildingName||d.name,0,60,91,195,22,0,d.id);
  if(d.model==='bike'){
    for(let i=-2;i<=2;i++){
      const g=new T.Group();g.position.set(i*43,10,127);root.add(g);
      box(g,'bike fuel tank',0,7,0,19,9,8,[0xb76144,0x456d8b,0xc9ac62][(i+3)%3],d.id);
      box(g,'bike seat',-5,13,0,15,3,8,0x243844,d.id);
      box(g,'bike steel frame',0,2,0,27,3,3,0xb2bab6,d.id);
      for(const x of [-12,12]){const m=shape(g,cyl,'bike wheel',x,0,0,10,3,10,0x23333b,d.id);m.rotation.x=Math.PI/2;}
      box(g,'bike handlebar',12,14,0,3,3,15,0xc0c7c4,d.id);
    }
  }else for(let i=-2;i<=2;i++)modelCar(root,i*43,126,Math.PI/2,[0xb75442,0x436e91,0xe3d8ba,0x7a8d78,0xbd9c4d][i+2]);
}
function modelPub(root,d){
  architecture.build(root,{...d,model:'supermart'});
  architecture.sign(root,d.buildingName||d.name,0,67,90,190,22,0,d.id);
  box(root,'pub striped terrace canopy',0,52,120,210,7,48,0x826853,d.id);
  for(let i=-2;i<=2;i++){
    shape(root,cyl,'pub outdoor table',i*40,22,128,22,3,22,0xbca878,d.id);
    shape(root,cyl,'pub table pedestal',i*40,11,128,4,22,4,0x829293,d.id);
    for(const s of [-1,1])box(root,'pub chair',i*40+s*12,9,136,8,18,9,0x517474,d.id);
  }
}
function attachMajorTiers(root,d){
  if(root.userData.architecture||d.model==='land')return;
  const size={shop:[120,95,86,0,0],factory:[190,125,115,0,0],market:[120,65,50,0,0],
    mine:[90,65,63,105,80],busstand:[135,85,83,-55,0],shipyard:[160,90,91,120,-55],airport:[245,120,117,155,-70]}[d.model];
  if(!size)return;
  const [w,dep,base,x,z]=size,groups=[];
  for(let i=0;i<5;i++){
    const g=new T.Group();g.position.set(x,base+i*23,z);root.add(g);
    box(g,'upgrade floor volume',0,11,0,w,22,dep,0xd7d4c3,d.id);
    box(g,'upgrade floor band',0,23,0,w+4,3,dep+4,0xeee2c7,d.id);
    for(let j=-3;j<=3;j++)for(const side of [-1,1])box(g,'upgrade floor glass',j*w*.12,12,side*(dep/2+.7),w*.085,14,1.5,0x426d85,d.id);
    g.scale.setScalar(.000001);groups.push(g);
  }
  root.userData.majorTiers={groups,level:1,base,pitch:23};
}
function modelTower(root, d) {
  box(root, 'tower podium', 0, 18, 0, 170, 36, 145, 0xFFE0B2, d.id);
  box(root, 'tower shaft', 0, 115, 0, 115, 230, 105, 0xFFE0B2, d.id);
  for (let f = 0; f < 8; f++) box(root, 'window band', 0, 45 + f * 24, -55, 100, 8, 4, 0x64B5F6, d.id);
}
function modelBus(parent, x, y, z, yaw) {
  const g = new T.Group();
  g.position.set(x, y, z);
  g.rotation.y = yaw;
  parent.add(g);
  box(g, 'bus body', 0, 0, 0, 60, 22, 24, 0xeac24a);
  box(g, 'bus glass', 0, 8, -13, 50, 10, 2, 0x4ba7bd);
  graphics.vehicleDetails(g, 'bus');
  return g;
}
function modelShip(parent, x, y, z, assetId = null) {
  const g = new T.Group();
  g.position.set(x, y, z);
  parent.add(g);
  shape(g, shipHullGeometry, 'ship rounded steel hull', 0, -12, 0, 1, 1, 1, 0x24313a, assetId);
  box(g,'ship cargo deck',0,18,0,77,5,202,0xc7c1a8,assetId);
  box(g, 'ship cabin', 0, 32, -72, 65, 42, 65, 0xe8efe9, assetId);
  box(g,'ship bridge glass',0,45,-37,54,11,2,0x497f97,assetId);
  for(let i=0;i<3;i++)for(const side of [-1,1])box(g,'ship deck container',side*19,33,-8+i*37,33,25,32,[0xab7151,0x597b94,0x829879][i],assetId);
  for(const side of [-1,1]){
    box(g,'ship guardrail',side*38,26,5,1.3,2,178,0xd4cbb3,assetId);
    for(let i=-3;i<=3;i++)box(g,'ship rail post',side*38,22,5+i*26,1.3,9,1.3,0xd4cbb3,assetId);
  }
  shape(g,cyl,'ship mast',0,75,-72,3,60,3,0xc5c8bc,assetId);
  return g;
}
function modelPlane(parent, x, y, z, assetId = null) {
  const g = new T.Group();
  g.position.set(x, y, z);
  parent.add(g);
  shape(g, graphics.sphere, 'plane body', 0, 0, 0, 24, 18, 105, 0xecf2ef, assetId);
  box(g, 'plane wing', 0, -1, -8, 130, 5, 24, 0xcddad7, assetId);
  box(g, 'plane tail', 0, 18, 47, 8, 26, 18, 0x4d96b4, assetId);
  box(g,'plane stabilizer',0,4,40,44,3,13,0xd8e1da,assetId);
  shape(g,graphics.sphere,'plane cockpit glass',0,4,-37,17,9,21,0x456b81,assetId);
  for(const side of [-1,1]){
    const engine=shape(g,cyl,'plane engine steel',side*30,-6,-3,11,32,11,0x9cb1b5,assetId);engine.rotation.x=Math.PI/2;
    for(let i=0;i<6;i++)box(g,'plane cabin window',side*11,3,-24+i*9,1.3,4,3.3,0x4b6d80,assetId);
  }
  return g;
}

const modelMap = {
  land:modelLand,showroom:modelShowroom,bike:modelShowroom,pub:modelPub,
  house: modelHouse,
  villa: modelHouse,
  apartment: modelApartment,
  shop: modelShop,
  market: modelMarket,
  supermart: modelSupermart,
  mall: modelMall,
  factory: modelFactory,
  mine: modelMine,
  busstand: modelBusStand,
  shipyard: modelShipyard,
  airport: modelAirport,
  tower: modelTower
};

function districtCenter(id) {
  return districts.find(d => d.id === id).center;
}

function buildWorld() {
  box(scene, '250000m empire base', 0, -12, 0, WORLD_SIZE_METERS, 12, WORLD_SIZE_METERS, 0x1e293b);
  box(scene, 'active city base', 0, -5, 620, ACTIVE_CITY_METERS.width, 10, ACTIVE_CITY_METERS.depth, 0x1e293b);

  // Scenic Coastal Shoreline, Beach, Promenade & Ocean Bay
  box(scene, 'coastal beach sand', 3350, 0.2, 7150, 5800, 2, 400, 0xE9C46A);
  box(scene, 'promenade quay wall', 3350, 0.4, 6980, 5800, 3, 60, 0x455A64);
  box(scene, 'coastal promenade path', 3350, 0.3, 6920, 5800, 1, 60, 0xCFD8DC);
  graphics.water(scene, 'ocean coastal bay', 3350, 8200, 6800, 2400, -1.5);
  box(scene, 'airport apron extension', 460, 2, 3290, 2650, 3, 360, 0x455A64);

  // High-Poly Steel Suspension Bridges over River & Coastal Water Channels
  function addHighPolyBridge(name, x, y, z, width, length, isHorizontal = false) {
    const bg = new T.Group();
    bg.position.set(x, y, z);
    scene.add(bg);
    box(bg, name + ' deck', 0, 4, 0, isHorizontal ? length : width, 5, isHorizontal ? width : length, 0x334155);
    box(bg, name + ' road surface', 0, 6.8, 0, isHorizontal ? length : width - 4, 1, isHorizontal ? width - 4 : length, 0x1e293b);
    [-length * 0.3, length * 0.3].forEach(pOffset => {
      const px = isHorizontal ? pOffset : 0;
      const pz = isHorizontal ? 0 : pOffset;
      box(bg, name + ' pillar base', px, -8, pz, isHorizontal ? 20 : width + 8, 22, isHorizontal ? width + 8 : 20, 0x475569);
      [-width / 2 - 2, width / 2 + 2].forEach(side => {
        const tx = isHorizontal ? px : side;
        const tz = isHorizontal ? side : pz;
        box(bg, name + ' steel tower', tx, 22, tz, 6, 42, 6, 0x38bdf8);
      });
    });
  }
  addHighPolyBridge('Coastal Bay Highway Bridge', -2800, 2, 3600, 100, 950, true);
  addHighPolyBridge('River Inlet Metro Bridge', 1200, 2, 3500, 90, 700, false);

  // District zoning is semantic; continuous paving replaces dark boxed borders.
  districts.forEach(d => {
    const color = ['commercial', 'corporate', 'residential', 'education'].includes(d.id) ? 0xb5b5a2 : 0x9eaa8c;
    box(scene, d.name + ' land', d.center[0], .5, d.center[1], d.size[0], 1, d.size[1], color);
  });

  [-2320, -850, 620, 1990, 3160].forEach(z => road(0, z, 10100, false, z === 620 ? 112 : 92));
  [-4520, -2750, -850, 1250, 3050, 4250].forEach(x => road(x, 470, 6800, true, x === 1250 ? 112 : 92));
  [-2750, -850, 1250, 3050].forEach(x => [-2320, -850, 620, 1990, 3160].forEach(z => {
    if ((x === -850 && z === -850) || (x === 1250 && z === -850)) return;
    intersection(x, z);
  }));
  roundabout(-850, -850);
  roundabout(1250, -850);
  districts.filter(d=>d.growth).forEach(d=>{
    const step=d.id==='development'?1160:1060;
    for(let row=0;row<4;row++){
      const z=d.center[1]+(row-1.5)*step;
      const curve=new T.CatmullRomCurve3([new T.Vector3(d.center[0]-2100,12,z),new T.Vector3(d.center[0],12,z+7),new T.Vector3(d.center[0]+2100,12,z)]);
      graphics.curvedRoad(curve,d.id==='development'?60:72,'district boulevard');
    }
    for(const side of [-1,1]){
      const x=d.center[0]+side*2030;
      const curve=new T.CatmullRomCurve3([new T.Vector3(x,12,d.center[1]-2700),new T.Vector3(x+side*18,12,d.center[1]),new T.Vector3(x,12,d.center[1]+2700)]);
      graphics.curvedRoad(curve,64,'district connector');
    }
  });
  // Both buses and the visible curved orbital boulevard use this same path.
  graphics.curvedRoad(roundedRectangleCurve(-5000, -2550, 4580, 3520, 320), 118, 'orbital boulevard');

  assetDefs.forEach(groupAsset);
  buildReferenceDensity();
  architecture.park(-400, -1330);
  for (const lot of reservedLots.filter(l => l.scenery === 'terrace tower')) {
    const g = new T.Group(); g.position.set(lot.x, 0, lot.z); scene.add(g);
    architecture.build(g, { id: null, model: 'tower', name: lot.x < 200 ? 'VENTURE ONE' : 'BHARAT TOWERS', max: 1, floors: lot.x < 200 ? 20 : 24, width: 180, depth: 160 });
  }
  const infillDistricts = districts.filter(d => ['residential', 'commercial', 'corporate'].includes(d.id));
  let infill = 0;
  for (const district of infillDistricts) {
    for (let z = district.center[1] - district.size[1] / 2 + 110; z < district.center[1] + district.size[1] / 2 - 110; z += 225) {
      for (let x = district.center[0] - district.size[0] / 2 + 105; x < district.center[0] + district.size[0] / 2 - 105; x += 220) {
        if (district.id === 'commercial' && x > 90 && x < 770 && z > -1820) continue;
        if (!lotIsClear(x, z, 170, 170, district, 20)) continue;
        reservedLots.push({x, z, width: 170, depth: 170, scenery: 'infill apartments'});
        const g = new T.Group(); g.position.set(x, 0, z); scene.add(g);
        architecture.build(g, {id: null, model: 'apartment', name: 'City Apartments', max: 1,
          floors: 5 + (infill * 7 % 8), width: 124, depth: 112});
        architecture.tree(g, -73, 57, .72, 12);
        architecture.tree(g, 73, -56, .6, 12);
        infill++;
      }
    }
  }
  graphics.stats.infillBuildings = infill;
  architecture.streets(); architecture.backdrop(reservedLots);
  Object.assign(graphics.stats, architecture.stats);
  graphics.batchStaticWorld();
  for(const item of assets.values())if(item.def.kind==='land'&&own(item.def.id)?.blueprintId)graphics.batchStaticWorld(item.construction.building);
  graphics.addTraffic(modelCar);
  renderer.shadowMap.needsUpdate = true;
}

function roundabout(x, z, radius = 126) {
  const points = Array.from({ length: 32 }, (_, i) => {
    const a = i * Math.PI * 2 / 32;
    return new T.Vector3(x + Math.cos(a) * radius, 12, z + Math.sin(a) * radius);
  });
  const curve = new T.CatmullRomCurve3(points, true, 'centripetal'); curve.userData = { closed: true };
  graphics.curvedRoad(curve, 54, 'roundabout');
  shape(scene, cyl, 'roundabout garden', x, 13, z, 180, 2, 180, 0x577a52);
  const curb = new T.TorusGeometry(89, 2.5, 8, graphics.quality.radialSegments);
  const ring = shape(scene, curb, 'roundabout curb', x, 15, z, 1, 1, 1, 0xe3d6ba);
  ring.rotation.x = Math.PI / 2;
  shape(scene, cyl, 'roundabout monument base', x, 21, z, 44, 16, 44, 0xe7d9be);
  shape(scene, cyl, 'roundabout bronze monument', x, 67, z, 8, 90, 8, 0xb58b42);
  for (let i = 0; i < 8; i++) {
    const a = i * Math.PI / 4; architecture.planter(scene, x + Math.cos(a) * 60, 14, z + Math.sin(a) * 60, 23, 13);
  }
}

function intersection(x, z, size = 176) {
  box(scene, 'intersection asphalt', x, 12, z, size, .5, size, 0x303940);
  for (let i = -2; i <= 2; i++) {
    box(scene, 'crosswalk ns', x + i * 18, 12.8, z - size / 2 + 20, 8, 1, 34, 0xf0efe0);
    box(scene, 'crosswalk sn', x + i * 18, 12.8, z + size / 2 - 20, 8, 1, 34, 0xf0efe0);
    box(scene, 'crosswalk ew', x - size / 2 + 20, 12.8, z + i * 18, 34, 1, 8, 0xf0efe0);
    box(scene, 'crosswalk we', x + size / 2 - 20, 12.8, z + i * 18, 34, 1, 8, 0xf0efe0);
  }
}

function buildReferenceDensity() {
  addTreeGrid(scene, -3460, -2000, 6, 3, 180, 1.1);
  addTreeGrid(scene, 1600, -1760, 6, 3, 170, 1.05);
  addTreeGrid(scene, -5200, 1180, 4, 7, 170, 1.05);
  addTreeGrid(scene, 4230, 1350, 3, 6, 160, .95);


  const parking = (id, dx, dz, cols) => {
    const district = districts.find(d => d.id === id), width = cols * 58 + 45, depth = 132;
    const options = [];
    for (let x = -800; x <= 800; x += 50) for (let z = -800; z <= 800; z += 50) options.push([x, z]);
    options.sort((a, b) => a[0] * a[0] + a[1] * a[1] - b[0] * b[0] - b[1] * b[1]);
    const origin = [district.center[0] + dx, district.center[1] + dz];
    const found = options.find(([x, z]) => lotIsClear(origin[0] + x, origin[1] + z, width, depth, district));
    if (!found) return;
    const [x, z] = [origin[0] + found[0], origin[1] + found[1]];
    reservedLots.push({ x, z, width, depth }); addParking(scene, x, z, cols, 2);
  };
  parking('residential', 170, 570, 7);
  parking('commercial', 210, 650, 8);
  parking('education', 520, 480, 6);
  parking('airport', 140, 650, 6);

  for (let i = 0; i < 40; i++) {
    if (i < 24) modelStreetLight(scene, -4400 + i * 360, 680, i % 2 ? Math.PI : 0);
  }

  const port = districtCenter('port');
  for (let i = 0; i < 7; i++) {
    box(scene, 'container red', port[0] - 850 + i * 135, 24, port[1] + 260, 110, 44, 54, i % 2 ? 0x2c76c5 : 0xd94d35);
    box(scene, 'container blue', port[0] - 820 + i * 135, 68, port[1] + 260, 110, 44, 54, i % 2 ? 0xf0b83f : 0x2c76c5);
  }
  for (let i = 0; i < 8; i++) modelPalm(scene, port[0] - 1100 + i * 275, port[1] + 680, 1.15);

  const mine = districtCenter('mining');
  for (let r = 0; r < 3; r++) {
    shape(scene, cone, 'ore mound', mine[0] + 360 + r * 140, 24, mine[1] - 260 + r * 210, 95, 72, 95, [0x4b463c, 0x675841, 0x7a6746][r]);
  }
}

buildWorld();

const labelLayer = $('labels');
const districtLabels = districts.map((d) => {
  const el = document.createElement('div');
  el.className = 'label';
  el.textContent = d.name;
  labelLayer.append(el);
  return { el, x: d.center[0], z: d.center[1], y: 190 };
});
const assetLabels = ['mall', 'vegmarket', 'restaurant', 'shipyard_east', 'shipyard_west', 'airport_metro', 'bus_corp', 'school', 'hospital'].map((id) => {
  const d = assetDefs.find(a => a.id === id);
  const el = document.createElement('div');
  el.className = 'label asset';
  el.textContent = d.name;
  labelLayer.append(el);
  return { el, x: d.x, z: d.z, y: 150 };
});
const labels = districtLabels.concat(assetLabels);

let focus = { x: 350, z: -1570 };
let target = { x: 350, z: -1570 };
let zoom = innerWidth < 700 ? 780 : 900;
let targetZoom = zoom;
let focusElevation = 400, targetElevation = 400;
let assetCamera = false;
let dragging = false;
let dragStart = null;
const raycaster = new T.Raycaster();
const pointer = new T.Vector2();

function updateCamera() {
  camera.aspect = innerWidth / innerHeight;
  const dist = zoom * 3.8;
  const center = new T.Vector3(focus.x, focusElevation, focus.z);
  // Selected plots sit above the property card, including low construction
  // sites. The same projection is used by picking and ground-projected panning.
  camera.setViewOffset(innerWidth, innerHeight, 0, assetCamera ? Math.round(innerHeight * .14) : 0, innerWidth, innerHeight);
  camera.position.copy(center).add(new T.Vector3(.38, .68, 1).normalize().multiplyScalar(dist));
  camera.lookAt(center);
  camera.updateProjectionMatrix();
}
function resize() {
  renderer.setSize(innerWidth, innerHeight);
  updateCamera();
}
addEventListener('resize', resize);
resize();

function groundToScreen(x, y, z) {
  const p = new T.Vector3(x, y, z).project(camera);
  return { x: (p.x * .5 + .5) * innerWidth, y: (-p.y * .5 + .5) * innerHeight, visible: p.z < 1 && Math.abs(p.x) < 1.1 && Math.abs(p.y) < .9 };
}
function updateLabels() {
  labels.forEach((l) => {
    const p = groundToScreen(l.x, l.y, l.z);
    l.el.style.display = p.visible && zoom < 3400 ? 'block' : 'none';
    l.el.style.left = p.x + 'px';
    l.el.style.top = p.y + 'px';
  });
}

function own(id) {
  return state.owned[id] || null;
}
function now() { state.clock.lastAt = Math.max(Date.now(), state.clock.lastAt || 0); return state.clock.lastAt; }
function constructionProgress(o) { return rawConstructionProgress(o, now()); }
function isWorking(o) { return !!(o?.daysLeft || o?.constructionEndAt); }
function remainingLabel(o) { return o?.constructionEndAt ? timeLabel(Math.max(0,o.constructionEndAt-now()))+' remaining' : o?.daysLeft+' game day(s) remaining'; }
function applyBlueprint(d, id) {
  const b=BLUEPRINTS.find(x=>x.id===id);if(!b)return false;
  Object.assign(d,{model:b.model,income:b.income,upkeep:b.upkeep,buildingName:b.name,note:b.name+' on player-owned land'});
  return true;
}
function category(d) {
  if(d.category)return d.category;
  if(['house','villa','apartment'].includes(d.model))return 'Homes';
  if(['factory','mine'].includes(d.model))return 'Industry';
  if(['airport','shipyard','busstand'].includes(d.model))return 'Transport';
  if(['school','college','hospital'].includes(d.id))return 'Civic';
  return d.model==='tower'?'Offices':'Retail';
}
function tagAssetMeshes(item) {
  const o=own(item.def.id), tint={original:0xffffff,sky:0xb8edff,jade:0xbdebd1,warm:0xffd6ab}[o?.style||'original'];
  item.root.traverse(m=>{
    if(!m.isMesh)return;
    if(item.def.expansion)m.userData.batchRegion=Math.floor(item.def.x/1200)+':'+Math.floor(item.def.z/1200);
    if(/floor volume|factory hall|shop body|tower shaft|supermart body|roof crown/.test(m.name))m.userData.remodelTint=tint;
  });
  if(item.def.kind==='land')item.construction.building.traverse(m=>{if(m.isMesh)m.userData.deferredBatch=true;});
}
function installPlotBuilding(item) {
  const before=new Set(item.root.children),d={...item.def,name:item.def.buildingName||item.def.name};
  if(!architecture.build(item.root,d)){(modelMap[d.model]||modelMap.shop)(item.root,d);graphics.enrichAsset(item.root,d);}
  attachMajorTiers(item.root,d);
  for(const child of [...item.root.children])if(!before.has(child))item.construction.building.add(child);
  item.construction.building.traverse(m=>{if(m.isMesh)m.userData.assetId=item.def.id;});
  item.construction.key='';
  tagAssetMeshes(item);constructionSites.update(item,own(item.def.id));
  graphics.batchStaticWorld(item.construction.building);
  item.construction.key=''; // Refresh the already-instanced construction site too.
}
function clearPlotBuilding(item){
  const removed=new Set();item.construction.building.traverse(m=>{if(m.isMesh)removed.add(m);});
  graphics.clearScopedBatches(item.construction.building);
  for(let i=pickables.length-1;i>=0;i--)if(removed.has(pickables[i]))pickables.splice(i,1);
  item.construction.building.clear();delete item.root.userData.architecture;delete item.root.userData.atrium;delete item.root.userData.majorTiers;
  Object.assign(item.def,{model:'land',income:0,upkeep:0,buildingName:null});item.construction.key='';
}
function startTimedWork(d,o,kind,target,cost) {
  o.constructionDurationMs=durationMs(d,target);
  o.constructionEndAt=now()+o.constructionDurationMs;
  o.constructionCost=cost;o.constructionKind=kind;o.targetLevel=target;
  o.daysLeft=o.constructionTotal=0;
}
function finishConstruction(id){
  const o=own(id);if(!o||!isWorking(o))return false;
  const upgraded=o.constructionKind==='upgrade';
  o.level=o.targetLevel;o.daysLeft=o.constructionTotal=o.constructionEndAt=o.constructionDurationMs=0;
  o.constructionKind=null;o.condition=100;
  addXp(upgraded?25+o.level*10:20,'complete:'+id+':'+o.level);
  const text=(o.customName||assetDefs.find(d=>d.id===id)?.buildingName||assetDefs.find(d=>d.id===id)?.name)+' ready at Level '+o.level;
  logCity(text);state.last=text;
  return true;
}
function settleConstruction(){
  let changed=false;const time=now();
  for(const [id,o] of Object.entries(state.owned))if(o.constructionEndAt&&time>=o.constructionEndAt)changed=finishConstruction(id)||changed;
  return changed;
}
function startBuild(plotId,blueprintId){
  settleConstruction();
  const d=assetDefs.find(a=>a.id===plotId),o=own(plotId),b=BLUEPRINTS.find(a=>a.id===blueprintId);
  if(!d||d.kind!=='land'||!o?.landOnly||isWorking(o)||!b){toast('Buy a vacant land plot before choosing a building.');return false;}
  const req=requirementText({...b,id:d.id});if(req){toast(req);return false;}
  if(!spend(b.price,'Build '+b.name+' on '+d.name))return false;
  o.landOnly=false;o.blueprintId=b.id;o.buildValue=b.price;o.customName=b.name;
  applyBlueprint(d,b.id);startTimedWork(d,o,'build',1,b.price);
  addXp(18+Math.min(220,Math.round(b.price/CR)),'build:'+d.id);
  save();installPlotBuilding(assets.get(d.id));
  state.last='Construction started: '+b.name+' · '+money(b.price)+' · '+timeLabel(o.constructionDurationMs)+'. Land was paid separately.';
  logCity(state.last);toast(state.last);refreshPanel();return true;
}
function fastFinish(){
  settleConstruction();const d=selectedDef(),o=d&&own(d.id);
  if(!o?.constructionEndAt){refreshPanel();return false;}
  const cost=fastFinishPrice(o,now());if(!spend(cost,'Instant finish '+d.name))return false;
  finishConstruction(d.id);state.last+=' · instant finish '+money(cost);toast(state.last);refreshPanel();return true;
}
function remodel(name,style){
  const d=selectedDef(),o=d&&own(d.id);if(!o||o.landOnly||isWorking(o))return false;
  if(!['original','sky','jade','warm'].includes(style))return false;
  if(!spend(2500,'Remodel '+d.name))return false;
  o.customName=String(name||d.buildingName||d.name).trim().slice(0,48)||d.name;
  o.style=style;o.remodelCount++;
  tagAssetMeshes(assets.get(d.id));graphics.syncInstances(new Set([d.id]));
  state.last='Remodeled '+o.customName+' · '+money(2500)+' · change '+o.remodelCount;logCity(state.last);toast(state.last);refreshPanel();return true;
}
function payTax(){
  const amount=state.taxes.due;if(amount<=0)return false;
  if(!spend(amount,'Playable City tax payment'))return false;
  state.taxes.due=0;state.taxes.paid+=amount;
  state.last='Paid city tax '+money(amount);logCity(state.last);toast(state.last);refreshPanel();return true;
}
function salePrice(d){
  const o=d&&own(d.id);
  if(!o)return 0;
  const baseVal=d.price+(o.buildValue||0);
  const upgVal=Math.max(0,( (o.level||1)-1 )*(d.price*.35));
  const totalVal=baseVal+upgVal;
  return Math.round(totalVal*.85*conditionMultiplier(o));
}
function incomeReport(){
  let gross=0,upkeep=0;
  for(const d of assetDefs){const o=own(d.id);if(!o||o.landOnly)continue;
    gross+=scaledIncome(d)+(isWorking(o)?0:o.buses*8000+o.ships*1200000);
    upkeep+=scaledUpkeep(d)+o.buses*2600+o.ships*280000;
  }return {gross,upkeep};
}
function ownedCount() {
  return Object.keys(state.owned).length;
}
function ownedByModel(model) {
  return Object.keys(state.owned).filter(id => assetDefs.find(a => a.id === id)?.model === model).length;
}
function ownsModel(model) {
  return ownedByModel(model) > 0;
}
function ownsKind(kind) {
  return Object.keys(state.owned).some(id => {const d=assetDefs.find(a=>a.id===id);return d?.kind===kind || kind==='house' && !own(id).landOnly && ['house','villa','apartment'].includes(d?.model);});
}
function totalBuses() {
  return Object.values(state.owned).reduce((sum, o) => sum + (Number(o.buses) || 0), 0);
}
function totalShips() {
  return Object.values(state.owned).reduce((sum, o) => sum + (Number(o.ships) || 0), 0);
}
function cityLevel() {
  state.highestCityLevel = Math.max(state.highestCityLevel || 1, levelFromXp(state.xp));
  return state.highestCityLevel;
}
function currentCycle() {
  return economyCycles[state.cycle] || economyCycles.stable;
}
function taxRateFor(gross) {
  return 0.02;
}
function conditionMultiplier(o) {
  return Math.max(0.5, Math.min(1.25, ((o?.condition || 100) / 100) * 1.25));
}
function utilityIncomeMultiplier() {
  return (state.utilities.power ? 1.25 : 1.0) * (state.utilities.water ? 1.20 : 1.0);
}
function utilityDecayMultiplier() {
  return state.utilities.power && state.utilities.water ? .55 : state.utilities.power || state.utilities.water ? .78 : 1;
}
function constructionDays(d) {
  if (d.model === 'airport' || d.model === 'shipyard') return 5;
  if (d.price >= 50 * CR) return 4;
  return 3;
}
function requirementText(d) {
  return '';
}
function isUnlocked(d) {
  return true;
}
function levelOf(id) {
  return own(id)?.level || 0;
}
function scaledIncome(d, o = own(d.id)) {
  if (!o) return d.income;
  if (isWorking(o) || o.landOnly) return 0;
  const levelMult = 1 + (o.level - 1) * 1.5;
  const condMult = conditionMultiplier(o);
  const utilMult = utilityIncomeMultiplier();
  const cycleMult = currentCycle().income;
  return Math.round(d.income * levelMult * condMult * utilMult * cycleMult);
}
function scaledUpkeep(d, o = own(d.id)) {
  if (o?.landOnly) return 0;
  if (!o) return d.upkeep;
  return Math.round(d.upkeep * (1 + (o.level - 1) * .28) * currentCycle().upkeep);
}
function upgradePrice(d) {
  const o = own(d.id);
  if (!o || o.level >= d.max) return 0;
  return Math.round((o.buildValue || d.price) * (.32 + o.level * .18));
}
function repairPrice(d) {
  const o = own(d.id);
  if (!o || o.landOnly || isWorking(o) || o.condition >= 96) return 0;
  return Math.round((100 - o.condition) * Math.max(1000, (o.buildValue || d.price) * .002));
}
function logCity(text) {
  state.history.unshift('Day ' + state.day + ': ' + text);
  state.history = state.history.slice(0, 20);
}
function addXp(value, key, daily = false) {
  return awardCityXp(state, value, key, daily);
}
function dailyCityXp(gross, net) {
  const owned = assetDefs.filter(d => own(d.id));
  if (!owned.length) return 0;
  let xp = 100;
  if (owned.length >= 5) xp += 50;
  if (new Set(owned.map(d => d.district)).size >= 3) xp += 50;
  if (state.utilities.power && state.utilities.water) xp += 50;
  if (owned.every(d => own(d.id).condition >= 80 && !isWorking(own(d.id)))) xp += 50;
  if (gross > 0 && net > 0) xp += 50;
  return xp;
}
function refreshProgressionHUD() {
  const beforeXp = state.xp, beforeWindow = state.cityProgression.windowStartedAt;
  const p = cityProgressionStatus(state);
  const totalMinutes = Math.ceil(p.resetsInMs / 60000), hours = Math.floor(totalMinutes / 60), minutes = totalMinutes % 60;
  $('topLevel').textContent = String(p.level);
  $('topLevelFill').style.width = Math.round(p.fraction * 100) + '%';
  $('xpSummary').textContent = 'City L'+p.level+' / 300 · XP '+p.levelXp.toLocaleString('en-IN')+' / '+p.nextCost.toLocaleString('en-IN');
  if(p.level===300)$('xpSummary').textContent='City L300 / 300 · '+p.totalXp.toLocaleString('en-IN')+' XP';
  $('dailyXpSummary').textContent = 'Today '+p.usedXp+' / 350 XP';
  $('visibleXpFill').style.width = Math.round(p.fraction*100)+'%';
  $('openProgression').setAttribute('aria-label', 'City level ' + p.level + ' of 300. Show progression');
  $('cityLevel').textContent = p.level + ' / 300';
  $('cityXp').textContent = p.totalXp.toLocaleString('en-IN');
  $('progressionSummary').textContent = p.rank + ' · ' + (p.level === 300 ? 'Maximum City Level reached' : p.toNext.toLocaleString('en-IN') + ' XP to Level ' + (p.level + 1)) + ' · Today ' + p.usedXp + '/' + DAILY_XP_CAP + ' XP · Refresh in ' + hours + 'h ' + minutes + 'm' + (p.pendingXp ? ' · Earned XP waiting: ' + p.pendingXp.toLocaleString('en-IN') : '');
  $('cityXpFill').style.width = Math.round(p.fraction * 100) + '%';
  if (state.xp !== beforeXp || state.cityProgression.windowStartedAt !== beforeWindow) save();
}
function completeMissions() {
  const completed = [];
  missionDefs.forEach(m => {
    if (state.missions[m.id]) return;
    if (!m.check()) return;
    if(!credit(m.reward, 'City mission reward: ' + m.title))return;
    state.missions[m.id] = true;
    addXp(m.xp, 'mission:' + m.id);
    const line = 'Mission complete: ' + m.title + ' +' + money(m.reward);
    completed.push(line);
    logCity(line);
  });
  if (completed.length) {
    state.last = completed[completed.length - 1];
    toast(completed.join('  |  '));
  }
}
function rollCycle() {
  const pattern = ['stable', 'stable', 'boom', 'stable', 'festival', 'monsoon', 'stable', 'slowdown'];
  state.cycle = pattern[state.day % pattern.length];
}
function selectedDef() {
  return assetDefs.find(a => a.id === selected) || null;
}
function toast(text) {
  $('toast').textContent = text;
  $('toast').style.display = 'block';
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => $('toast').style.display = 'none', 3200);
}
function spend(amount, reason) {
  const value = Number(amount);
  if (!Number.isFinite(value) || value <= 0) return false;
  const bridge = bankBridge();
  if (bridge?.spend) {
    const ok = bridge.spend(value, reason || 'Playable City expense');
    syncHostBalance();
    if (!ok) {
      toast('Insufficient FLUX balance for ' + reason + ' (₹' + Math.round(value).toLocaleString('en-IN') + ' needed).');
      return false;
    }
    return true;
  }
  syncHostBalance();
  if (state.balance < value) {
    toast('Not enough FLUX balance for ' + reason + '.');
    return false;
  }
  state.balance -= value;
  return true;
}
function refreshVisuals() {
  const changedAssets = new Set();
  for (const [id, item] of assets) {
    const o = own(id);
    item.mark.visible = !!o;
    const lockScale = o ? .000001 : 1;
    if(item.lock && item.lock.scale.x !== lockScale){item.lock.scale.setScalar(lockScale);changedAssets.add(id);}
    item.mark.scale.y = o ? Math.max(1, o.level * .8) : 1;
    if (constructionSites.update(item, o)) changedAssets.add(id);
    const tiers=item.root.userData.majorTiers;
    const shownLevel=isWorking(o)&&constructionProgress(o).stage===2?o.targetLevel:o?.level||1;
    if(tiers&&tiers.level!==shownLevel){tiers.groups.forEach((g,i)=>g.scale.setScalar(i<shownLevel-1?1:.000001));tiers.level=shownLevel;changedAssets.add(id);}
    if (item.root.userData.architecture) {
      item.root.scale.setScalar(1);
    } else {
      const scale = 1;
      if (item.root.scale.x !== scale) { item.root.scale.setScalar(scale); changedAssets.add(id); }
    }
  }
  for(const id of changedAssets)assets.get(id)?.root.traverse(g=>{if(g.isGroup)g.updateMatrix();});
  if (changedAssets.size) graphics.syncInstances(changedAssets);
  syncDynamicFleet();
}
function refreshPanel() {
  settleConstruction();
  const linked = syncHostBalance();
  completeMissions();
  refreshVisuals();

  if ($('money')) $('money').textContent = money(state.balance);
  if ($('topMoney')) {
    $('topMoney').textContent = money(state.balance);
    if ($('topMoney').parentElement) $('topMoney').parentElement.title = 'Shared bank: ' + money(state.balance);
  }
  refreshProgressionHUD();
  if ($('topCoin')) $('topCoin').textContent = ownedCount();
  if ($('topDay')) $('topDay').textContent = state.day;
  if ($('topCycle')) $('topCycle').textContent = currentCycle().name;
  if ($('cycle')) $('cycle').textContent = currentCycle().name;
  if ($('topGem')) $('topGem').textContent = bankBridge()?.getDiamonds ? String(bankBridge().getDiamonds()) : '0';
  if ($('bankStatus')) $('bankStatus').textContent = (linked ? 'Main FLUX bank linked' : 'City preview bank') + ' · Day ' + state.day + ' · ' + state.last;
  if ($('taxRate')) $('taxRate').textContent = Math.round(taxRateFor(incomeReport().gross) * 100) + '%';
  ['power', 'water'].forEach(id => { if ($(id)) $(id).disabled = state.utilities[id]; });

  const d = selectedDef(), o = d && own(d.id), working = isWorking(o), req = d && !o && requirementText(d);
  if ($('panel')) $('panel').hidden = false;
  const a = d && assets.get(d.id)?.root.userData.architecture;
  if ($('selectedName')) $('selectedName').textContent = o?.customName || d?.name || 'Choose a property';
  if ($('selectedLock')) $('selectedLock').textContent = o ? '✓ Owned' + (o.landOnly ? ' · Vacant land' : ' · Condition ' + Math.round(o.condition) + '%') : 'Unowned · ' + (req || 'Fixed price ' + money(d?.price || 0));
  if ($('buildingSubtitle')) $('buildingSubtitle').textContent = o?.landOnly ? 'Buy land ✓ · Choose a building' : working ? constructionProgress(o).name + ' · ' + remainingLabel(o) : (o ? 'Level ' + o.level + ' / 6' : 'Ready property') + (a ? ' · ' + a.floors + ' floors' : '');
  if ($('selectedMeta')) $('selectedMeta').textContent = d?.note || '';

  if ($('buy')) { $('buy').disabled = !d || !!o || !!req; $('buy').textContent = 'Buy ' + money(d?.price || 0); }
  if ($('upgrade')) { $('upgrade').disabled = !o || o.landOnly || working || o.level >= 6; $('upgrade').textContent = 'Upgrade ' + money(d ? upgradePrice(d) : 0); }
  if ($('sell')) { $('sell').disabled = !o || working; }
  if ($('repair')) { $('repair').disabled = !o || !d || repairPrice(d) <= 0; }
  if ($('special')) { $('special').disabled = !o || working || d?.model !== 'busstand'; }
  if ($('specialShip')) { $('specialShip').disabled = !o || working || d?.model !== 'shipyard'; }

  if ($('quickBuy') && $('buy')) { $('quickBuy').disabled = $('buy').disabled; $('quickBuy').textContent = o ? '✓ Owned' : (d?.kind === 'land' ? 'Buy land ' : 'Buy ') + money(d?.price || 0); }
  if ($('quickSell') && $('sell')) { $('quickSell').disabled = $('sell').disabled; $('quickSell').textContent = o ? 'Sell ' + money(salePrice(d)) : 'Sell'; }
  if ($('primaryAction')) {
    $('primaryAction').textContent = 'MANAGE';
    $('primaryAction').disabled = false;
    $('primaryAction').onclick = (e) => {
      e?.preventDefault();
      e?.stopPropagation();
      cityUI?.show('manage');
    };
  }
  if ($('buildProgress')) {
    $('buildProgress').hidden = !working;
    if (working && $('buildStage')) $('buildStage').textContent = (o.constructionKind === 'upgrade' ? 'Upgrade' : 'Construction') + ' · ' + remainingLabel(o);
  }
  if ($('viewCatalog')) $('viewCatalog').textContent = assetDefs.length + ' properties';
  if ($('assetList')) refreshList(d?.district || 'commercial');
  cityUI?.refresh();
  save();
}
function refreshList(district) {
  const list = assetDefs.filter(a => a.district === district).slice(0, 12);
  $('assetList').innerHTML = '';
  list.forEach((a) => {
    const b = document.createElement('button');
    b.className = 'assetBtn';
    const o = own(a.id);
    const req = requirementText(a);
    const stateText = o ? `L${o.level}/${a.max}${o.daysLeft ? ' · ' + constructionProgress(o).name + ' ' + o.daysLeft + 'd' : ' · ' + Math.round(o.condition) + '%'}` : req ? 'locked: ' + req : 'build on this plot';
    b.innerHTML = `<strong>${a.name}</strong><span>${money(a.price)} · ${stateText} · ${money(a.income)}/day</span>`;
    b.onclick = () => selectAsset(a.id, true);
    $('assetList').append(b);
  });
}
function selectAsset(id, fly = false) {
  selected = id;
  const d = assetDefs.find(a => a.id === id);
  if (d && fly) {
    target.x = d.x;
    target.z = d.z;
    targetZoom = d.model === 'airport' ? 760 : d.model === 'shipyard' ? 900 : d.model === 'tower' ? 720 : d.id === 'mall' ? 600 : 420;
    targetElevation = Math.min(450, assets.get(id)?.root.userData.architecture?.height * .45 || 55);
    assetCamera = true;
    window.previewStable = false;
  }
  refreshPanel();
}

$('openAccount').onclick = () => {
  if (syncHostBalance()) {
    state.last = 'Main FLUX India Bank is already linked.';
    toast(state.last);
    refreshPanel();
    return;
  }
  if (state.account) return toast('Flux Bank account is already active.');
  state.account = true;
  state.last = 'Account opened. Balance starts at ₹0.';
  toast('Flux Bank account opened. Take a loan to begin.');
  refreshPanel();
};
function takeLoan(name, principal) {
  if (state.loans.includes(name)) return toast('Loan already taken in this city save.');
  if (takeHostLoan(name, principal)) {
    state.account = true;
    state.loans.push(name);
    state.last = name + ' credited through FLUX India Bank: ' + money(principal);
    toast(state.last);
    refreshPanel();
    return;
  }
  if (bankBridge()?.takeLoan) return toast('FLUX Bank declined this loan.');
  if (!state.account) return toast('Open bank account first.');
  state.loans.push(name);
  state.balance += principal;
  state.last = name + ' credited: ' + money(principal);
  toast(state.last);
  refreshPanel();
}
$('loanSmall').onclick = () => takeLoan('Growth loan (₹50 Lakh)', 0.5 * CR);
$('loanMega').onclick = () => takeLoan('City loan (₹1 Crore)', 1 * CR);
$('buy').onclick = () => {
  const d = selectedDef();
  if (!d || own(d.id)) return;
  const req = requirementText(d);
  if (req) return toast(req);
  if (!spend(d.price, d.name)) return;
  state.owned[d.id] = normalizeOwned({ level: 1, buses: 0, ships: 0, condition: 100, landOnly:d.kind==='land' });
  if(d.kind!=='land')addXp(18 + Math.min(220, Math.round(d.price / CR)), 'build:' + d.id);
  state.last = 'Bought ' + d.name + ' for the fixed price ' + money(d.price) + (d.kind==='land'?'. Land is owned. Choose a blueprint to build.':'. Property is owned and ready to operate.');
  logCity(state.last);
  toast(state.last);
  selectAsset(d.id, true);
};
$('upgrade').onclick = () => {
  const d = selectedDef();
  const o = d && own(d.id);
  settleConstruction();
  if (!d || !o || o.landOnly || o.level >= d.max || isWorking(o)) return;
  syncHostBalance();
  const cost = upgradePrice(d);
  if (state.balance < cost) {
    toast('Not enough FLUX bank balance for ' + d.name + ' upgrade (₹' + Math.round(cost).toLocaleString('en-IN') + ' needed).');
    return;
  }
  if (!spend(cost, d.name + ' upgrade')) return;
  startTimedWork(d,o,'upgrade',o.level+1,cost);
  state.last = d.name + ' upgrade started: Level ' + o.level + ' → ' + o.targetLevel + ' for ' + money(cost) + '.';
  logCity(state.last);
  toast(state.last);
  selectAsset(d.id, true);
};

function demolishAsset() {
  const d = selectedDef();
  if (!d || !own(d.id)) return false;
  const o = own(d.id);
  if (isWorking(o) || o.landOnly) {
    toast('Select a completed building to demolish back into vacant land.');
    return false;
  }
  const refund = Math.round((o.buildValue || d.price * 0.5) * 0.5);
  credit(refund, 'Demolished building on ' + d.name);
  o.landOnly = true;
  o.level = 1;
  o.blueprintId = null;
  o.buildValue = 0;
  o.customName = d.name;
  if (assets.get(d.id)) clearPlotBuilding(assets.get(d.id));
  state.last = 'Demolished building on ' + d.name + ' · Refund: ' + money(refund);
  logCity(state.last);
  toast(state.last);
  refreshPanel();
  return true;
}

function sellAsset() {
  const d = selectedDef();
  if (!d || !own(d.id)) return false;
  const o = own(d.id);
  if (isWorking(o)) return false;
  const refund = salePrice(d);
  if (!credit(refund, d.name + ' sale')) {
    toast('FLUX Bank could not complete this sale. Ownership retained.');
    return false;
  }
  delete state.owned[d.id];
  if (d.kind === 'land' && o.blueprintId) clearPlotBuilding(assets.get(d.id));
  state.last = d.name + ' sold for ' + money(refund);
  logCity(state.last);
  toast(state.last);
  refreshPanel();
  return true;
}

$('sell').onclick = sellAsset;
function addFleetVehicle(kind) {
  const d = selectedDef();
  const o = d && own(d.id);
  if (!d || !o || o.landOnly || isWorking(o)) return;
  if (kind === 'bus' && d.model === 'busstand') {
    const cost = 18 * L;
    if (!spend(cost, 'bus')) return;
    o.buses = (o.buses || 0) + 1;
    addXp(20, 'bus:' + d.id, true);
    state.last = 'Added bus to ' + d.name + ' for ' + money(cost);
  } else if (kind === 'ship' && d.model === 'shipyard') {
    const cost = 90 * CR;
    if (!spend(cost, 'ship')) return;
    o.ships = (o.ships || 0) + 1;
    addXp(60, 'ship:' + d.id, true);
    state.last = 'Added ship to ' + d.name + ' for ' + money(cost);
  } else {
    toast(kind === 'bus' ? 'Select a purchased bus stand first.' : 'Select a purchased shipyard first.');
    return;
  }
  logCity(state.last);
  toast(state.last);
  refreshPanel();
}
$('special').onclick = () => addFleetVehicle('bus');
$('specialShip').onclick = () => addFleetVehicle('ship');
$('repair').onclick = () => {
  const d = selectedDef();
  const o = d && own(d.id);
  if (!d || !o || o.landOnly || isWorking(o)) return;
  const cost = repairPrice(d);
  if (cost <= 0) return;
  if (!spend(cost, d.name + ' repair')) return;
  o.condition = 100;
  addXp(8, 'repair:' + d.id, true);
  state.last = d.name + ' repaired for ' + money(cost);
  logCity(state.last);
  toast(state.last);
  refreshPanel();
};
$('power').onclick = () => {
  if (state.utilities.power) return;
  if (!spend(POWER_COST, 'city power grid')) return;
  state.utilities.power = true;
  addXp(90, 'utility:power');
  state.last = 'City power grid activated for ' + money(POWER_COST);
  logCity(state.last);
  toast(state.last);
  refreshPanel();
};
$('water').onclick = () => {
  if (state.utilities.water) return;
  if (!spend(WATER_COST, 'city water service')) return;
  state.utilities.water = true;
  addXp(80, 'utility:water');
  state.last = 'City water service activated for ' + money(WATER_COST);
  logCity(state.last);
  toast(state.last);
  refreshPanel();
};
$('nextDay').onclick = () => {
  settleConstruction();
  const previousCycle = state.cycle;
  rollCycle();
  let gross = 0;
  let upkeep = 0;
  const projectedOwned = {};
  const completed = [];
  Object.keys(state.owned).forEach(id => {
    const d = assetDefs.find(a => a.id === id);
    const o = normalizeOwned(state.owned[id]);
    projectedOwned[id] = o;
    if (!d) return;
    const wasBuilding = isWorking(o);
    if (o.daysLeft > 0) {
      o.daysLeft = Math.max(0, o.daysLeft - 1);
      if (o.daysLeft === 0) {
        const upgraded = o.constructionKind === 'upgrade';
        o.level = o.targetLevel;
        o.constructionKind = null;
        o.constructionTotal = 0;
        o.condition = Math.min(100, o.condition + 12);
        completed.push({ id: d.id, name: d.name, level: o.level, xp: upgraded ? 25 + o.level * 10 : 20 });
      }
    } else if(!o.constructionEndAt && !o.landOnly) {
      const decay = (d.model === 'airport' || d.model === 'shipyard' ? 2.3 : d.price >= 10 * CR ? 1.7 : .9) * utilityDecayMultiplier();
      o.condition = Math.max(5, o.condition - decay);
    }
    // A building starts earning after its construction completes. A failed
    // bank settlement must not advance its construction or ownership level.
    if (!wasBuilding && !o.landOnly) gross += scaledIncome(d, o) + (o.buses || 0) * 8000 + (o.ships || 0) * 1200000;
    upkeep += scaledUpkeep(d, o);
    upkeep += (o.buses || 0) * 2600;
    upkeep += (o.ships || 0) * 280000;
  });
  const net = Math.max(0, gross - Math.min(gross, upkeep));
  const tax = Math.round(net * 0.02);
  if (net > 0) {
    credit(net, 'Playable City day income');
  }
  state.owned = projectedOwned;
  state.taxes.due += tax;
  completed.forEach(c => {
    addXp(c.xp, 'complete:' + c.id + ':' + c.level);
    logCity(c.name + ' construction completed · Level ' + c.level);
  });
  state.day++;
  const dailyXp = addXp(dailyCityXp(gross, net), 'daily-city', true);
  state.last = (completed.length ? completed.map(c => c.name + ' ready at Level ' + c.level).join('; ') + '. ' : '') + `Day settled: income ${money(gross)}, upkeep ${money(upkeep)}, tax due ${money(tax)}, interest ${money(interest)}`;
  if (dailyXp.granted || dailyXp.queued) state.last += ' · Daily City XP +' + dailyXp.granted + (dailyXp.queued ? ' (' + dailyXp.queued + ' waiting)' : '');
  logCity(state.last + ' · Cycle ' + currentCycle().name);
  toast(state.last);
  refreshPanel();
};

function syncDynamicFleet() {
  const signature=Object.entries(state.owned).map(([id,o])=>id+':'+o.buses+':'+o.ships).join('|');
  if(dynamic.signature===signature)return;
  dynamic.signature=signature;
  dynamic.buses.forEach(b => scene.remove(b.g || b));
  dynamic.ships.forEach(s => scene.remove(s.g || s));
  dynamic.buses = [];
  dynamic.ships = [];
  Object.keys(state.owned).forEach(id => {
    const d = assetDefs.find(a => a.id === id);
    const o = state.owned[id];
    if (!d || !o) return;
    for (let i = 0; i < Math.min(8, o.buses || 0); i++) {
      const g = modelBus(new T.Group(), 0, 0, 0, 0);
      g.traverse(m => { if (m.isMesh) m.castShadow = false; });
      scene.add(g);
      dynamic.buses.push({ g, offset: i * .17, route: i % 3 });
    }
    for (let i = 0; i < Math.min(5, o.ships || 0); i++) {
      const g = new T.Group();
      modelShip(g, 0, 0, 0);
      g.traverse(m => { if (m.isMesh) m.castShadow = false; });
      scene.add(g);
      dynamic.ships.push({ g, offset: i * .21 });
    }
  });
}

function routePoint(path, t) {
  t = ((t % 1) + 1) % 1;
  const scaled = t * path.length;
  const i = Math.floor(scaled) % path.length;
  const j = (i + 1) % path.length;
  const f = scaled - i;
  const a = path[i], b = path[j];
  return { x: a[0] + (b[0] - a[0]) * f, z: a[1] + (b[1] - a[1]) * f, yaw: Math.atan2(b[0] - a[0], b[1] - a[1]) };
}
const shipRoute = [[-5000, 3180], [-4300, 3340], [-3300, 3180], [-3080, 2500], [-3820, 2180], [-4700, 2460]];

function animateFleet(time) {
  dynamic.buses.forEach((b, i) => {
    const loop = graphics.roads[graphics.roads.length - 1].curve;
    const p = graphics.sampleRoad(loop, time * .0035 + b.offset, 31);
    b.g.position.set(p.x, 24, p.z);
    b.g.rotation.y = p.yaw;
  });
  dynamic.ships.forEach((s) => {
    const p = routePoint(shipRoute, time * .012 + s.offset);
    s.g.position.set(p.x, 22, p.z);
    s.g.rotation.y = p.yaw;
  });
}

const cameraBounds = { minX: -10500, maxX: 10800, minZ: -9500, maxZ: 10500, minZoom: 330, maxZoom: 6500 };
const activePointers = new Map();
let pinchStart = null;
function clampCameraTargets() {
  target.x = Math.max(cameraBounds.minX, Math.min(cameraBounds.maxX, target.x));
  target.z = Math.max(cameraBounds.minZ, Math.min(cameraBounds.maxZ, target.z));
  targetZoom = Math.max(cameraBounds.minZoom, Math.min(cameraBounds.maxZoom, targetZoom));
}
const dragPlane = new T.Plane(new T.Vector3(0, 1, 0), -12);
const dragRay = new T.Raycaster();
function cameraGroundPoint(x, y, cam) {
  dragRay.setFromCamera(new T.Vector2(x / innerWidth * 2 - 1, 1 - y / innerHeight * 2), cam);
  return dragRay.ray.intersectPlane(dragPlane, new T.Vector3());
}
function pointerDistance() {
  const pts = [...activePointers.values()];
  if (pts.length < 2) return 1;
  return Math.max(1, Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y));
}
function endPointer(e) {
  if (e.type !== 'pointercancel' && dragging && dragStart && activePointers.size === 1 && dragStart.moved < 8) {
    const rect = renderer.domElement.getBoundingClientRect();
    pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, camera);
    const hits = raycaster.intersectObjects(pickables, false);
    const resolveHit = hit => hit?.object?.userData?.assetId ||
      (hit?.instanceId !== undefined ? hit.object.userData.assetIds?.[hit.instanceId] : null);
    const assetId = hits.map(resolveHit).find(Boolean);
    if (assetId) {
      selectAsset(assetId, false);
      const touchedDef = assetDefs.find(a => a.id === assetId);
      if (touchedDef) toast((own(assetId)?.customName || touchedDef.name) + ' selected · Tap MANAGE for details');
    }
  }
  activePointers.delete(e.pointerId);
  dragging = false;
  dragStart = null;
  pinchStart = null;
}
renderer.domElement.addEventListener('pointerdown', (e) => {
  activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
  renderer.domElement.setPointerCapture(e.pointerId);
  if (activePointers.size === 2) {
    pinchStart = { distance: pointerDistance(), zoom: targetZoom };
    dragging = false;
    dragStart = null;
    return;
  }
  dragging = true;
  const dragCamera = camera.clone();
  dragStart = { x: e.clientX, y: e.clientY, tx: target.x, tz: target.z, moved: 0,
    camera: dragCamera, ground: cameraGroundPoint(e.clientX, e.clientY, dragCamera) };
});
renderer.domElement.addEventListener('pointermove', (e) => {
  if (activePointers.has(e.pointerId)) activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (pinchStart && activePointers.size >= 2) {
    targetZoom = pinchStart.zoom * (pinchStart.distance / pointerDistance());
    clampCameraTargets();
    return;
  }
  if (!dragging || !dragStart) return;
  const dx = e.clientX - dragStart.x;
  const dy = e.clientY - dragStart.y;
  dragStart.moved = Math.max(dragStart.moved, Math.hypot(dx, dy));
  const ground = cameraGroundPoint(e.clientX, e.clientY, dragStart.camera);
  if (ground && dragStart.ground) {
    target.x = dragStart.tx + dragStart.ground.x - ground.x;
    target.z = dragStart.tz + dragStart.ground.z - ground.z;
  }
  clampCameraTargets();
});
renderer.domElement.addEventListener('pointerup', endPointer);
renderer.domElement.addEventListener('pointercancel', endPointer);
renderer.domElement.addEventListener('wheel', (e) => {
  e.preventDefault();
  targetZoom = targetZoom * Math.exp(e.deltaY * .001);
  clampCameraTargets();
}, { passive: false });

function focusPreset(which) {
  assetCamera = false; targetElevation = 400;
  window.previewStable = false;
  const map = {
    city: { x: 0, z: 620, zoom: 2850 },
    residential: { id: 'residential', zoom: 1050 },
    commercial: { x: 350, z: -1570, zoom: innerWidth < 700 ? 780 : 900 },
    industrial: { id: 'industrial', zoom: 1150 },
    port: { id: 'port', zoom: 1300 },
    airport: { id: 'airport', zoom: 1500 },
    corporate: { id: 'corporate', zoom: 1120 },
    transport: { id: 'entertainment', zoom: 1300 }
  };
  const next = map[which] || map.city;
  if (next.id) {
    const c = districtCenter(next.id);
    target = { x: c[0], z: c[1] };
  } else {
    target = { x: next.x, z: next.z };
  }
  targetZoom = next.zoom;
  clampCameraTargets();
}
document.querySelectorAll('[data-focus]').forEach(b => b.onclick = () => focusPreset(b.dataset.focus));
$('zoomIn').onclick = () => { targetZoom *= .72; clampCameraTargets(); };
$('zoomOut').onclick = () => { targetZoom *= 1.35; clampCameraTargets(); };
$('reset').onclick = () => focusPreset('commercial');

let lastRenderTime = 0;
let lastProgressTick = 0;
function render(timeMs) {
  requestAnimationFrame(render);
  if (window.fluxCapturePaused || (lastRenderTime && timeMs - lastRenderTime < 32)) return;
  const delta = lastRenderTime ? Math.min(.1, Math.max(0, (timeMs - lastRenderTime) / 1000)) : 1 / 60;
  lastRenderTime = timeMs;
  const blend = 1 - Math.exp(-9 * delta);
  focus.x += (target.x - focus.x) * blend;
  focus.z += (target.z - focus.z) * blend;
  zoom += (targetZoom - zoom) * blend;
  focusElevation += (targetElevation - focusElevation) * blend;
  updateCamera();
  updateLabels();
  animateFleet(timeMs / 1000);
  graphics.update(timeMs / 1000);
  if (timeMs - lastProgressTick > 1000) { if(Object.values(state.owned).some(isWorking))refreshPanel();else refreshProgressionHUD(); lastProgressTick = timeMs; }
  try {
    renderer.render(scene, camera);
  } catch (err) {
    console.warn("Render frame error:", err);
  }
  const loadingEl = $('loading');
  if (loadingEl) { loadingEl.hidden = true; loadingEl.style.display = 'none'; }
  if ($('readout')) {
    $('readout').innerHTML =
      `${worldInfo.playableSector}<br>` +
      `District claim: ${worldInfo.empireKmPerDistrict.toLocaleString('en-IN')}km each · City L${cityLevel()} · XP ${Math.round(state.xp || 0)} · ${currentCycle().name}<br>` +
      `Owned ${ownedCount()}/${assetDefs.length} · Buses ${totalBuses()} · Ships ${totalShips()} · Missions ${Object.keys(state.missions).length}/${missionDefs.length}`;
  }
  window.previewState = { ready: true, selected, owned: ownedCount(), balance: state.balance, zoom, assetCount: assetDefs.length, cityLevel: cityLevel(), xp: state.xp,
    graphics: { ...graphics.stats, triangles: renderer.info.render.triangles, drawCalls: renderer.info.render.calls } };
  window.previewStable = Math.abs(target.x - focus.x) < 1 && Math.abs(target.z - focus.z) < 1 && Math.abs(targetZoom - zoom) < 1 && Math.abs(targetElevation - focusElevation) < 1;
}

refreshPanel();
const initialLoading = $('loading');
if (initialLoading) { initialLoading.hidden = true; initialLoading.style.display = 'none'; }
window.previewReady = true;
window.previewStable = false;
window.fluxPreviewSyncBank = (balance) => {
  const value = Number(balance);
  if (!Number.isFinite(value)) return;
  state.account = true;
  state.balance = value;
  if ($('money')) $('money').textContent = money(state.balance);
  if ($('topMoney')) $('topMoney').textContent = money(state.balance);
  if ($('bankStatus')) $('bankStatus').textContent = 'Main FLUX bank linked · Day ' + state.day + ' · ' + state.last;
};
window.fluxPreview = { selectAsset, focusPreset, state, assetDefs, cityLevel, missionDefs,
  constructionProgress, constructionDays, upgradePrice, requirementText, scaledIncome, normalizeOwned,
  startBuild, fastFinish, remodel, payTax, settleConstruction, now, isWorking, BLUEPRINTS, fastFinishPrice, cityUI:()=>cityUI,
  progression: { MAX_CITY_LEVEL, DAILY_XP_CAP, REAL_DAY_MS, awardCityXp, cityProgressionStatus, minimumDaysForLevel },
  renderer, scene, camera, graphics, architecture, assets, pickables, groundToScreen, refreshPanel,
  reservedLots, footprints, roadX, roadZ, renderStill: () => { updateCamera(); renderer.render(scene, camera); } };
const qualityControl = $('graphicsQuality');
if (qualityControl) {
  qualityControl.value = qualityName;
  qualityControl.onchange = () => {
    try { localStorage.setItem('flux_city_graphics', qualityControl.value); } catch {}
    save(); location.reload();
  };
}
requestAnimationFrame(render);

function focusDistrict(id){
  const d=districts.find(a=>a.id===id);if(!d)return;
  assetCamera=false;targetElevation=350;target={x:d.center[0],z:d.center[1]};targetZoom=d.growth?1700:1100;
  window.previewStable=false;clampCameraTargets();
}
function navigateTab(route){
  if(route==='playable_city'){focusPreset('commercial');cityUI.close();return;}
  if(bankBridge()?.navigateTo && bankBridge().navigateTo(route))return;
  if(route==='banking')cityUI.show('bank');
  else if(route==='tax_finance'||route==='dashboard')cityUI.show('reports');
  else if(route==='real_estate')cityUI.show('catalog',{category:'Homes'});
  else if(route==='manufacturing')cityUI.show('catalog',{category:'Industry'});
  else if(route==='import_export')cityUI.show('catalog',{category:'Transport'});
  else if(route==='stock_market'||route==='business_center'||route==='local_business')cityUI.show('catalog');
  else cityUI.show('progression');
}
window.cityUI = cityUI = createCityInterface({state,defs:assetDefs,districts,assets,missions:missionDefs,BLUEPRINTS,BUILD_STAGES,
  money,own,ownedCount,selectedDef,selectAsset,requirementText,constructionProgress,isWorking,remainingLabel,
  scaledIncome,scaledUpkeep,upgradePrice,repairPrice,salePrice,demolishAsset,sellAsset,incomeReport,category,currentCycle,bankBridge,
  startBuild,fastFinish,remodel,payTax,now,focusDistrict,navigateTab,minimumDaysForLevel,
  progressionStatus:()=>cityProgressionStatus(state)});
if ($('openProgression')) $('openProgression').onclick=()=>cityUI.show('progression');
if ($('progressionDetails')) $('progressionDetails').onclick=()=>cityUI.show('progression');
if ($('xpSummary')) $('xpSummary').onclick=()=>cityUI.show('progression');
if ($('openMore')) $('openMore').onclick=()=>cityUI.show('more');
if ($('closePanel')) {
  $('closePanel').onclick = () => {
    selected = null;
    if ($('panel')) $('panel').hidden = true;
  };
}
if ($('quickBuy')) $('quickBuy').onclick=()=>{$('buy')?.click();};
if ($('quickUpgrade')) $('quickUpgrade').onclick=()=>{$('upgrade')?.click();};
if ($('quickSell')) $('quickSell').onclick=()=>{$('sell')?.click();};
if ($('viewCatalog')) $('viewCatalog').onclick=()=>cityUI.show('catalog');
if ($('openCityBank')) $('openCityBank').onclick=()=>cityUI.show('bank');
if ($('collectDay')) $('collectDay').onclick=()=>{$('nextDay')?.click();cityUI.show('reports');};
document.querySelectorAll('[data-tool]').forEach(b=>b.onclick=()=>cityUI.show(b.dataset.tool==='population'?'catalog':b.dataset.tool));
document.querySelectorAll('[data-route]').forEach(b=>b.onclick=()=>navigateTab(b.dataset.route));
if ($('exitCity')) $('exitCity').onclick=()=>{save();cityUI.close();navigateTab('dashboard');};
document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshPanel();});
