import { BLUEPRINTS, BUILD_CHOICES, durationMs, fastFinishPrice, timeLabel } from './city-catalog.js';

// Full context screens with pinned title/Done controls and paginated lists.
// Long catalogs never get squeezed into the map's property card.
export function createCityInterface(c){
  const $=id=>document.getElementById(id),esc=v=>String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  let active=null,previousFocus=null;
  const button=(label,action,extra='',disabled=false,primary=false)=>'<button '+(disabled?'disabled ':'')+'class="'+(primary?'gold':'')+'" data-action="'+action+'" '+extra+'>'+esc(label)+'</button>';
  const metric=(name,value)=>'<div class="metric"><span>'+esc(name)+'</span><b>'+esc(value)+'</b></div>';
  const row=(title,text)=>'<div class="dialogRow"><b>'+esc(title)+'</b><span>'+esc(text)+'</span></div>';
  function tabs(items){return '<div class="screenTabs" role="tablist">'+items.map(([id,label])=>'<button role="tab" aria-selected="'+(active.tab===id)+'" data-action="tab" data-value="'+id+'">'+label+'</button>').join('')+'</div>';}
  function pageList(items,draw,count=innerWidth<700?4:6){
    // Fit each page into the available reading box, including its controls.
    const available=$('dialogContent').clientHeight;
    count=Math.max(1,Math.min(count,Math.floor((available-180)/80)));
    const pages=Math.max(1,Math.ceil(items.length/count));active.page=Math.min(active.page,pages-1);
    return '<div class="screenList">'+items.slice(active.page*count,(active.page+1)*count).map(draw).join('')+'</div><div class="pagination">'+button('Previous','page','data-value="-1"',active.page===0)+'<span>Page '+(active.page+1)+' / '+pages+' · '+items.length+' items</span>'+button('Next','page','data-value="1"',active.page===pages-1)+'</div>';
  }
  function propertyRow(d){
    const o=c.own(d.id),req=!o&&c.requirementText(d),name=o?.customName||d.name;
    const status=o?(o.landOnly?'Owned vacant land':c.isWorking(o)?'Work in progress':'Owned · Level '+o.level+'/6'):(req?'Requirement: '+req:'Fixed price '+c.money(d.price));
    return '<button class="catalogRow" data-action="asset" data-id="'+d.id+'">'+(o?'<span class="rowIcon">✓</span>':'<svg class="icon rowIcon"><use href="#i-lock"/></svg>')+'<span><b>'+esc(name)+'</b><small>'+esc(status)+'</small></span><span class="rowPrice">'+esc(c.money(d.price))+'<br>View →</span></button>';
  }
  function map(){
    if(active.zone){
      const d=c.districts.find(x=>x.id===active.zone),list=c.defs.filter(x=>x.district===d.id);
      return button('← All districts','zones')+row(d.name,'Buy existing buildings or visit Development to buy vacant land. Select a property to read its complete details.')+
        '<div class="metrics">'+metric('Properties',list.length)+metric('Owned',list.filter(a=>c.own(a.id)).length)+metric('Survey',Math.round(d.size[0])+' × '+Math.round(d.size[1])+' m')+'</div>'+button('View this district in 3D','focus','data-id="'+d.id+'"',false,true)+pageList(list,propertyRow);
    }
    const vacant=c.defs.filter(d=>d.kind==='land').length;
    return row('Choose a location',c.districts.length+' districts · '+(c.defs.length-vacant)+' buildings + '+vacant+' vacant plots. Buy and operate ready buildings, or buy land before building your own.')+
      pageList(c.districts,d=>'<button class="catalogRow" data-action="zone" data-id="'+d.id+'"><svg class="icon rowIcon"><use href="#i-map"/></svg><span><b>'+esc(d.name)+'</b><small>'+c.defs.filter(a=>a.district===d.id).length+' selectable properties · tap for details</small></span><span>→</span></button>',innerWidth<700?5:6);
  }
  function catalog(){
    const categories=['All','Owned','Homes','Retail','Leisure','Offices','Industry','Transport','Civic','Land'];
    const category=active.category||'All',query=(active.query||'').toLowerCase();
    const list=c.defs.filter(d=>(category==='All'||category==='Owned'&&c.own(d.id)||c.category(d)===category)&&(!query||(c.own(d.id)?.customName||d.name).toLowerCase().includes(query)));
    return '<div class="catalogFilters"><input id="catalogSearch" placeholder="Find a property…" aria-label="Find a property" value="'+esc(active.query||'')+'"><select id="catalogCategory" aria-label="Property category">'+categories.map(x=>'<option '+(category===x?'selected':'')+'>'+x+'</option>').join('')+'</select></div>'+row(c.ownedCount()+' properties owned','Padlock means unowned. Buying removes the ownership lock. Prices are fixed and listed before payment.')+
      (list.length?pageList(list,propertyRow):row('No matching properties','Choose All or try a different name.'));
  }
  function manage(){
    let d=c.selectedDef();
    if(!d){
      d = c.defs.find(x => c.own(x.id)) || c.defs[0];
      if(d) c.selectAsset(d.id, false);
    }
    if(!d) return row('Choose a property','Tap a building on the 3D map, or pick an entry from the property catalog.');
    const o=c.own(d.id),req=!o&&c.requirementText(d),working=c.isWorking(o),name=o?.customName||d.name;
    const progress=c.constructionProgress(o),a=c.assets.get(d.id)?.root.userData.architecture;
    const valuation = (d.price || 0) * (o?.level || 1);
    const saleVal = c.salePrice(d);
    const income = c.scaledIncome(d);
    const upkeep = c.scaledUpkeep(d);
    const netProfit = income - upkeep;
    const taxDue = c.state.taxes.due;

    let html=tabs([['overview','Overview & Value'],['work','Build / Upgrade'],['remodel','Remodel'],['fleet','Fleet']]);
    html+=row((o?'✓ Owned · ':'Locked · Unowned · ')+name,o?.landOnly?'Vacant land: choose a blueprint and pay the separate construction cost.':req||working?req||progress.name+' · '+c.remainingLabel(o):'Level '+(o?.level||1)+' / 6 · '+(a?a.floors+' floors · ':'')+(o?'Condition '+Math.round(o.condition)+'%':'Ready property for sale'));

    if(active.tab==='overview'){
      html+='<div class="metrics">'
        +metric('Market Valuation', c.money(valuation))
        +metric(d.kind==='land'?'Land Purchase':'Buy Price', c.money(d.price))
        +metric('Resale Value', o ? c.money(saleVal) : 'N/A')
        +metric('Daily Income', o?.landOnly?'₹0':c.money(income))
        +metric('Daily Upkeep', o?.landOnly?'₹0':c.money(upkeep))
        +metric('Net Profit / Day', o?.landOnly?'₹0':c.money(netProfit))
        +metric('City Tax Liability', c.money(Math.round(income * 0.05)))
        +metric('Condition', o ? Math.round(o.condition) + '%' : '100%')
        +metric('Level / Structural', 'Level ' + (o?.level || 1) + ' / 6')
        +'</div>';

      const upgCost = c.upgradePrice(d);
      const repCost = c.repairPrice(d);
      const canBuy = !o && c.state.balance >= (d.price || 0);
      const canUpgrade = o && !o.landOnly && !working && o.level < 6 && c.state.balance >= upgCost;
      const canRepair = o && !o.landOnly && !working && repCost > 0 && c.state.balance >= repCost;
      const canRemodel = o && !o.landOnly && !working && c.state.balance >= 2500;

      html+='<div class="screenActions">'
        +button(o?.landOnly?'Land Owned ✓':o?'✓ Already Owned':d.kind==='land'?'Buy Land '+c.money(d.price):'Buy Property '+c.money(d.price),'buy','',!canBuy,true)
        +button('Build on Land','choose-build','',!o?.landOnly)
        +button(o?'Upgrade Level '+( (o?.level||1)+1 )+' ('+c.money(upgCost)+')':'Upgrade','upgrade','',!canUpgrade)
        +button('Repair ('+c.money(repCost)+')','repair','',!canRepair)
        +button('Pay City Tax ('+c.money(taxDue)+')','pay-tax','',taxDue<=0 || c.state.balance < taxDue)
        +button('Remodel & Rename','tab','data-value="remodel"',!canRemodel)
        +button('Demolish Building','demolish-confirm','',!o||o.landOnly||working)
        +button('Sell Property ('+c.money(saleVal)+')','sell-confirm','',!o||working)
        +'</div>';

      html+=row('Detailed Property Overview','Market valuation is based on structural level and location. Daily income minus upkeep gives net profit. Pay City Tax resolves pending tax due across your empire.');
    } else if(active.tab==='work'){
      if(o?.landOnly)html+=button('Choose what to build','choose-build','',false,true)+row('Land is already paid for','House, apartment, showroom, pub, factory, mall, airport or shipyard: see the building cost and countdown before starting.');
      else if(working)html+='<div class="workStages">'+c.BUILD_STAGES.map((n,i)=>'<span class="'+(i<=progress.stage?'done':'')+'">'+esc(n)+'</span>').join('')+'</div><div class="progressBar"><div style="width:'+Math.round(progress.progress*100)+'%"></div></div>'+row(progress.name,c.remainingLabel(o))+'<div class="screenActions">'+button('Finish now '+c.money(fastFinishPrice(o,c.now())),'fast-finish','',!o.constructionEndAt,true)+button('View site in 3D','view','data-id="'+d.id+'"')+'</div>'+row('Completion','The timer continues after you close the app. Instant finish uses your shared bank balance; it does not bypass the daily XP cap. Legacy saves still finish their pending game-day work with Next Day.');
      else html+=row('Six structural levels','Base level 1 → level 2 → level 3 → level 4 → level 5 → level 6. Upgrades add floors and roof tiers; only one upgrade can run on a property at a time.')+'<div class="levelStages">'+Array.from({length:6},(_,i)=>'<span class="'+(o&&i<o.level?'done':'')+'">L'+(i+1)+'</span>').join('')+'</div>'+row('Next upgrade',o?.level>=6?'All six structural levels completed':c.money(c.upgradePrice(d))+' · '+timeLabel(durationMs(d,(o?.level||1)+1)))+button(o?.level>=6?'Level 6 complete':'Start upgrade','upgrade','',!o||o.level>=6,true);
    } else if(active.tab==='remodel'){
      html+=row('Repeatable changes','Rename and repaint this building as often as you want. Each applied remodel costs ₹2,500; floor levels remain separate. Cosmetic changes grant no XP.');
      html+='<label class="fieldLabel" for="remodelName">Property name</label><input id="remodelName" maxlength="48" value="'+esc(name)+'"><label class="fieldLabel" for="remodelStyle">Facade finish</label><select id="remodelStyle">'+[['original','Original stone & bronze'],['sky','Cool blue glass'],['jade','Jade facade'],['warm','Warm sandstone']].map(([id,n])=>'<option value="'+id+'" '+(o?.style===id?'selected':'')+'>'+n+'</option>').join('')+'</select>'+row('Remodels applied',o?.remodelCount||0)+button('Apply change ₹2,500','remodel','',!o||o.landOnly||working,true);
    } else {
      html+=row('Operating fleet','Bus terminals can add buses for ₹18 L each. Shipyards can add ships for ₹90 Cr each. Fleet income and upkeep join the same daily city report.');
      html+='<div class="metrics">'+metric('Buses',o?.buses||0)+metric('Ships',o?.ships||0)+metric('Status',o&&!working&&!o.landOnly?'Ready':'Unavailable')+'</div><div class="screenActions">'+button('Add Bus ₹18 L','special','',!o||working||d.model!=='busstand',true)+button('Add Ship ₹90 Cr','specialShip','',!o||working||d.model!=='shipyard',true)+'</div>';
    }
    return html;
  }
  function build(){
    const land=c.defs.filter(d=>d.kind==='land'&&c.own(d.id)?.landOnly);
    if(!active.plot)return row('1. Buy empty land → 2. Choose a building → 3. Start construction','Land and buildings have separate fixed prices. Your owned vacant plots appear here.')+(land.length?pageList(land,d=>'<button class="catalogRow" data-action="plot" data-id="'+d.id+'"><span>✓</span><span><b>'+esc(d.name)+'</b><small>Owned vacant land · ready to develop</small></span><span>Choose →</span></button>'):row('No vacant land owned yet','Buy a plot first. Your ready properties remain available in the catalog.'))+button('Buy vacant land','land-catalog','',false,true);
    const plot=c.defs.find(d=>d.id===active.plot);if(!c.own(plot.id)?.landOnly){active.plot=null;return build();}
    if(active.blueprint){
      const b=BLUEPRINTS.find(x=>x.id===active.blueprint),req=c.requirementText({...b,id:plot.id});
      return button('← Building choices','blueprints')+row('Build '+b.name,'On '+plot.name+' · land is already owned')+'<div class="metrics">'+metric('Building cost',c.money(b.price))+metric('Real build time',timeLabel(durationMs(b)))+metric('Base income / day',c.money(b.income))+'</div>'+row('Six levels + unlimited remodeling','Preparation, structure and finishing are visible in 3D. The timer is saved. A separately priced instant-finish button appears once work starts.')+(req?row('Requirement',req):'')+button('Start build '+c.money(b.price),'start-build','data-plot="'+plot.id+'" data-id="'+b.id+'"',!!req,true);
    }
    return row('Choose a building for '+plot.name,'30 building choices. Prices cover construction only; your land is already paid for.')+pageList(BUILD_CHOICES,b=>'<button class="catalogRow" data-action="blueprint" data-id="'+b.id+'"><svg class="icon rowIcon"><use href="#i-city"/></svg><span><b>'+esc(b.name)+'</b><small>'+esc(b.category)+' · '+esc(timeLabel(durationMs(b)))+'</small></span><span class="rowPrice">'+esc(c.money(b.price))+'<br>Details →</span></button>');
  }
  function reports(){
    const r = c.incomeReport();
    const tax = c.state.taxes;
    const ownedAssets = c.defs.filter(d => c.own(d.id));
    const totalValuation = ownedAssets.reduce((sum, d) => {
      const o = c.own(d.id);
      return sum + (d.price || 0) * (o?.level || 1);
    }, 0);
    const netDailyIncome = r.gross - r.upkeep;
    const taxRatePct = Math.round(c.taxRateFor(r.gross) * 100);

    let html = tabs([['overview','Overview & Value'],['assets','Owned Properties'],['history','Income History']]);

    if (active.tab === 'overview') {
      html += '<div class="metrics">'
        + metric('Properties Bought', ownedAssets.length)
        + metric('Total Net Worth', c.money(totalValuation))
        + metric('Daily Gross Income', c.money(r.gross))
        + metric('Daily Upkeep', c.money(r.upkeep))
        + metric('Net Daily Income', c.money(netDailyIncome))
        + metric('City Tax Rate', taxRatePct + '%')
        + metric('Tax Due (Unpaid)', c.money(tax.due))
        + metric('Tax Paid Total', c.money(tax.paid))
        + metric('Shared FLUX Bank', c.money(c.state.balance))
        + '</div>';

      html += '<div class="screenActions">'
        + button('Pay City Tax ' + c.money(tax.due), 'pay-tax', '', tax.due <= 0, true)
        + button('Settle Next Day', 'nextDay')
        + '</div>';

      html += row('City Tax & Empire Revenue Statement', 'Tax is assessed on daily gross income. Next Day credits net daily income to your shared FLUX bank account. Pay Tax settles outstanding tax due across all properties.');
    } else if (active.tab === 'history') {
      html += pageList(c.state.history, x => row('City Transaction', x));
    } else {
      if (!ownedAssets.length) {
        html += row('No Properties Owned Yet', 'Buy buildings or vacant land from the Catalog to start earning daily city income.');
      } else {
        html += pageList(ownedAssets, d => {
          const o = c.own(d.id);
          const val = (d.price || 0) * (o?.level || 1);
          const inc = c.scaledIncome(d);
          const upk = c.scaledUpkeep(d);
          return row(
            (o.customName || d.name) + ' · Level ' + (o.level || 1) + '/6',
            'Valuation: ' + c.money(val) + ' · Income: ' + c.money(inc) + '/day · Upkeep: ' + c.money(upk) + '/day'
          ) + '<div class="screenActions">' + button('Sell Property (' + c.money(c.salePrice(d)) + ')', 'asset', 'data-id="' + d.id + '"', false, true) + '</div>';
        });
      }
    }
    return html;
  }
  function bank(){
    return row('One shared FLUX bank',c.bankBridge()?'Linked to your main game account. All property, build, repair, tax, loan and EMI payments use this balance.':'Standalone browser preview account. In the Android app this uses your main FLUX bank.')+'<div class="metrics">'+metric('Available',c.money(c.state.balance))+metric('Tax due',c.money(c.state.taxes.due))+metric('Active Loans',c.state.loans.length)+'</div><div class="screenActions">'+button('City Loan ₹50 L (12% Int)','loanSmall','',c.state.loans.includes('City Loan ₹50 L (12% Int, EMI Active)'))+button('City Loan ₹1 Cr Max (12% Int)','loanMega','',c.state.loans.includes('City Loan ₹1 Cr Max (12% Int, EMI Active)'))+button('Settle Next Day','nextDay','',false,true)+button('Pay Tax '+c.money(c.state.taxes.due),'pay-tax','',c.state.taxes.due<=0)+button(c.state.utilities.power?'Power active':'Power grid ₹25 Cr','power','',c.state.utilities.power)+button(c.state.utilities.water?'Water active':'Water service ₹15 Cr','water','',c.state.utilities.water)+'</div>'+row('Loan & EMI Terms','City loans are capped at ₹50 Lakhs or ₹1 Crore max. All sanctioned loans carry a 12% annual interest rate. Daily EMIs (principal + 12% interest) are automatically settled on every game day.');
  }
  function progression(){
    const p=c.progressionStatus();
    return tabs([['overview','Your XP'],['milestones','Milestones'],['rules','How XP works']])+(active.tab==='overview'?'<div class="metrics">'+metric('City level',p.level+' / 300')+metric('Total XP',p.totalXp.toLocaleString('en-IN'))+metric('Today',p.usedXp+' / 350 XP')+'</div>'+row(p.rank,p.level===300?'Maximum City Level':p.levelXp+' / '+p.nextCost+' XP in this level · '+p.toNext+' XP to Level '+(p.level+1))+'<div class="progressBar"><div style="width:'+Math.round(p.fraction*100)+'%"></div></div>'+row('Next XP window',timeLabel(p.resetsInMs)+' · waiting XP '+p.pendingXp.toLocaleString('en-IN'))+row('Long-term goal','Level 300 needs 373,525 XP. At the maximum daily XP rate it takes at least 1,067 elapsed days with normal device time. Actual play can take longer.'):active.tab==='milestones'?pageList([25,50,100,150,200,250,300],l=>row('Level '+l,'Calculated minimum: '+c.minimumDaysForLevel(l)+' elapsed days from Level 1')):row('350 XP per real 24-hour window','Every XP source shares this limit. Excess earned XP waits for another window. Repeated Next Day presses do not repeat the daily XP reward.')+row('Stage rewards','Buy/build rewards and completed upgrade milestones are claimed once per property and stage. Repairs and fleet rewards use the same daily allowance. Repainting and renaming grant no XP.')+row('Keep playing','Income, taxes and real construction timers continue working after your XP allowance is reached. Property levels remain 1–6. City levels remain 1–300.'));
  }
  function tasks(){return row('City milestones',Object.keys(c.state.missions).length+' / '+c.missions.length+' complete. Rewards are automatic and paid once.')+pageList(c.missions,m=>row((c.state.missions[m.id]?'✓ Complete · ':'○ Goal · ')+m.title,'Reward '+c.money(m.reward)+' · '+m.xp+' XP · '+(m.check()?'Goal met':'In progress')));}
  function render(){
    if(!active)return;let html='';
    const names={map:'City locations',catalog:'Property catalog',manage:'Manage property',build:'Build your own',reports:'City reports & tax',bank:'Bank & city services',progression:'City Level 300',tasks:'Tasks',more:'All FLUX tabs',sell:'Confirm sale',demolish:'Confirm demolition'};
    $('dialogTitle').textContent=names[active.kind]||'FLUX City';
    if(active.kind==='map')html=map();else if(active.kind==='catalog')html=catalog();else if(active.kind==='manage')html=manage();else if(active.kind==='build')html=build();else if(active.kind==='reports')html=reports();else if(active.kind==='bank')html=bank();else if(active.kind==='progression')html=progression();else if(active.kind==='tasks')html=tasks();
    else if(active.kind==='more')html=pageList([['profile','Profile'],['real_estate','Real Estate'],['import_export','International Trade'],['local_business','Local Business'],['manufacturing','Manufacturing'],['stock_market','Markets'],['dashboard','Empire'],['banking','Banking'],['tax_finance','Tax & Finance'],['business_center','Business']],([id,n])=>button(n,'route','data-id="'+id+'"'));
    else if(active.kind==='sell'){const d=c.selectedDef();html=row('Sell '+(c.own(d.id)?.customName||d.name),'Listed refund: '+c.money(c.salePrice(d))+'. This returns the property to unowned and removes its fleet and customization.')+'<div class="screenActions">'+button('Keep property','cancel-sale')+button('Sell for '+c.money(c.salePrice(d)),'sell','',false,true)+'</div>';}
    else if(active.kind==='demolish'){const d=c.selectedDef(),o=c.own(d.id);const refund=Math.round((o?.buildValue||d.price*.5)*.5);html=row('Demolish building on '+(o?.customName||d.name),'This will clear the constructed building back into vacant land plot. Demolition refund: '+c.money(refund)+'. You can then choose any new building blueprint to construct on this land.')+'<div class="screenActions">'+button('Keep building','cancel-demolish')+button('Demolish & Clear Plot '+c.money(refund),'demolish','',false,true)+'</div>';}
    $('dialogContent').innerHTML=html;
    $('dialogContent').scrollTop=0;
  }
  function show(kind,options={}){previousFocus=document.activeElement;active={kind,tab:'overview',page:0,...options};$('cityDialog').hidden=false;render();$('dialogClose').focus();}
  function close(){active=null;$('cityDialog').hidden=true;previousFocus?.focus?.();}
  $('dialogClose').onclick=close;$('dialogDone').onclick=close;
  $('dialogContent').addEventListener('click',e=>{
    const b=e.target.closest('[data-action]');if(!b||b.disabled)return;
    const action=b.dataset.action,id=b.dataset.id;
    if(action==='page'){active.page+=Number(b.dataset.value);render();return;}
    if(action==='tab'){active.tab=b.dataset.value;active.page=0;render();return;}
    if(action==='zone'){active.zone=id;active.page=0;render();return;}
    if(action==='zones'){delete active.zone;active.page=0;render();return;}
    if(action==='asset'){c.selectAsset(id,true);show('manage');return;}
    if(action==='view'){c.selectAsset(id,true);close();return;}
    if(action==='focus'){c.focusDistrict(id);close();return;}
    if(action==='land-catalog'){show('catalog',{category:'Land'});return;}
    if(action==='choose-build'){show('build',{plot:c.selectedDef().id});return;}
    if(action==='plot'){active.plot=id;active.page=0;render();return;}
    if(action==='blueprint'){active.blueprint=id;render();return;}
    if(action==='blueprints'){delete active.blueprint;render();return;}
    if(action==='start-build'){if(c.startBuild(b.dataset.plot,id)){c.selectAsset(b.dataset.plot,true);show('manage',{tab:'work'});}return;}
    if(action==='fast-finish'){c.fastFinish();render();return;}
    if(action==='remodel'){c.remodel($('remodelName').value,$('remodelStyle').value);render();return;}
    if(action==='pay-tax'){c.payTax();render();return;}
    if(action==='demolish-confirm'){show('demolish');return;}
    if(action==='cancel-demolish'){show('manage');return;}
    if(action==='demolish'){if(c.demolishAsset()){show('manage');}return;}
    if(action==='sell-confirm'){show('sell');return;}
    if(action==='cancel-sale'){show('manage');return;}
    if(action==='sell'){if(c.sellAsset()){show('manage');}return;}
    if(action==='route'){c.navigateTab(id);return;}
    const control=$(action);if(control){control.click();if(action==='sell'||action==='demolish')show('manage');else render();}
  });
  $('dialogContent').addEventListener('change',e=>{if(e.target.id==='catalogSearch'){active.query=e.target.value;active.page=0;render();}else if(e.target.id==='catalogCategory'){active.category=e.target.value;active.page=0;render();}});
  addEventListener('keydown',e=>{if(e.key==='Escape')close();if(e.key==='Tab'&&active){const controls=[...$('cityDialog').querySelectorAll('button:not(:disabled),input,select')].filter(x=>x.getClientRects().length);if(e.shiftKey&&document.activeElement===controls[0]){e.preventDefault();controls.at(-1)?.focus();}else if(!e.shiftKey&&document.activeElement===controls.at(-1)){e.preventDefault();controls[0]?.focus();}}});
  addEventListener('resize',()=>{if(active)render();});
  return {show,close,refresh:()=>{if(active&&active.kind==='manage'&&active.tab==='work')render();},get active(){return active;}};
}
